package data.scripts.shipsystems;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.*;
import java.util.List;

import static java.lang.Math.sqrt;

/**
 * Reloads missile weapons while the shipsystem is active
 * @author Nicke535
 */
public class loa_missileManufactorumStats extends BaseShipSystemScript {
    //Percentage of a weapon's maximum ammo to refill each second. 0.01 would be 1%
    private static final float REFILL_RATE = 0.04f;

    //Sound that plays each time a missile weapon gets a piece of ammo back
    private static final String REFILL_SOUND = "loa_missilefactory_load";

    //General volume multiplier for the refill sound
    private static final float REFILL_SOUND_MULTIPLIER = 1f;

    //Approximate number of sparks spawned (per second, per weapon) whenn refilling ammo
    private static final float SPARK_AMOUNT = 1f;

    //Size of the sparks that are spawned when refilling ammo
    private static final float SPARK_SIZE = 15f;


    /* - CODE-SPECIFIC, DON'T TOUCH - */
    //Keeps track of "leftover ammo" between frames
    private Map<WeaponAPI, Float> leftoverAmmo = new HashMap<>();
    //Keeps track of total reload status of all weapon types (needed for the correct display of status data)
    private Map<String, Integer> weaponReloadCurrentLevels = new HashMap<>();
    private Map<String, Integer> weaponReloadMaximumLevels = new HashMap<>();
    private List<String> weaponReloadStatusIDs = new LinkedList<>();


    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        //Don't run if our engine is nonexistent
        if (Global.getCombatEngine() == null) {
            return;
        }

        ShipAPI ship;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
        } else {
            return;
        }

        //Time counter
        float amount = Global.getCombatEngine().getElapsedInLastFrame();
        if (Global.getCombatEngine().isPaused()) {
            amount = 0;
        }

        //Get all our missile weapons
        weaponReloadStatusIDs.clear();
        weaponReloadCurrentLevels.clear();
        weaponReloadMaximumLevels.clear();
        java.util.List<WeaponAPI> mslWeapons = new ArrayList<>();
        for (WeaponAPI wep : ship.getAllWeapons()) {
            //Ignore non-missiles
            if (wep.getType() != WeaponAPI.WeaponType.MISSILE) {
                continue;
            }

            //Ignore missiles with unlimited max ammo/no max ammo
            if (wep.getMaxAmmo() <= 0 || wep.getMaxAmmo() > 99999f) {
                continue;
            }

            //Otherwise, we keep the weapon
            mslWeapons.add(wep);

            //Also register its reload progress to the list so we can print it later
            if (weaponReloadStatusIDs.contains(wep.getDisplayName())) {
                weaponReloadCurrentLevels.put(wep.getDisplayName(), weaponReloadCurrentLevels.get(wep.getDisplayName())+wep.getAmmo());
                weaponReloadMaximumLevels.put(wep.getDisplayName(), weaponReloadMaximumLevels.get(wep.getDisplayName())+wep.getMaxAmmo());
            } else {
                weaponReloadStatusIDs.add(wep.getDisplayName());
                weaponReloadCurrentLevels.put(wep.getDisplayName(), wep.getAmmo());
                weaponReloadMaximumLevels.put(wep.getDisplayName(), wep.getMaxAmmo());
            }
        }

        for (WeaponAPI wep : mslWeapons) {
            //Bonus partial ammo left over from previous frames
            float previousAmmo = 0f;
            if (leftoverAmmo.get(wep) != null) {
                previousAmmo = leftoverAmmo.get(wep);
            }

            //We regenerate a percentage of a missile's base maximum ammo per second
            float maxAmmoForRegen = wep.getSpec().getMaxAmmo();
            float ammoToAdd = (maxAmmoForRegen*REFILL_RATE*amount) + previousAmmo;
            if (Math.floor(ammoToAdd) >= 1) {
                int newAmmo = wep.getAmmo() + (int)Math.floor(ammoToAdd);
                if (newAmmo > wep.getMaxAmmo()) { newAmmo = wep.getMaxAmmo(); }
                wep.setAmmo(newAmmo);
            }

            //We can reload "partial" shots in a frame, store those
            float leftOver = ammoToAdd - (float)Math.floor(ammoToAdd);
            leftoverAmmo.put(wep, leftOver);

            //We also have a random chance to spawn sparks
            if (Math.random() < SPARK_AMOUNT*amount) {
                spawnSpark(wep.getLocation(), ship.getVelocity());
            }

            //If we refilled at least one missile this frame, play a small sound depending on the weapon's max ammo, and spawn a spark
            if (ammoToAdd >= 1f) {
                float volumeMult = MathUtils.clamp(0.75f/(float)sqrt(wep.getMaxAmmo()),0.05f, 0.75f);
                float pitchMult = (0.9f - volumeMult) * 3f;
                Global.getSoundPlayer().playSound(REFILL_SOUND, pitchMult, volumeMult*REFILL_SOUND_MULTIPLIER,
                        wep.getLocation(), ship.getVelocity());
            }
        }
    }


    //Calling this does nothing, so ignore it
    public void unapply(MutableShipStatsAPI stats, String id) {}


    //Status data
    public StatusData getStatusData(int index, State state, float effectLevel) {
        //Lists all the types of missile weapons and their percentage fill level
        if (index < weaponReloadStatusIDs.size()) {
            String name = weaponReloadStatusIDs.get(index);
            if (weaponReloadCurrentLevels.containsKey(name) && weaponReloadMaximumLevels.containsKey(name)) {
                return new StatusData("" + name + ": " + weaponReloadCurrentLevels.get(name) + "/" + weaponReloadMaximumLevels.get(name), false);
            }
        }
        return null;
    }


    //Mini-function for spawning a semi-random spark
    private void spawnSpark (Vector2f approximatePosition, Vector2f targetVelocity) {
        Global.getCombatEngine().addHitParticle(MathUtils.getRandomPointInCircle(approximatePosition, 4f+SPARK_SIZE),
                MathUtils.getRandomPointInCircle(targetVelocity, 4f+SPARK_SIZE),
                MathUtils.getRandomNumberInRange(0.8f, 1.3f)*SPARK_SIZE, 1f,
                MathUtils.getRandomNumberInRange(0.15f, 0.35f), Color.ORANGE);
    }
}
