package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_warspeed3 extends BaseShipSystemScript {
    //Does what it says on the tin
    private static final boolean DEBUG_MODE = false;

    //Engine color to change to at maximum and minimum performance
    private static final Color ENGINE_COLOR_PRISTINE = new Color(255, 200, 50);
    private static final Color ENGINE_COLOR_DEFUNCT = new Color(255, 50, 0);

    //Size loss on the system engines from defunctness. Defined as a multiplier loss (0.7 = looses 70% size at max defunct)
    private static final float ENGINE_DEFUNCT_SIZE_LOSS = 0.075f;

    //How much time does it take to reach bottom-level performance?
    private static final float ACTIVATION_TIME_UNTIL_DEFUNCT = 300f;

    // How much speed does the system give at maximum and minimum?
    public static final float MAX_SPEED_INCREASE = 150f;
    public static final float MIN_SPEED_INCREASE = 35f;

    // How much acceleration does the system give at maximum and minimum? Counted as a percentage increase (50 = +50%)
    private static final float MAX_ACCEL_INCREASE = 200;
    private static final float MIN_ACCEL_INCREASE = 20f;

    // How much deceleration does the system give at maximum and minimum? Counted as a percentage increase (50 = +50%)
    private static final float MAX_DECEL_INCREASE = 100f;
    private static final float MIN_DECEL_INCREASE = 10f;

    // How much is the turning decrease at maximum and minimum effect? Counted as a multiplier (0.5 = halved turn speed)
    private static final float MAX_TURN_DECREASE = 0.5f;
    private static final float MIN_TURN_DECREASE = 1f;

   // -- Fake AI [TM] configurations --
    private static final float NEAR_ZERO_FLUX_LEVEL = 0.03f;
    private static final float MAX_DESIRED_USAGE_TIME_IN_ONE_GO = 5f;
    private static final float RANGE_FRACTION_FOR_VALID_TARGETS = 5f; //This percentage of our maximum range is the radius we search for targets in
    private static final float RANGE_FRACTION_FOR_VALID_TARGETS_FIRSTUSE = 3f; //Same as above, but for the initial "forced activation" of the system. Keep lower than above, or flicker issues occur
    private static final float FIRST_USE_GRACE_TIME = 10f; //The first time the system is used, we always trigger it for at least this long
    private static final float RANGE_FRACTION_TO_STAY_CLOSE = 0.4f;//We won't turn off the system on the offensive unless we're this close to our target (as a fraction of minimum weapon range)
    // --

    //Internal variables
    private float timeUsed = 0f;
    private boolean hasRun = false;
    private HashMap<ShipEngineAPI, Color> systemEngines = new HashMap<>();
    private float timeUsedInOneGo = 0f;
    private boolean firstEnemyEncounter = true;
    private float firstUseGraceTime = 99f;


    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //Always OK for this system to vent as cancellation
        ship.getAIFlags().setFlag(ShipwideAIFlags.AIFlags.OK_TO_CANCEL_SYSTEM_USE_TO_VENT);

        //If we haven't found our system engines yet, do that
        if (systemEngines.isEmpty()) {
            for (ShipEngineAPI engine : ship.getEngineController().getShipEngines()) {
                if (engine.isSystemActivated()) {
                    systemEngines.put(engine, engine.getEngineSlot().getColor());
                }
            }
        }

        //Run Fake AI[TM] if the player isn't controlling the ship
        if (!player || ship.getAI() != null) {
            runFakeAI(ship);
        }

        //Implementation to stop the script's main effect from running when turned off
        if (effectLevel <= 0f) {
            unapply(stats, id);
            return;
        }

        //Check if we should be flamed out. If so, deactivate the system and force a flameout
        if (ship.getSystem().isOn()) {
            int enginesActive = 0;
            List<ShipEngineAPI> nonSystemEngines = ship.getEngineController().getShipEngines();
            nonSystemEngines.removeAll(systemEngines.keySet());
            for (ShipEngineAPI engine : nonSystemEngines) {
                if (!engine.isDisabled() && !engine.isPermanentlyDisabled()) {
                    enginesActive++;
                }
            }
            if (enginesActive <= 0) {
                ship.getSystem().deactivate();
                ship.getEngineController().forceFlameout();
            }
        }


        //Tick our timer, but cap it at our maximum activation time
        //Now adjusted by SystemRegenBonus modifier to account for Systems Expertise and other similar effects
        timeUsed += ship.getMutableStats().getSystemCooldownBonus().computeEffective(Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue());
        timeUsed = Math.min(timeUsed, ACTIVATION_TIME_UNTIL_DEFUNCT);
        timeUsedInOneGo += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();

        //The current "defunctness" of the system. Also store this so that the AI knows what's up
        float defunctLevel = timeUsed / ACTIVATION_TIME_UNTIL_DEFUNCT;
        Global.getCombatEngine().getCustomData().put("loa_warspeed_defunctness" + ship.getId(), defunctLevel);

        //Changes engine color a bit, but only "system" engines
        Color mixedColor = Misc.interpolateColor(ENGINE_COLOR_PRISTINE, ENGINE_COLOR_DEFUNCT, defunctLevel);
        for (Map.Entry<ShipEngineAPI, Color> engineData : systemEngines.entrySet()) {
            ShipEngineAPI engine = engineData.getKey();
            engine.getEngineSlot().setColor(mixedColor);
            ship.getEngineController().setFlameLevel(engine.getEngineSlot(), 1f - (defunctLevel * ENGINE_DEFUNCT_SIZE_LOSS));
        }


        //Applies the actual speed / turning effects
        float speedIncrease = (MAX_SPEED_INCREASE * (1f - defunctLevel)) + (MIN_SPEED_INCREASE * defunctLevel);
        stats.getMaxSpeed().modifyFlat(id, speedIncrease * effectLevel);
        float accelIncrease = (MAX_ACCEL_INCREASE * (1f - defunctLevel)) + (MIN_ACCEL_INCREASE * defunctLevel);
        stats.getAcceleration().modifyPercent(id, accelIncrease * effectLevel);
        float decelIncrease = (MAX_DECEL_INCREASE * (1f - defunctLevel)) + (MIN_DECEL_INCREASE * defunctLevel);
        stats.getDeceleration().modifyPercent(id, decelIncrease * effectLevel);
        float turningDecrease = (MAX_TURN_DECREASE * (1f - defunctLevel)) + (MIN_TURN_DECREASE * defunctLevel);
        stats.getMaxTurnRate().modifyMult(id, 1f - ((1f - turningDecrease) * effectLevel));
        stats.getTurnAcceleration().modifyMult(id, 1f - ((1f - turningDecrease) * effectLevel));

        //Handles custom sound player bullshit to segue with the current strength level of the boost
        if (!hasRun) {
            hasRun = true;
            Global.getSoundPlayer().playSound("loa_warspeed_start", 0.9f + (1f - defunctLevel) * 0.1f, 0.5f + (1f - defunctLevel) * 0.5f,
                    ship.getLocation(), ship.getVelocity());
        } else {
            Global.getSoundPlayer().playLoop("loa_warspeed_loop", ship, (0.9f + (1f - defunctLevel) * 0.1f) * effectLevel, (0.5f + (1f - defunctLevel) * 0.5f) * effectLevel,
                    ship.getLocation(), ship.getVelocity());
        }
    }


    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        stats.getMaxSpeed().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getDeceleration().unmodify(id);
        stats.getTurnAcceleration().unmodify(id);
        stats.getMaxTurnRate().unmodify(id);

        hasRun = false;
        timeUsedInOneGo = 0f;

        for (Map.Entry<ShipEngineAPI, Color> engineData : systemEngines.entrySet()) {
            ShipEngineAPI engine = engineData.getKey();
            engine.getEngineSlot().setColor(engineData.getValue());
            ship.getEngineController().setFlameLevel(engine.getEngineSlot(), 0f);
        }
    }


    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (state == State.IDLE || state == State.COOLDOWN) {
            return null;
        }

        float defunctLevel = timeUsed / ACTIVATION_TIME_UNTIL_DEFUNCT;
        float speedIncrease = (MAX_SPEED_INCREASE * (1f - defunctLevel)) + (MIN_SPEED_INCREASE * defunctLevel);
        if (index == 0) {
            return new StatusData("+" + (int) Math.round(speedIncrease) + " top speed", false);
        } else if (index == 1 && defunctLevel < 1f) {
            return new StatusData("Reduced turning", true);
        }
        return null;
    }



    //Runs Add-On AI (so "fake" AI) for the shipsystem, turning (and keeping) it off when necessary
    private void runFakeAI(ShipAPI ship) {
        boolean keepOff = false;
        boolean turnOff = false;
        boolean preferZeroFlux = false;
        float amount = Global.getCombatEngine().getElapsedInLastFrame()*ship.getMutableStats().getTimeMult().getModifiedValue();
        float maxWeaponRangeThisFrame = getLongestWeaponRange(ship);
        float minWeaponRangeThisFrame = getShortestWeaponRange(ship);
        float defunctLevel = timeUsed / ACTIVATION_TIME_UNTIL_DEFUNCT;
        float speedIncrease = (MAX_SPEED_INCREASE * (1f - defunctLevel)) + (MIN_SPEED_INCREASE * defunctLevel);
        ShipAPI shipTarget = ship.getShipTarget();
        if (shipTarget == null) {
            if (ship.getAIFlags().getCustom(ShipwideAIFlags.AIFlags.MANEUVER_TARGET) instanceof ShipAPI) {
                shipTarget = (ShipAPI) ship.getAIFlags().getCustom(ShipwideAIFlags.AIFlags.MANEUVER_TARGET);
            }
        }

        //We don't run AI shortly after triggering a "forced" system activation
        firstUseGraceTime += amount;
        if (firstUseGraceTime < FIRST_USE_GRACE_TIME) {
            return;
        }

        //The system should never be on if our ship target doesn't exist, unless we've been ordered to retreat from combat
        if (shipTarget == null && !ship.isDirectRetreat()) {
            keepOff = true;
            if (DEBUG_MODE) {
                Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"keepoffluxf", "graphics/icons/hullsys/drone_sensor.png", "FAKE AI",
                        "SYSTEM BLOCKED BY HAVING NO TARGET", true);
            }
        } else if (!ship.isDirectRetreat()) {
            //Our zero-flux-bonus conditions don't apply if the ship has a threshhold for ZFB higher than... well, zero!
            //  This is because in that case, we get both ZFB and our system's bonus!
            float fluxThreshhold = ship.getMutableStats().getZeroFluxMinimumFluxLevel().getModifiedValue();
            if (fluxThreshhold <= 0f) {
                //The system should be turned off if we have too little flux and our speed bonus is less than our zero flux bonus
                if (ship.getFluxLevel() < NEAR_ZERO_FLUX_LEVEL
                        && speedIncrease < ship.getMutableStats().getZeroFluxSpeedBoost().getModifiedValue()) {
                    preferZeroFlux = true;
                }

                //The system should be KEPT off if we have zero flux
                if (ship.getFluxLevel() <= 0f) {
                    keepOff = true;
                    if (DEBUG_MODE) {
                        Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"keepoffluxf", "graphics/icons/hullsys/drone_sensor.png", "FAKE AI",
                                "SYSTEM BLOCKED FROM USE BY FLUX", true);
                    }
                }
            }

            //Should also be kept off if we're too far away from our target... unless they're in range of us!
            if (shipTarget != null && shipTarget.isAlive() && shipTarget.getOwner() != ship.getOwner()) {
                if (MathUtils.getDistance(ship, shipTarget) > maxWeaponRangeThisFrame * RANGE_FRACTION_FOR_VALID_TARGETS) {
                    if (MathUtils.getDistance(ship, shipTarget) > getLongestWeaponRange(shipTarget)) {
                        keepOff = true;
                        if (DEBUG_MODE) {
                            Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"keepoffrange", "graphics/icons/hullsys/drone_sensor.png", "FAKE AI",
                                    "SYSTEM BLOCKED DUE TO RANGE", true);
                        }
                    }
                }
            }
        }

        //The system should be turned off if we have left the system on for too long, or we have been told to keep it off
        //  This is ignored if we're retreating, or we're too far away from our current target
        if (timeUsedInOneGo >= MAX_DESIRED_USAGE_TIME_IN_ONE_GO || keepOff || preferZeroFlux) {
            boolean ignore = false;
            if (ship.isRetreating() || ship.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.BACKING_OFF)) {
                ignore = true;
                if (DEBUG_MODE) {
                    Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"ignore", "graphics/icons/hullsys/drone_sensor.png", "FAKE AI",
                            "RETREATING: KEEPING ON", true);
                }
            }
            if (shipTarget != null
                    && MathUtils.getDistance(ship, shipTarget) > minWeaponRangeThisFrame * RANGE_FRACTION_TO_STAY_CLOSE) {
                ignore = true;
                if (DEBUG_MODE) {
                    Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"ignore", "graphics/icons/hullsys/drone_sensor.png", "FAKE AI",
                            "NOT CLOSE ENOUGH: KEEPING ON", true);
                }
            }

            if (!ignore && timeUsedInOneGo >= MAX_DESIRED_USAGE_TIME_IN_ONE_GO) {
                timeUsedInOneGo = 0f;
            }

            turnOff = !ignore;
        }

        if (turnOff) {
            if (DEBUG_MODE) {
                Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"turnoff", "graphics/icons/hullsys/drone_sensor.png", "FAKE AI",
                        "TURNING OFF", true);
                Global.getCombatEngine().addFloatingText(ship.getLocation(), "FAKE AI : TURNING OFF", 20f, Color.RED, ship, 0.5f, 2f);
            }
            deactivateSystem(ship);
        }
        if (keepOff) {
            if (!ship.getSystem().isActive() && !ship.getSystem().isChargeup()) {
                ship.blockCommandForOneFrame(ShipCommand.USE_SYSTEM);
            }
        }

        //If we have a hostile ship target, and we have yet to activate the system this combat, AND it's within range, activate the system
        if (shipTarget != null && shipTarget.getOwner() != ship.getOwner() && firstEnemyEncounter
                && !turnOff && !keepOff) {
            if (MathUtils.getDistance(ship, shipTarget) < maxWeaponRangeThisFrame * RANGE_FRACTION_FOR_VALID_TARGETS_FIRSTUSE) {
                firstEnemyEncounter = false;
                firstUseGraceTime = 0f;
                activateSystem(ship);
                if (DEBUG_MODE) {
                    Global.getCombatEngine().addFloatingText(ship.getLocation(), "FAKE AI : FORCED ACTIVATION", 20f, Color.BLUE, ship, 0.5f, 2f);
                }
            }
        }
    }


    //Shorthand for getting the longest (non-missile, non-PD) weapon range on a ship
    private float getLongestWeaponRange(ShipAPI source) {
        //Go through all weapons, discard missiles, and return the highest range
        float maxRange = 0f;
        for (WeaponAPI wep : source.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE || wep.getSpec().getAIHints().contains(WeaponAPI.AIHints.PD)) {
                continue;
            }

            if (maxRange < wep.getRange()) {
                maxRange = wep.getRange();
            }
        }
        return maxRange;
    }


    //Shorthand for getting the shortest (non-missile, non-PD) weapon range on a ship
    private float getShortestWeaponRange(ShipAPI source) {
        //Go through all weapons, discard missiles, and return the lowest range
        float minRange = Float.MAX_VALUE;
        boolean hasChanged = false;
        for (WeaponAPI wep : source.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE || wep.getSpec().getAIHints().contains(WeaponAPI.AIHints.PD)) {
                continue;
            }

            if (minRange > wep.getRange()) {
                minRange = wep.getRange();
                hasChanged = true;
            }
        }

        if (hasChanged) {
            return minRange;
        } else {
            return 0f;
        }
    }


    private void deactivateSystem(ShipAPI ship) {
        if (ship.getSystem().isActive()) {
            ship.useSystem();
        }
    }


    private void activateSystem(ShipAPI ship) {
        if (!ship.getSystem().isOn() && AIUtils.canUseSystemThisFrame(ship)) {
            ship.useSystem();
        }
    }
}