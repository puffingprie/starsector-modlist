//By Nicke535
//Swaps between two mounted missile racks, still ticking down all (vanilla) effects on the second rack
package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import java.util.HashMap;
import java.util.Map;

public class loa_hotracks extends BaseShipSystemScript {
    //How much the malfunction chance of the system increases each time it's used, and the maximum malfunction chance it can have
    private static final float FAILURE_GAIN_PER_USE = 0.10f;
    private static final float FAILURE_CHANCE_MAX = 0.7f;

    //Internal script variables
    private Map<WeaponAPI, SwappedOutWeaponData> swappedOutMap = new HashMap<>();
    private boolean runOnce = true;
    private float currentFailureChance = 0f;

    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //Handle swapping once we're finished channeling
        if (effectLevel >= 1f) {
            runOnce = false;
        } else if (effectLevel < 1f && !runOnce) {
            runOnce = true;
            boolean failsThisTime = Math.random() < currentFailureChance;
            for (WeaponAPI wep : ship.getAllWeapons()) {
                if (wep.getType() == WeaponAPI.WeaponType.MISSILE) {
                    //If this is the first time we're swapping, instantiate data first
                    if (swappedOutMap.get(wep) == null) {
                        SwappedOutWeaponData firstData = new SwappedOutWeaponData(wep, true);
                        swappedOutMap.put(wep, firstData);
                    }
                    SwappedOutWeaponData newData = new SwappedOutWeaponData(wep);
                    wep.setAmmo(swappedOutMap.get(wep).ammoLeft);
                    wep.setRemainingCooldownTo(swappedOutMap.get(wep).cooldownLeft);
                    swappedOutMap.put(wep, newData);
                    if (failsThisTime) {
                        wep.disable(false);
                    }
                }
            }
            currentFailureChance += FAILURE_GAIN_PER_USE;
            if (currentFailureChance > FAILURE_CHANCE_MAX) {
                currentFailureChance = FAILURE_CHANCE_MAX;
            }
        }

        //Always tick all our "swapped-out" racks
        float amount = Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();
        for (SwappedOutWeaponData data : swappedOutMap.values()) {
            data.tick(amount);
        }

        //Also, store our current reload and DPS "scores" to the combat engine so we can access it somewhere else
        float reloadScore = 0f;
        float dpsScore = 0f;
        float numberOfMissileWeapons = 0f;
        for (WeaponAPI wep : ship.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE) {
                numberOfMissileWeapons++;
                if (swappedOutMap.get(wep) == null || !wep.usesAmmo()) {
                    reloadScore += 1f;
                } else {
                    reloadScore += (float)swappedOutMap.get(wep).ammoLeft / (float)wep.getMaxAmmo();
                }
                if (swappedOutMap.get(wep) != null) {
                    if (swappedOutMap.get(wep).ammoLeft > 0 || !wep.usesAmmo()) {
                        dpsScore += 1f - (swappedOutMap.get(wep).cooldownLeft / wep.getCooldown());
                    }
                } else {
                    dpsScore += 1f;
                }
            }
        }
        reloadScore /= numberOfMissileWeapons;
        dpsScore /= numberOfMissileWeapons;
        Global.getCombatEngine().getCustomData().put("loa_dual_missile_racks_" + ship.getId() + "_reloadscore", reloadScore);
        Global.getCombatEngine().getCustomData().put("loa_dual_missile_racks_" + ship.getId() + "_dpsscore", dpsScore);

        //And also store our failure chance, for the same reason
        Global.getCombatEngine().getCustomData().put("loa_dual_missile_racks_" + ship.getId() + "_failchance", currentFailureChance);
    }

    // Unapply never runs for this script, due to our settings in the .system file
    public void unapply(MutableShipStatsAPI stats, String id) {
    }

    //Shows a tooltip in the HUD
    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0) {
            return new StatusData("Hot-swap malfunction chance : " + Math.round(currentFailureChance*100f) + "%", true);
        } else if (index == 1 && state == State.ACTIVE) {
            return new StatusData("Hot-swap in progress", false);
        }
        return null;
    }

    //Class for storing data about a weapon when swapped
    private class SwappedOutWeaponData {
        WeaponAPI weapon;
        float cooldownLeft;
        int ammoLeft;
        float ammoRefillCounter = 0f;

        SwappedOutWeaponData(WeaponAPI weapon) {
            this.weapon = weapon;
            cooldownLeft = weapon.getCooldownRemaining();
            ammoLeft = weapon.getAmmo();
        }

        SwappedOutWeaponData(WeaponAPI weapon, boolean setToMax) {
            this.weapon = weapon;
            if (setToMax) {
                cooldownLeft = 0f;
                ammoLeft = weapon.getMaxAmmo();
            } else {
                cooldownLeft = weapon.getCooldownRemaining();
                ammoLeft = weapon.getAmmo();
            }
        }

        void tick(float amount) {
            cooldownLeft -= amount;
            ammoRefillCounter += amount;
            if (cooldownLeft <= 0f) {
                cooldownLeft = 0f;
            }

            if (weapon.getAmmoPerSecond() > 0f) {
                float timeToRefillAmmo = 1f / (weapon.getAmmoPerSecond()*weapon.getSpec().getBurstSize());

                if (ammoRefillCounter > timeToRefillAmmo) {
                    ammoRefillCounter -= timeToRefillAmmo;
                    ammoLeft+=weapon.getSpec().getBurstSize();
                }
                if (ammoLeft > weapon.getMaxAmmo()) {
                    ammoLeft = weapon.getMaxAmmo();
                }
            }
        }
    }
}