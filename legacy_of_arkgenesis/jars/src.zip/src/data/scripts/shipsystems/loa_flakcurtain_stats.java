package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

/**
 * Spews out projectiles all around the ship while the system is active
 * @author Nicke535
 */
public class loa_flakcurtain_stats extends BaseShipSystemScript {

	/* - Mechanical stats - */
	private static final String WEAPON_ID = "loa_flakcurtain"; //ID of the weapon to spawn shots from

	//private static final String SOUND_ID = ""; //Sound to play when firing a shot

	private static final float SHOTS_PER_SECOND = 60f; //To adjust total number of shots, adjust the system duration in ship_systems.csv
	private static final int SHOTS_PER_SALVO = 1; //Number of shots in each individual salvo. For example: if 2, firerate is halved but it shoots 2 shots per salvo

	private static final float SHOT_ANGLE = 360f; //Calculated as a cone with a total angle equal to this (180 = semicircle, 360 = full circle etc.)
	private static final float SHOT_ANGLE_OFFSET = 0f; //Offset angle for the shot arc: for example, if one wants to fire slightly right-skewed
	private static final Vector2f CENTER_OFFSET = new Vector2f(0f, 0f); //For offsetting the fire location of the system compared to the ship's center

	private static final boolean FIRERATE_RAMPUP = false; 	//If false, shots start spawning when the system is fully charged.
															//If true, shots spawn gradually faster and faster during chargeup

	/* - Smoke visual stats - */
	private static final float SMOKE_PARTICLES_PER_SECOND = 5f;
	private static final float SMOKE_SPEED = 5f;
	private static final float SMOKE_ANGLE = 0f;
	private static final float SMOKE_SCATTER = 16f;
	private static final float SMOKE_OPACITY = 0.1f;
	private static final Color SMOKE_COLOR = new Color(200, 200 ,200);
	private static final float SMOKE_MAX_DURATION = 0.5f;
	private static final float SMOKE_MIN_DURATION = 0.2f;
	private static final float SMOKE_MAX_SIZE = 20f;
    private static final float SMOKE_MIN_SIZE = 15f;

	//Internal timers
	private float shotCooldown = 0f;
	private float smokeTracker = 0f;

	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		ShipAPI ship = (ShipAPI)stats.getEntity();
		if (ship == null) { return; }
		CombatEngineAPI engine = Global.getCombatEngine();
		float amount = engine.getElapsedInLastFrame() * effectLevel * ship.getMutableStats().getTimeMult().getModifiedValue();

		/* - Effects - */
		if (effectLevel >= 0f) {
			if ((FIRERATE_RAMPUP && state.equals(State.IN)) || effectLevel >= 1f) {
				shotCooldown -= amount;
				while (shotCooldown <= 0f) {
					shotCooldown += (1f / SHOTS_PER_SECOND) * SHOTS_PER_SALVO;

					Vector2f shotSpawnLocation = ship.getLocation();
					Vector2f spawnOffset = VectorUtils.rotate(CENTER_OFFSET, ship.getFacing(), new Vector2f(0f, 0f));
					shotSpawnLocation = Vector2f.add(shotSpawnLocation, spawnOffset, new Vector2f(0f, 0f));
					//Global.getSoundPlayer().playSound(SOUND_ID, 1f, 1f, shotSpawnLocation, ship.getVelocity());
					for (int i = 0; i < SHOTS_PER_SALVO; i++) {
						engine.spawnProjectile(ship, null, WEAPON_ID, shotSpawnLocation,
								ship.getFacing()+SHOT_ANGLE_OFFSET+MathUtils.getRandomNumberInRange(-SHOT_ANGLE/2f, SHOT_ANGLE/2f),
								ship.getVelocity());
					}
				}
			}
		}

                
		/* - Visuals - */
		//Checks whether we should draw visuals at all (only draw when we are close enough to the viewport, )
		ViewportAPI viewport = engine.getViewport();
		if (!viewport.isNearViewport(ship.getLocation(), ship.getCollisionRadius() * 1.5f)) {
			return;
		}

		//Main part handling smoke: keeps a counter which depends on how many smoke particles we want per second
		smokeTracker += amount;
		if (smokeTracker > (1f / SMOKE_PARTICLES_PER_SECOND)) {
			//Handles smoke emission from all system weapon mounts
			for (WeaponSlotAPI testSlot : ship.getHullSpec().getAllWeaponSlotsCopy()) {
				if (!testSlot.isSystemSlot()) {
					continue;
				}

				Vector2f positionOfSmoke = MathUtils.getRandomPointInCircle(testSlot.computePosition(ship), 1f);
				Vector2f speedOfSmoke = MathUtils.getRandomPointInCone(null, SMOKE_SPEED, testSlot.getAngle() - SMOKE_ANGLE + ship.getFacing(), testSlot.getAngle() + SMOKE_ANGLE + ship.getFacing());
				speedOfSmoke = MathUtils.getRandomPointInCircle(speedOfSmoke, SMOKE_SCATTER);
				engine.addSmokeParticle(positionOfSmoke,
						speedOfSmoke, MathUtils.getRandomNumberInRange(SMOKE_MIN_SIZE, SMOKE_MAX_SIZE), SMOKE_OPACITY,
                        MathUtils.getRandomNumberInRange(SMOKE_MIN_DURATION, SMOKE_MAX_DURATION), SMOKE_COLOR);
			}
			//Updates our smoke tracker
			smokeTracker -= (1f / SMOKE_PARTICLES_PER_SECOND);
		}
	}

	public void unapply(MutableShipStatsAPI stats, String id) {
		shotCooldown = 0f;
	}
	
	public StatusData getStatusData(int index, State state, float effectLevel) {
		if (index == 0 && state.equals(State.ACTIVE)) {
			return new StatusData("Deploying ordinance" , false);
		}
		return null;
	}
}
