package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.dark.shaders.distortion.DistortionShader;
import org.dark.shaders.distortion.RippleDistortion;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Based on the other magnetic overload scripts, designed for the LoA IBB.
 * @author Nicke535
 */
public class loa_bigmac_system extends BaseShipSystemScript {

    //Actual gameplay configurations: adjusts the system's behaviour
    //Lightning gameplay stat configs
    private static final float LIGHTNING_DAMAGE = 100f;
    private static final float LIGHTNING_EMP_DAMAGE = 200f;
    private static final float LIGHTNING_RANGE = 600f;
    private static final float LIGHTNING_CHANCE_CHARGEUP_MAX = 0.99f; //Maximum chance, per second and system mount, for lightning to spawn. Scales up from 0 during charge-up
    private static final int LIGHTNING_ACTIVATION_COUNT = 25; //Number of lightning bolts to spawn when reaching the "on" state
    private static final int LIGHTNING_MAX_PER_TARGET = 5; //Maximum lightning bolts to allocate to each target when reaching the "on" state
    private static final float LIGHTNING_CHANCE_ACTIVE_MAX = 0.99f; //Maximum chance, per second and system mount, for lightning to spawn. Applies in the "on"-state, and fades out during chargedown

    //Burndrive gameplay stat configs
    private static final float MAX_SPEED_INCREASE = 200f;
    private static final float ACCEL_INCREASE_PERCENT = 500f;
    private static final float TURN_RATE_INCREASE_PERCENT = 200f;
    private static final float TURN_ACCEL_INCREASE_PERCENT = 200f;
    private static final float DECELERATION_PENALTY_PERCENT = 50f;

    //AI gamaplay config
    private static final float ENEMY_SHIP_DP_TO_ACTIVATE = 15f; //How many DP's worth of enemy ships without active shields needs to be in range to activate
    private static final float ENEMY_MISSILE_DAMAGE_TO_ACTIVATE = 2000f; //How much total enemy missile damage must be in range for the system to activate
    private static final int ENEMY_FIGHTERS_TO_ACTIVATE = 8; //How many enemy fighters need to be in range for the system to activate
    private static final float LIGHTNING_RANGE_FOR_AI = 700f;

    //Visual config: change some visual parameters
    private static final Color ENGINE_COLOR = new Color(255, 50, 0);
    private static final Color ENGINE_CONTRAIL_COLOR = new Color(40, 40, 20);
    private static final Color LIGHTNING_COLOR = new Color(255, 50, 0);
    private static final Color LIGHTNING_COLOR_CORE = new Color(255, 75, 50);
    private static final float LIGHTNING_MIN_SIZE = 15f; //Picks a random value between MIN and MAX
    private static final float LIGHTNING_MAX_SIZE = 18f;
    private static final boolean FAR_PROPAGATION = true; // When true, makes lightning shoot to random spots nearby when it fails to find a target, instead of targeting the ship itself
    private static final float LIGHTNING_MIN_PROPAGATION_RANGE = 150f; //Minimum lightning range, only used for FAR_PROPAGATION
    private static final float DISTORTION_DURATION = 0.5f;
    private static final float DISTORTION_INTENSITY = 75f;
    private static final float DISTORTION_MIN_SIZE = 0f;
    private static final float DISTORTION_MAX_SIZE = 250f;

    //Audio config
    private static final String ACTIVATION_SOUND = "loa_macattack_charge";
    private static final String FULL_POWER_SOUND = "loa_macattack_kick";
    private static final String LOOP_SOUND = "loa_macattack_loop";

    //Internal script variables
    private boolean runOnce = false;
    private boolean hasReachedFullPower = false;

    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //Fake AI[TM]: since we can't attach a proper AI script, we'll do a separate AI check here!
        //Note that any ship with getAI == null is under player control, so it doesn't run the AI
        if (AIUtils.canUseSystemThisFrame(ship)
                && (!player || ship.getAI() != null)) {
            runFakeAI(ship);
        }

        //Run our unapply() when needed, instead of the rest of the code
        if (effectLevel <= 0f) {
            unapply(stats, id);
            return;
        }

        //Sound on activation, that is, when the system gets > 0 effect level for the first time
        if (effectLevel > 0f && !runOnce) {
            runOnce = true;
            Global.getSoundPlayer().playSound(ACTIVATION_SOUND, 1f, 1f, ship.getLocation(), Misc.ZERO);
        }

        //Loop sound
        if (effectLevel > 0f) {
            Global.getSoundPlayer().playLoop(LOOP_SOUND, ship, 1f, effectLevel, ship.getLocation(), Misc.ZERO);
        }


        //Active lightning spawning: first time we reach full effectLevel, spawn a bunch of lightning and play a sound
        if (effectLevel >= 1f && !hasReachedFullPower) {
            hasReachedFullPower = true;
            Global.getSoundPlayer().playSound(FULL_POWER_SOUND, 1f, 1f, ship.getLocation(), Misc.ZERO);
            HashMap<ShipAPI, Integer> hitAllocator = new HashMap<>();
            WeightedRandomPicker<Vector2f> slotPicker = new WeightedRandomPicker<>();
            for (int i = 0; i < LIGHTNING_ACTIVATION_COUNT; i++) {
                if (slotPicker.isEmpty()) {
                    for (WeaponSlotAPI slot : ship.getHullSpec().getAllWeaponSlotsCopy()) {
                        if (slot.isSystemSlot()) {
                            slotPicker.add(slot.computePosition(ship));
                        }
                    }
                }
                spawnOneEMPArc(ship, slotPicker.pickAndRemove(), hitAllocator);
            }

            //Oh, and spawn Glib distortions from all slots as well. Almost forgot that
            for (WeaponSlotAPI slot : ship.getHullSpec().getAllWeaponSlotsCopy()) {
                if (slot.isSystemSlot()) {
                    RippleDistortion distortion = new RippleDistortion(slot.computePosition(ship), Misc.ZERO);
                    distortion.setAutoAnimateFrameRate(15 / DISTORTION_DURATION, 45);

                    //Handles negative intensity
                    float actualIntensity = DISTORTION_INTENSITY;
                    if (actualIntensity < 0f) {
                        actualIntensity *= -1f;
                        distortion.flip(true);
                    }
                    distortion.setIntensity(actualIntensity);

                    //Ensure the effect fades out properly
                    distortion.setLifetime(DISTORTION_DURATION);
                    distortion.fadeOutIntensity(DISTORTION_DURATION);

                    //We want the size to work a bit wierdly, namely to fade in, but start at 25%. So we add that
                    distortion.setSize(DISTORTION_MAX_SIZE - DISTORTION_MIN_SIZE);
                    distortion.fadeInSize(DISTORTION_DURATION);
                    distortion.setSize(DISTORTION_MIN_SIZE);

                    //And finally ensure the distortion is tracked
                    DistortionShader.addDistortion(distortion);
                }
            }
        }


        //This is for the "passive" lightning spawning
        for (WeaponSlotAPI weaponSlotAPI : ship.getHullSpec().getAllWeaponSlotsCopy()) {
            //Only care about system slots
            if (!weaponSlotAPI.isSystemSlot()) {
                continue;
            }

            //Get our lightning chance for the current frame
            float lightningChance = LIGHTNING_CHANCE_ACTIVE_MAX;
            if (state.equals(State.IN)) {
                lightningChance = LIGHTNING_CHANCE_CHARGEUP_MAX;
            }

            //Do we send out lightning this frame? If not, skip to next mount
            if (Math.pow((1f - lightningChance), Global.getCombatEngine().getElapsedInLastFrame()) >= (Math.random() * effectLevel)) {
                continue;
            }

            //Get our weapon slot's position
            Vector2f point = weaponSlotAPI.computePosition(ship);
            spawnOneEMPArc(ship, point, null);
        }

        //Burndrive-related code
        stats.getMaxSpeed().modifyFlat(id, MAX_SPEED_INCREASE * effectLevel);
        stats.getAcceleration().modifyPercent(id, ACCEL_INCREASE_PERCENT * effectLevel);
        stats.getMaxTurnRate().modifyPercent(id, TURN_RATE_INCREASE_PERCENT * effectLevel);
        stats.getTurnAcceleration().modifyPercent(id, TURN_ACCEL_INCREASE_PERCENT * effectLevel);
        stats.getDeceleration().modifyMult(id, 1f - (DECELERATION_PENALTY_PERCENT/100f));
        ship.getEngineController().fadeToOtherColor(this, ENGINE_COLOR, ENGINE_CONTRAIL_COLOR, 1.0f, 1.0f);
    }


    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        hasReachedFullPower = false;

        stats.getMaxSpeed().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getMaxTurnRate().unmodify(id);
        stats.getTurnAcceleration().unmodify(id);
        stats.getDeceleration().unmodify(id);
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (state.equals(State.COOLDOWN) || state.equals(State.IDLE)) {
            return null;
        } else {
            if (index == 0) {
                return new StatusData("all power to thrusters", false);
            }
            if (index == 1) {
                return new StatusData("engaging bolt emitters", false);
            }
            return null;
        }
    }

    //Spawns a single EMP arc
    // If "hitAllocator" is null, infinite hits per target are possible. Otherwise, it counts and prevents hits from being allocated to certain targets too many times
    private void spawnOneEMPArc(ShipAPI ship, Vector2f point, HashMap<ShipAPI, Integer> hitAllocator) {
        CombatEntityAPI targetEntity = null;
        List<ShipAPI> shipsWithinRange = CombatUtils.getShipsWithinRange(point, LIGHTNING_RANGE);
        List<CombatEntityAPI> removeList = new ArrayList<CombatEntityAPI>();
        for (ShipAPI testShip : shipsWithinRange) {
            if (testShip.getOwner() == ship.getOwner() || testShip.isPhased() || testShip.getCollisionClass().equals(CollisionClass.NONE)) {
                removeList.add(testShip);
            }
            if (hitAllocator != null) {
                Integer hitsOnTarget = hitAllocator.get(testShip);
                if (hitsOnTarget != null && hitsOnTarget >= LIGHTNING_MAX_PER_TARGET) {
                    removeList.add(testShip);
                }
            }
        }
        List<MissileAPI> missilesWithinRange = CombatUtils.getMissilesWithinRange(point, LIGHTNING_RANGE);
        for (MissileAPI testMissile : missilesWithinRange) {
            if (testMissile.getOwner() == ship.getOwner() || testMissile.getCollisionClass().equals(CollisionClass.NONE)) {
                removeList.add(testMissile);
            }
        }

        for (CombatEntityAPI removeThing : removeList) {
            if (shipsWithinRange.contains(removeThing)) {
                shipsWithinRange.remove(removeThing);
            }
            if (missilesWithinRange.contains(removeThing)) {
                missilesWithinRange.remove(removeThing);
            }
        }

        //Targeting: find which missile/ship we want to hit
        //(the damage nuller is for if we don't find a target)
        float damageNuller = 1f;
        boolean targetIsShip = false;
        if (missilesWithinRange.isEmpty() && shipsWithinRange.isEmpty()) {
            damageNuller = 0f;

            //Checks if we want random propagation or self-discharge as a visual indicator when no enemies are in range
            if (FAR_PROPAGATION) {
                targetEntity = new SimpleEntity(MathUtils.getRandomPointOnCircumference(point, MathUtils.getRandomNumberInRange(LIGHTNING_MIN_PROPAGATION_RANGE, LIGHTNING_RANGE)));
            } else {
                targetEntity = ship;
            }
        } else if (!missilesWithinRange.isEmpty() && (shipsWithinRange.isEmpty() || MathUtils.getRandomNumberInRange(0, missilesWithinRange.size() + shipsWithinRange.size()) < missilesWithinRange.size())) {
            targetEntity = missilesWithinRange.get(MathUtils.getRandomNumberInRange(0, missilesWithinRange.size()-1));
        } else {
            targetEntity = shipsWithinRange.get(MathUtils.getRandomNumberInRange(0, shipsWithinRange.size()-1));
            targetIsShip = true;
        }

        //Update our hitAllocator, if we have one
        if (hitAllocator != null && targetIsShip) {
            if (hitAllocator.get(targetEntity) == null) {
                hitAllocator.put((ShipAPI)targetEntity, 1);
            } else {
                hitAllocator.put((ShipAPI)targetEntity, hitAllocator.get(targetEntity)+1);
            }
        }

        //Ensures we don't hit spots far away on the target ship, but also that we don't get weird bugs
        float maxRange = 1000000f;
        if (targetIsShip) {
            Vector2f closestThingy = getClosestMountOrEngineFromPoint(point, (ShipAPI)targetEntity);
            maxRange = Math.max(MathUtils.getDistance(closestThingy, point)+50f, LIGHTNING_RANGE);
        }

        Global.getCombatEngine().spawnEmpArc(ship, point, ship, targetEntity,
                DamageType.ENERGY, //Damage type
                LIGHTNING_DAMAGE * damageNuller, //Damage
                LIGHTNING_EMP_DAMAGE * damageNuller, //Emp
                maxRange, //Max range
                "al_emoverload_zap", //Impact sound
                MathUtils.getRandomNumberInRange(LIGHTNING_MIN_SIZE, LIGHTNING_MAX_SIZE), // thickness of the lightning bolt
                LIGHTNING_COLOR_CORE, //Central color
                LIGHTNING_COLOR //Fringe Color
        );
    }

    //Utility function used for the thing shown above
    private Vector2f getClosestMountOrEngineFromPoint(Vector2f point, ShipAPI target) {
        float closestDistance = Float.MAX_VALUE;
        Vector2f closestSpotYet = point;
        for (ShipEngineControllerAPI.ShipEngineAPI engine : target.getEngineController().getShipEngines()){
            float newDistance = MathUtils.getDistance(engine.getLocation(), point);
            if (newDistance < closestDistance) {
                closestSpotYet = engine.getLocation();
                closestDistance = newDistance;
            }
        }
        for (WeaponAPI wep : target.getAllWeapons()) {
            if (wep.getSlot().isHidden()) {
                continue;
            }
            float newDistance = MathUtils.getDistance(wep.getLocation(), point);
            if (newDistance < closestDistance) {
                closestSpotYet = wep.getLocation();
                closestDistance = newDistance;
            }
        }

        return closestSpotYet;
    }

    private void activateSystem(ShipAPI ship) {
        if (!ship.getSystem().isOn()) {
            ship.useSystem();
        }
    }

    //Runs Add-On AI (so "fake" AI) for the shipsystem, detecting incoming missiles, fighters and ships
    private void runFakeAI(ShipAPI ship) {
        Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName()+"def", "graphics/icons/hullsys/drone_sensor.png", "AI RUNNING", "AI RUNNING", false);

        //First, gets all ships in range
        List<ShipAPI> nearbyEnemies = CombatUtils.getShipsWithinRange(ship.getLocation(), LIGHTNING_RANGE_FOR_AI);
        int numberOfFighters = 0;
        int nearbyDP = 0;
        for (ShipAPI other : nearbyEnemies) {
            if (other.isPhased()
                    || other.getCollisionClass().equals(CollisionClass.NONE)
                    || other.getOwner() == ship.getOwner()) {
                continue;
            }

            if (other.getHullSize().equals(ShipAPI.HullSize.FIGHTER)) {
                numberOfFighters++;
            } else {
                nearbyDP += other.getDeployCost();
            }
        }

        //Should we activate due to ships?
        if (numberOfFighters >= ENEMY_FIGHTERS_TO_ACTIVATE
            || nearbyDP >= ENEMY_SHIP_DP_TO_ACTIVATE) {
            activateSystem(ship);
            return;
        }

        //Check for missiles, if we haven't already activated
        float damage = 0f;
        for (MissileAPI msl : CombatUtils.getMissilesWithinRange(ship.getLocation(), LIGHTNING_RANGE_FOR_AI)) {
            if (msl.isArmed()
                    && !msl.isFizzling()
                    && msl.getOwner() != ship.getOwner()) {
                damage += msl.getDamageAmount();
            }
        }
        if (damage > ENEMY_MISSILE_DAMAGE_TO_ACTIVATE) {
            activateSystem(ship);
        } else {
            Global.getCombatEngine().maintainStatusForPlayerShip(this.getClass().getName(), "graphics/icons/hullsys/drone_sensor.png", ""+damage, ""+damage, false);
        }
    }
}