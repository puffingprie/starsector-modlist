package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.util.Misc;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

/**
 * A simple stat-changing shipsystem script, which gets worse over time
 * @author Nicke535
 */
public class loa_redline extends BaseShipSystemScript {
    private static final boolean DEBUG_MODE = true;//Turns off or on logging output
    private final static Logger LOGGER = Global.getLogger(loa_redline.class);

    public static final float MAX_SPEED_INCREASE = 600f; //Note that this doesn't apply when accelerating backwards
    public static final float ACCEL_BONUS_PERCENT = 200f;
    public static final float TIME_MULT = 0.85f; //At 0.5, that means time moves half as fast for the ship compared to others, at 2f, time moves twice as fast for it
    public static final float BONUS_LOSS_PER_USE = 0.15f; //How much of the bonuses gets lost each use (so at 0.15, you loose 15% of the current bonus each time. Scales multiplicatively)
    public static final String BLOWOUT_SOUND = "loa_redline_explode"; //The sound to play once the system reaches "down" state

    //Particle size, color and longevity for when the system reaches Active state
    public static final float PARTICLE_SIZE = 30f;
    public static final Color PARTICLE_COLOR = new Color(255, 155, 100);
    public static final float PARTICLE_DURATION = 1.25f;

    private float timesUsed = 0;
    private boolean hasActivated = false;

    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        ShipAPI ship;
        boolean player;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //Just in case...
        if (effectLevel <= 0f) {
            unapply(stats, id);
            return;
        }

        //Handles the "blowout" effect and degradation over time
        if (DEBUG_MODE) {
            LOGGER.info("Started blowout code");
        }
        float bonusMult = (float)Math.pow(1f-BONUS_LOSS_PER_USE, timesUsed);
        if (effectLevel >= 1f) {
            hasActivated = true;
        } else if (hasActivated) {
            Global.getSoundPlayer().playSound(BLOWOUT_SOUND, 0.5f + 0.5f*bonusMult, 0.5f + 0.5f*bonusMult, ship.getLocation(), new Vector2f(0f, 0f));
            for (ShipEngineControllerAPI.ShipEngineAPI engine : ship.getEngineController().getShipEngines()) {
                if (!engine.isDisabled()) {
                    Global.getCombatEngine().spawnExplosion(engine.getLocation(), ship.getVelocity(), PARTICLE_COLOR, PARTICLE_SIZE, PARTICLE_DURATION);
                }
            }
            timesUsed += 1f;
            hasActivated = false;
        }
        if (DEBUG_MODE) {
            LOGGER.info("Ended blowout code");
        }

        //Calculate max speeds with and without system
        if (DEBUG_MODE) {
            LOGGER.info("Started speed calc code");
        }
        stats.getMaxSpeed().unmodify(id);
        float maxSpeedBase = ship.getMutableStats().getMaxSpeed().getModifiedValue();
        stats.getMaxSpeed().modifyPercent(id,MAX_SPEED_INCREASE*effectLevel*bonusMult);
        float maxSpeedSystem = ship.getMutableStats().getMaxSpeed().getModifiedValue();
        if (DEBUG_MODE) {
            LOGGER.info("Ended speed calc code");
        }

        //If we accelerate backwards, we get no max-speed increase
        if (ship.getEngineController().isAcceleratingBackwards()) {
            stats.getMaxSpeed().unmodify(id);
        }
        stats.getAcceleration().modifyPercent(id,ACCEL_BONUS_PERCENT*effectLevel*bonusMult);


        //Adjusts time mult, based on how fast we're going compared to how fast we *could* be going
        float baseShipTimeMult = 1f + (TIME_MULT - 1f) * effectLevel * bonusMult;
        float timeMultProgress = Math.min(1f, Math.max(0f, (MathUtils.getDistance(new Vector2f(0f, 0f), ship.getVelocity())-maxSpeedBase) / (maxSpeedSystem-maxSpeedBase)));
        float shipTimeMult = Misc.interpolate(1f, baseShipTimeMult, timeMultProgress);
        if (DEBUG_MODE) {
            LOGGER.info("Time mult this frame : " + shipTimeMult);
        }

        if (Float.isNaN(shipTimeMult)) {
            if (DEBUG_MODE) {
                throw new RuntimeException("Not-A-Number detected! Current status: timesUsed="+timesUsed+", bonusMult="+bonusMult+", baseShipTimeMult="+baseShipTimeMult+", maxSpeedBase="+maxSpeedBase+", maxSpeedSystem="+maxSpeedSystem);
            } else {
                throw new RuntimeException("An unexpected issue occurred in loa_redline.java. Send this message to the mod author with the following info: timesUsed="+timesUsed+", bonusMult="+bonusMult+", baseShipTimeMult="+baseShipTimeMult+", maxSpeedBase="+maxSpeedBase+", maxSpeedSystem="+maxSpeedSystem);
            }
        }
        if (player) {
            stats.getTimeMult().modifyMult(id, shipTimeMult);
            Global.getCombatEngine().getTimeMult().modifyMult(id, 1f / shipTimeMult);
        } else {
            stats.getTimeMult().modifyMult(id, shipTimeMult);
            Global.getCombatEngine().getTimeMult().unmodify(id);
        }
    }

    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }
        if (DEBUG_MODE) {
            LOGGER.info("Started unapply()");
        }

        stats.getMaxSpeed().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getTimeMult().unmodify(id);
        Global.getCombatEngine().getTimeMult().unmodify(id);

        if (DEBUG_MODE) {
            LOGGER.info("Ended unapply()");
        }
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0) {
            return new StatusData("Wierd system is a go!", false);
        }
        return null;
    }
}