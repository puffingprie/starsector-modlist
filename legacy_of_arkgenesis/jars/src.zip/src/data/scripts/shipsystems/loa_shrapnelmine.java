//By Nicke535, adapted from the MineStrikeStats script by Alex
package data.scripts.shipsystems;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.impl.combat.MineStrikeStatsAIInfoProvider;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class loa_shrapnelmine extends BaseShipSystemScript implements MineStrikeStatsAIInfoProvider {
	//The weapon ID of the mine weapon in weapon_data.csv
	private static final String MINE_WEAPON_ID = "loa_amflak_mine";

	//Weapon ID of the shrapnel fired on mine detonation (also weapon_data.csv). CANNOT be a beam
	private static final String SHRAPNEL_WEAPON_ID = "loa_amflak";

	//The amount of shrapnel projectiles spawned on mine detonation
	private static final int SHRAPNEL_COUNT = 30;

	//How much the speed of the shrapnel pieces vary (as a multiplier; 0.2 means  up to 20% reduced speed)
	private static final float SHRAPNEL_SPEED_VARIANCE = 0.45f;

	//Range of the minelayer
	private static final float MINE_RANGE = 1500f;

	//Minimum distance a mine will spawn from a target
	private static final float MIN_SPAWN_DIST = 150f;

	//How long the mine will move around before stopping for the last stage of detonation.
	private static final float MOVING_TIME = 7f;

	//How long the mine will "live" after arming (but before detonating)
	private static final float ARMED_TIME = 2f;

	//The sound the system makes when placing a mine
	private static final String MINE_PLACE_SOUND = "loa_shrapnelmine_place";


	//Returns how long the fuse of the mine is, IE how long it takes before the mine is allowed to explode.
	public float getFuseTime() {
		return MOVING_TIME;
	}

	//Needed by the API nowadays
	public float getMineRange(ShipAPI ship) {return MINE_RANGE;}


	//Main apply function
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		//Gets the ship
		ShipAPI ship = null;
		if (stats.getEntity() instanceof ShipAPI) {
			ship = (ShipAPI) stats.getEntity();
		} else {
			return;
		}

		//If we're using the system, fire off a mine
		if (state != State.IN && effectLevel >= 1) {
			//Gets our system target point; first, check the mouse target and any eventual flag-based target
			Vector2f target = ship.getMouseTarget();
			if (ship.getShipAI() != null && ship.getAIFlags().hasFlag(AIFlags.SYSTEM_TARGET_COORDS)){
				target = (Vector2f) ship.getAIFlags().getCustom(AIFlags.SYSTEM_TARGET_COORDS);
			}

			//If we have a target, we do some vanilla math to determine where we want to drop the mine
			if (target != null) {
				float dist = Misc.getDistance(ship.getLocation(), target);
				float max = getMaxRange(ship) + ship.getCollisionRadius();
				if (dist > max) {
					float dir = Misc.getAngleInDegrees(ship.getLocation(), target);
					target = Misc.getUnitVectorAtDegreeAngle(dir);
					target.scale(max);
					Vector2f.add(target, ship.getLocation(), target);
				}

				target = findClearLocation(ship, target);

				if (target != null) {
					spawnMine(ship, target);
				}
			}
		}
	}


	//Unapply function: never runs
	public void unapply(MutableShipStatsAPI stats, String id) {
	}


	//Function for actually spawning a "mine"
	public void spawnMine(ShipAPI source, Vector2f mineLoc) {
		//Vanilla mine spawning checks and math. Essentially, find a nice location which doesn't have mines too close
		CombatEngineAPI engine = Global.getCombatEngine();
		Vector2f currLoc = Misc.getPointAtRadius(mineLoc, 30f + (float) Math.random() * 30f);
		float start = (float) Math.random() * 360f;
		for (float angle = start; angle < start + 390; angle += 30f) {
			if (angle != start) {
				Vector2f loc = Misc.getUnitVectorAtDegreeAngle(angle);
				loc.scale(50f + (float) Math.random() * 30f);
				currLoc = Vector2f.add(mineLoc, loc, new Vector2f());
			}
			for (MissileAPI other : Global.getCombatEngine().getMissiles()) {
				if (!other.isMine()) continue;

				float dist = Misc.getDistance(currLoc, other.getLocation());
				if (dist < other.getCollisionRadius() + 40f) {
					currLoc = null;
					break;
				}
			}
			if (currLoc != null) {
				break;
			}
		}
		if (currLoc == null) {
			currLoc = Misc.getPointAtRadius(mineLoc, 30f + (float) Math.random() * 30f);
		}

		//Spawn us the "mine", at the location we selected earlier
		MissileAPI mine = (MissileAPI) engine.spawnProjectile(source, null,
				MINE_WEAPON_ID,
				currLoc,
				(float) Math.random() * 360f, null);

		//"Fades in" the mine
		float fadeInTime = 0.4f;
		mine.getVelocity().scale(0);
		mine.fadeOutThenIn(fadeInTime);

		//Adjusts the mine's lifetime, so it detonates at the right time
		float liveTime = MOVING_TIME + ARMED_TIME;
		mine.setFlightTime(mine.getMaxFlightTime()-MOVING_TIME);
		mine.setUntilMineExplosion(liveTime);

		//Tracks extra mine effects, in our case splitting into shrapnel
		Global.getCombatEngine().addPlugin(handleSplinterFakeMinePlugin(engine, mine, this));

		//Sound for spawning a "mine"
		Global.getSoundPlayer().playSound(MINE_PLACE_SOUND, 1f, 1f, mine.getLocation(), mine.getVelocity());
	}


	//An everyframeplugin added to handle each individual mine's effects
	protected EveryFrameCombatPlugin handleSplinterFakeMinePlugin(final CombatEngineAPI engine, final MissileAPI mine, final loa_shrapnelmine originScript) {
		return new BaseEveryFrameCombatPlugin() {
			//Timer for elapsed time
			float elapsed = 0f;

			//Timer for elapsed time *while armed*
			float elapsedArmed = 0f;

			//The health the mine had the last frame
			float lastMineHealth = mine.getHitpoints();

			@Override
			public void advance(float amount, List<InputEventAPI> events) {
				//Advance the timer
				if (Global.getCombatEngine().isPaused()) return;
				elapsed += amount;

				//If we are armed, also advance the "armed" timer
				if (mine.isMinePrimed()) {
					elapsedArmed += amount;
				}

				//If the mine is dead, remove it completely: it has simply died from damage
				if (mine.getHitpoints() <= 0f) {
					Global.getCombatEngine().removePlugin(this);
					return;
				}

				//Once the mine has dissapeared (without dying to damage), detonate it visually (the actual damage and
				//stuff is handled vanilla-like by the projectile, except EMP) and remove the tracker entirely
				if (!engine.isEntityInPlay(mine)) {
					handleMineDetonation();
					Global.getCombatEngine().removePlugin(this);
					return;
				}

				//Stores how much health the mine has, so it can detect getting shot
				lastMineHealth = mine.getHitpoints();
			}

			//Handles the "explosion" of the mine, when it ends charging but wasn't shot down: spawns a whole bunch of shrapnel
			private void handleMineDetonation () {
				//Simply spawns shrapnel equal to our shrapnel count, from our shrapnel weapon
				for (int i = 0; i < SHRAPNEL_COUNT; i++) {
					DamagingProjectileAPI proj = (DamagingProjectileAPI)engine.spawnProjectile(mine.getSource(), null,
							SHRAPNEL_WEAPON_ID,
							mine.getLocation(),
							(float) Math.random() * 360f, null);
					proj.getVelocity().scale(MathUtils.getRandomNumberInRange(1f-SHRAPNEL_SPEED_VARIANCE, 1f));
				}
			}
		};
	}


	//For AI: returns the maximum range to activate at
	protected float getMaxRange(ShipAPI ship) {
		return getMineRange(ship);
	}


	//Returns info text
	@Override
	public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
		if (system.isOutOfAmmo()) return null;
		if (system.getState() != SystemState.IDLE) return null;

		Vector2f target = ship.getMouseTarget();
		if (target != null) {
			float dist = Misc.getDistance(ship.getLocation(), target);
			float max = getMaxRange(ship) + ship.getCollisionRadius();
			if (dist > max) {
				return "OUT OF RANGE";
			} else {
				return "READY";
			}
		}
		return null;
	}


	//Determines if a shipsystem is usable
	@Override
	public boolean isUsable(ShipSystemAPI system, ShipAPI ship) {
		return ship.getMouseTarget() != null;
	}


	//Some vanilla math to get a non-occuped location for the mine
	private Vector2f findClearLocation(ShipAPI ship, Vector2f dest) {
		if (isLocationClear(dest)) return dest;

		float incr = 50f;

		WeightedRandomPicker<Vector2f> tested = new WeightedRandomPicker<Vector2f>();
		for (float distIndex = 1; distIndex <= 32f; distIndex *= 2f) {
			float start = (float) Math.random() * 360f;
			for (float angle = start; angle < start + 360; angle += 60f) {
				Vector2f loc = Misc.getUnitVectorAtDegreeAngle(angle);
				loc.scale(incr * distIndex);
				Vector2f.add(dest, loc, loc);
				tested.add(loc);
				if (isLocationClear(loc)) {
					return loc;
				}
			}
		}

		if (tested.isEmpty()) return dest; // shouldn't happen

		return (Vector2f)tested.pick();
	}

	//Some more vanilla math to find clear locations for mines
	private boolean isLocationClear(Vector2f loc) {
		for (ShipAPI other : Global.getCombatEngine().getShips()) {
			if (other.isShuttlePod()) continue;
			if (other.isFighter()) continue;
			float dist = Misc.getDistance(loc, other.getLocation());
			float r = other.getCollisionRadius();
			//r = Math.min(r, Misc.getTargetingRadius(loc, other, false) + r * 0.25f);
			if (dist < r + MIN_SPAWN_DIST) {
				return false;
			}
		}
		for (CombatEntityAPI other : Global.getCombatEngine().getAsteroids()) {
			float dist = Misc.getDistance(loc, other.getLocation());
			if (dist < other.getCollisionRadius() + MIN_SPAWN_DIST) {
				return false;
			}
		}

		return true;
	}
}



