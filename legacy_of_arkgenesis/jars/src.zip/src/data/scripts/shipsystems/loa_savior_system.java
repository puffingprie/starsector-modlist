package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import org.magiclib.plugins.MagicTrailPlugin;
import org.magiclib.util.MagicRender;
import org.dark.shaders.distortion.DistortionShader;
import org.dark.shaders.distortion.RippleDistortion;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.EnumSet;
import java.util.List;

/**
 * System script for the Saviour : a fancy-pancy teleporter
 */
public class loa_savior_system extends BaseShipSystemScript {
    //These *must* match the stats in ship_systems.csv : I can't easily grab them from there so it was easier to
    //input them here at the top of the config instead
    //  Note that all other times set in the script except the buff times are expected to add up to this
    private static final float CHARGEUP = 5.1f;
    private static final float CHARGEDOWN = 3.1f;

    //How long does the "normal" phasing take, and what is the opacity for the ship there?
    private static final float PHASE_TIME = 0.6f;
    private static final float PHASE_OPACITY = 0.2f;

    //How long does the various phases in the ship's teleportation take?
    private static final float DEEPPHASE_FADE_IN_TIME = 2.5f; //As in, fade time for the "in" state
    private static final float DISAPPEARANCE_TIME = 2f;
    private static final float DEEPPHASE_FADE_OUT_TIME = 2.5f; //As in, fade time for the "out" state
    private static final float DAMAGE_BONUS_BUFF_TIME_FULL = 5f; //FULL + FADE is expected to match for both bonuses
    private static final float DAMAGE_BONUS_BUFF_TIME_FADE = 5f;
    private static final float FLUX_BONUS_BUFF_TIME_FULL = 0f;
    private static final float FLUX_BONUS_BUFF_TIME_FADE = 10f;

    //Maximum flux and damage bonus for weapons
    //      Expressed as percentages
    private static final float MAX_DAMAGE_BONUS = 50f;
    private static final float MAX_FLUX_BONUS = -100f;

    //ID of the sprite to use for the ship's phase glow
    //Expected to be loaded in settings.json under the category "loa_combat"
    private static final String GLOW_1_SPRITE_ID = "loa_savior_glow1";
    private static final String GLOW_2_SPRITE_ID = "loa_savior_glow2";

    //Colors of the ship's phase glows
    //      I've set them to vanilla values for now, but feel free to change of course
    private static final Color GLOW_1_COLOR = new Color(255, 175, 255, 255);
    private static final Color GLOW_2_COLOR = new Color(255, 0, 255, 150);

    //Glow color for the ship's weapons while buffed
    private static final Color WEAPON_GLOW_COLOR = new Color(255, 0, 255, 150);

    //The "in" and "out" sound effects to play for the system, when entering and exiting deepphase
    //private static final String IN_SOUND = "system_phase_cloak_activate";
    private static final String OUT_SOUND = "loa_shockjump_exit";

    //Function variable for the rate at which distortion ripples spawn
    //      Higher values means a sharper curve, while lower values give a smoother peak
    //      A 1f means using a simple linear function, 2f is quadratic etc. Lower values than 0f has unforeseen consequences
    private static final float RIPPLE_FUNCTION_VAR = 0.5f;

    //Maximum spawn rate of ripples from the system
    //      Expressed as ripples/second
    private static final float MAX_RIPPLES_PER_SECOND = 3f;

    //Different stats for the ripples themselves
    private static final float RIPPLE_MAX_SIZE = 550f; //Max size of the ripple
    private static final float RIPPLE_DURATION = 3f; //Duration of an individual ripple
    private static final float RIPPLE_DEPTH = 20f; //The "displacement intensity" of an individual ripple

    //Stats for jitter. Note that jitter scales just like ripple frequency does
    private static final float JITTER_DURATION = 0.03f;
    private static final float JITTER_COPIES_PER_SECOND = 140f;
    private static final float JITTER_MAX_SIZE = 15f;
    private static final float JITTER_OPACITY = 0.5f;
    private static final float JITTER_EXTRAJITTER = 2f; //This one is a bit odd, play around with it

    //This is how much the ship is "pushed" by when overlapping with other ships.
    //Finicky variable, play around a bit with it to get it good.
    //1f approximately represents getting completely shunted out over 1 second, 2f half a second etc.
    private static final float BASE_PUSH_FORCE = 5f;

    //"Safe flux level" for the buff : while below this flux level, the ship won't try and vent while it still has
    //its system buff applied
    private static final float SAFE_FLUX_LEVEL = 0.65f;


    //Internal script variables
    private boolean hasSpawnedFadeInGlow = false;
    private boolean hasSpawnedFadeOutGlow = false;
    private boolean hasPlayedInSound = false;
    private boolean hasPlayedOutSound = false;
    private float rippleTimer = 0f;
    private float jitterTimer = 0f;
    private Float lockedFacing = null;


    @SuppressWarnings("deprecation")
    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        //Don't run when paused
        if (Global.getCombatEngine().isPaused()) {
            return;
        }

        //Ensures we have a ship
        ShipAPI ship = null;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //We have different effects depending on where exactly we are in the activation sequence
        SystemStateTracker stateTracker = new SystemStateTracker();
        stateTracker.calculateState(state, effectLevel);
        if (stateTracker.systemState == SystemState.OFF) {
            unapply(stats, id);
        } else {
            //Prevent weapon fire and shield use until the phase is entirely over
            //Also (hopefully?) prevent prefire by setting our collision class to NONE
            ship.blockCommandForOneFrame(ShipCommand.FIRE);
            ship.blockCommandForOneFrame(ShipCommand.VENT_FLUX);
            ship.blockCommandForOneFrame(ShipCommand.USE_SELECTED_GROUP);
            ship.blockCommandForOneFrame(ShipCommand.TOGGLE_SHIELD_OR_PHASE_CLOAK);
            ship.setHoldFireOneFrame(true);
            ship.setCollisionClass(CollisionClass.NONE);

            //Keep adjusting our facing, it's been proven unstable. Only do this on the out-path
            if (state.equals(State.OUT)) {
                facingAdjustment(ship);
            }
        }

        if (stateTracker.systemState == SystemState.PHASE_IN || stateTracker.systemState == SystemState.PHASE_OUT) {
            //Phase : if we haven't yet spawned our fade-in glow we spawn that (should only trigger on the first frame really)
            if (stateTracker.systemState == SystemState.PHASE_IN) {
                if (!hasSpawnedFadeInGlow) {
                    hasSpawnedFadeInGlow = true;
                    SpriteAPI sprite1 = Global.getSettings().getSprite("loa_combat", GLOW_1_SPRITE_ID);
                    SpriteAPI sprite2 = Global.getSettings().getSprite("loa_combat", GLOW_2_SPRITE_ID);
                    MagicRender.objectspace(sprite1, ship, new Vector2f(0f, 0f), new Vector2f(0f, 0f),
                            new Vector2f(sprite1.getWidth(), sprite1.getHeight()), new Vector2f(0f, 0f),
                            180f, 0f, true, GLOW_1_COLOR, true,
                            0f, 0f, 0f, 0f, 0f, PHASE_TIME, 0f,
                            DEEPPHASE_FADE_IN_TIME, true, CombatEngineLayers.ABOVE_SHIPS_LAYER);
                    MagicRender.objectspace(sprite2, ship, new Vector2f(0f, 0f), new Vector2f(0f, 0f),
                            new Vector2f(sprite2.getWidth(), sprite2.getHeight()), new Vector2f(0f, 0f),
                            180f, 0f, true, GLOW_2_COLOR, true,
                            0f, 0f, 0f, 0f, 0f, PHASE_TIME, 0f,
                            DEEPPHASE_FADE_IN_TIME, true, CombatEngineLayers.ABOVE_SHIPS_LAYER);
                }

                //And, if in the "in" state, handle ripples
                float progress = stateTracker.timeInCurrentState / (PHASE_TIME + DEEPPHASE_FADE_IN_TIME);
                spawnRipples(ship, progress);
            }

            //And we also handle phase both for in and out phase
            handlePhase(ship, stateTracker.systemState.equals(SystemState.PHASE_IN) ? (stateTracker.timeInCurrentState / PHASE_TIME) : 1f - (stateTracker.timeInCurrentState / PHASE_TIME));
        } else if (stateTracker.systemState == SystemState.DEEPPHASE_IN) {
            if (!hasPlayedInSound) {
                hasPlayedInSound = true;
                //Global.getSoundPlayer().playSound(IN_SOUND, 1f, 1f, ship.getLocation(), new Vector2f(0f, 0f));
            }
            float progress = stateTracker.timeInCurrentState / DEEPPHASE_FADE_IN_TIME;
            phase(ship, Misc.interpolate(PHASE_OPACITY, 0f, progress));
            float rippleProgress = (PHASE_TIME + stateTracker.timeInCurrentState) / (PHASE_TIME + DEEPPHASE_FADE_IN_TIME);
            spawnRipples(ship, rippleProgress);
        } else if (stateTracker.systemState == SystemState.DEEPPHASE) {
            phase(ship, 0f);
        } else if (stateTracker.systemState == SystemState.DEEPPHASE_OUT) {
            float progress = stateTracker.timeInCurrentState / DEEPPHASE_FADE_OUT_TIME;
            //Deepphase : out. Spawn our fade-out glow if we haven't yet
            //  Also add our buffs here while we're at it
            //  NEW: also also adjust our turning to better face targets
            if (!hasSpawnedFadeOutGlow) {
                hasSpawnedFadeOutGlow = true;
                SpriteAPI sprite1 = Global.getSettings().getSprite("loa_combat", GLOW_1_SPRITE_ID);
                SpriteAPI sprite2 = Global.getSettings().getSprite("loa_combat", GLOW_2_SPRITE_ID);
                MagicRender.objectspace(sprite1, ship, new Vector2f(0f, 0f), new Vector2f(0f, 0f),
                        new Vector2f(sprite1.getWidth(), sprite1.getHeight()), new Vector2f(0f, 0f),
                        180f, 0f, true, GLOW_1_COLOR, true,
                        0f, 0f, 0f, 0f, 0f, DEEPPHASE_FADE_OUT_TIME, 0f,
                        PHASE_TIME, true, CombatEngineLayers.ABOVE_SHIPS_LAYER);
                MagicRender.objectspace(sprite2, ship, new Vector2f(0f, 0f), new Vector2f(0f, 0f),
                        new Vector2f(sprite2.getWidth(), sprite2.getHeight()), new Vector2f(0f, 0f),
                        180f, 0f, true, GLOW_2_COLOR, true,
                        0f, 0f, 0f, 0f, 0f, DEEPPHASE_FADE_OUT_TIME, 0f,
                        PHASE_TIME, true, CombatEngineLayers.ABOVE_SHIPS_LAYER);
                Global.getCombatEngine().addPlugin(new SaviorBuff(id, ship, DEEPPHASE_FADE_OUT_TIME + PHASE_TIME));
            }

            //Also start returning from deep-phase
            if (!hasPlayedOutSound) {
                hasPlayedOutSound = true;
                //Global.getSoundPlayer().playSound(OUT_SOUND, 1f, 1f, ship.getLocation(), new Vector2f(0f, 0f));
            }
            phase(ship, Misc.interpolate(0f, PHASE_OPACITY, progress));
            spawnRipples(ship, progress);
            pushFromNearbyShips(ship);
        }
    }

    //For handling "normal" phase-in and phase-out
    private void handlePhase(ShipAPI ship, float progress) {
        phase(ship, 1f - (progress * (1f - PHASE_OPACITY)));
    }

    //For quickly changing the ship's opacity and making it untargetable
    private void phase(ShipAPI ship, float opacity) {
        MagicTrailPlugin.cutTrailsOnEntity(ship);
        ship.setExtraAlphaMult(opacity);
        ship.setApplyExtraAlphaToEngines(true);
    }


    //Handles spawning "ripples" of screen distortion
    //Also
    private void spawnRipples(ShipAPI ship, float progress) {
        float progressAdjusted = progress * 2f;
        if (progress > 0.5f) {
            progressAdjusted = (1f - progress) * 2f;
        }

        progressAdjusted = (float) Math.pow(progressAdjusted, RIPPLE_FUNCTION_VAR);


        //Jitter : a first attempt using after-images
        jitterTimer += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue() * progressAdjusted;
        while (jitterTimer >= (1f / JITTER_COPIES_PER_SECOND)) {
            jitterTimer -= (1f / JITTER_COPIES_PER_SECOND);
            Vector2f jitterPos = MathUtils.getRandomPointInCircle(new Vector2f(0f, 0f), JITTER_MAX_SIZE*progressAdjusted);
            ship.addAfterimage(new Color(1f, 1f, 1f, JITTER_OPACITY), jitterPos.x, jitterPos.y,
                    0f, 0f, JITTER_EXTRAJITTER,0f, JITTER_DURATION, 0f, false,
                    true, false);

            SpriteAPI sprite1 = Global.getSettings().getSprite("loa_combat", GLOW_1_SPRITE_ID);
            SpriteAPI sprite2 = Global.getSettings().getSprite("loa_combat", GLOW_2_SPRITE_ID);
            MagicRender.objectspace(sprite1, ship, jitterPos, new Vector2f(0f, 0f),
                    new Vector2f(sprite1.getWidth(), sprite1.getHeight()), new Vector2f(0f, 0f), 180f,
                    0f, true, Misc.interpolateColor(Misc.interpolateColor(GLOW_2_COLOR, Color.black, progress), Color.black, 1f-JITTER_OPACITY),
                    true,0f, 0f, 0f, 0f, 0f, 0f,
                    JITTER_DURATION, 0f, true, CombatEngineLayers.ABOVE_SHIPS_LAYER);
            MagicRender.objectspace(sprite2, ship, jitterPos, new Vector2f(0f, 0f),
                    new Vector2f(sprite2.getWidth(), sprite2.getHeight()), new Vector2f(0f, 0f), 180f,
                    0f, true, Misc.interpolateColor(Misc.interpolateColor(GLOW_2_COLOR, Color.black, progress), Color.black, 1f-JITTER_OPACITY),
                    true,0f, 0f, 0f, 0f, 0f, 0f,
                    JITTER_DURATION, 0f, true, CombatEngineLayers.ABOVE_SHIPS_LAYER);
        }

        //Actual ripple
        rippleTimer += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue() * progressAdjusted;
        while (rippleTimer >= (1f / MAX_RIPPLES_PER_SECOND)) {
            rippleTimer -= (1f / MAX_RIPPLES_PER_SECOND);
            RippleDistortion ripple = new RippleDistortion(new Vector2f(ship.getLocation()), Misc.ZERO);
            ripple.setCurrentFrame(0);
            ripple.setIntensity(RIPPLE_DEPTH);

            //Ensure the effect fades out properly
            ripple.setLifetime(RIPPLE_DURATION);
            ripple.fadeOutIntensity(RIPPLE_DURATION);

            //The ripple need needs to grow over time, or there's not much of a ripple!
            //Also adds animation
            ripple.setSize(RIPPLE_MAX_SIZE);
            ripple.fadeInSize(RIPPLE_DURATION);
            ripple.setFrameRate(120f / RIPPLE_DURATION);

            //And finally ensure the distortion is tracked
            DistortionShader.addDistortion(ripple);
        }
    }

    //"Pushes" the ships from any nearby ships, so that it can avoid collisions
    private void pushFromNearbyShips(ShipAPI ship) {
        float amount = Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();
        List<ShipAPI> otherShips = CombatUtils.getShipsWithinRange(ship.getLocation(), ship.getCollisionRadius());

        Vector2f moveSpeed = new Vector2f(0f, 0f);
        for (ShipAPI other : otherShips) {
            if (ship == other || other.getCollisionClass() == CollisionClass.NONE || other.getHullSize() == ShipAPI.HullSize.FIGHTER) {
                continue;
            }

            float moreAccurateDistance = MathUtils.getDistance(other.getLocation(), ship.getLocation())
                    - other.getCollisionRadius()
                    - Misc.getTargetingRadius(other.getLocation(), ship, false);
            if (moreAccurateDistance < 0f) {
                //We are overlapping : apply a force depending on overlap amount
                Vector2f forceToApply = VectorUtils.getDirectionalVector(other.getLocation(), ship.getLocation());
                forceToApply.x *= (moreAccurateDistance + 30f) * -1f * BASE_PUSH_FORCE;
                forceToApply.y *= (moreAccurateDistance + 30f) * -1f * BASE_PUSH_FORCE;
                moveSpeed = Vector2f.add(moveSpeed, forceToApply, new Vector2f(0f, 0f));
            }
        }

        ship.getLocation().x += moveSpeed.x * amount;
        ship.getLocation().y += moveSpeed.y * amount;
    }

    /**
     * Adjusts the ship's facing to improve on vanilla's behaviour
     */
    private void facingAdjustment(ShipAPI ship) {
        //If we don't have a locked facing, we need to get one
        if (lockedFacing == null) {
            //Only adjust if our ship target is not null
            //      Note that we MIGHT have a special "locked in" target from our AI as well: in that case, use that
            ShipAPI target = ship.getShipTarget();
            if (Global.getCombatEngine().getCustomData().get("LOA_SAVIOR_AI_TARGET_KEY"+ship.getId()) instanceof ShipAPI) {
                //Only count the locked target if we're not player controlled
                if (Global.getCombatEngine().getPlayerShip() != ship || Global.getCombatEngine().isUIAutopilotOn()) {
                    target = (ShipAPI) Global.getCombatEngine().getCustomData().get("LOA_SAVIOR_AI_TARGET_KEY"+ship.getId());
                }
                Global.getCombatEngine().getCustomData().remove("LOA_SAVIOR_AI_TARGET_KEY"+ship.getId());
            }
            if (target == null) {
                return;
            }
            lockedFacing = VectorUtils.getAngle(ship.getLocation(), target.getLocation());
        }

        ship.setFacing(lockedFacing);
    }


    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        ship.getMutableStats().getEnergyWeaponDamageMult().unmodify(id);
        ship.getMutableStats().getEnergyWeaponFluxCostMod().unmodify(id);
        lockedFacing = null;

        if (ship.getSystem().getEffectLevel() <= 0f) {
            hasPlayedInSound = false;
            hasPlayedOutSound = false;
            hasSpawnedFadeInGlow = false;
            hasSpawnedFadeOutGlow = false;
            ship.setExtraAlphaMult(1f);
            ship.setCollisionClass(CollisionClass.SHIP);
        }
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        SystemStateTracker stateTracker = new SystemStateTracker();
        stateTracker.calculateState(state, effectLevel);
        if (state.equals(State.IN)) {
            if (index == 0) {
                return new StatusData("Entering Deep Phase", false);
            }
        } else if (state.equals(State.OUT)) {
            if (index == 0) {
                return new StatusData("Exiting Deep Phase", false);
            }
        }
        return null;
    }

    //Keeps track of the system's state
    private class SystemStateTracker {
        float timeInCurrentState;
        SystemState systemState;

        void calculateState(State state, float effectLevel) {
            if (state.equals(State.IN)) {
                float timePassed = effectLevel * CHARGEUP;
                if (timePassed <= PHASE_TIME) {
                    systemState = SystemState.PHASE_IN;
                    timeInCurrentState = timePassed;
                } else {
                    timePassed -= PHASE_TIME;
                    if (timePassed <= DEEPPHASE_FADE_IN_TIME) {
                        systemState = SystemState.DEEPPHASE_IN;
                        timeInCurrentState = timePassed;
                    } else {
                        timePassed -= DEEPPHASE_FADE_IN_TIME;
                        if (timePassed <= DISAPPEARANCE_TIME) {
                            systemState = SystemState.DEEPPHASE;
                            timeInCurrentState = timePassed;
                        } else {
                            systemState = SystemState.OFF; // Failsafe, should never happen
                        }
                    }
                }
            } else if (state.equals(State.OUT)) {
                float timePassed = (1f - effectLevel) * CHARGEDOWN;
                if (timePassed <= DEEPPHASE_FADE_OUT_TIME) {
                    systemState = SystemState.DEEPPHASE_OUT;
                    timeInCurrentState = timePassed;
                } else {
                    timePassed -= DEEPPHASE_FADE_OUT_TIME;
                    if (timePassed <= PHASE_TIME) {
                        systemState = SystemState.PHASE_OUT;
                        timeInCurrentState = timePassed;
                    } else {
                        systemState = SystemState.OFF;
                    }
                }
            } else {
                systemState = SystemState.OFF;
            }
        }
    }

    enum SystemState {
        PHASE_IN,
        PHASE_OUT,
        DEEPPHASE_IN,
        DEEPPHASE,
        DEEPPHASE_OUT,
        OFF
    }

    /**
     * Class for managing the status buffs applied by the system
     */
    private class SaviorBuff extends BaseEveryFrameCombatPlugin {
        private String id;
        private ShipAPI ship;
        private float silentDuration;

        private float lifetime = 0f;

        SaviorBuff(String id, ShipAPI ship, float silentDuration) {
            this.id = id;
            this.ship = ship;
            this.silentDuration = silentDuration;
        }

        @Override
        public void advance(float amount, List<InputEventAPI> events) {
            if (Global.getCombatEngine().isPaused()) {
                return;
            }
            lifetime += amount * ship.getMutableStats().getTimeMult().getModifiedValue();
            if (lifetime < silentDuration) {
                return;
            }

            //If the ship is not overfluxed, tell AI to not vent if the buff still applies
            if (ship.getFluxLevel() < SAFE_FLUX_LEVEL) {
                ship.getAIFlags().setFlag(ShipwideAIFlags.AIFlags.DO_NOT_VENT, 0.2f);
            } else {
                ship.getAIFlags().unsetFlag(ShipwideAIFlags.AIFlags.DO_NOT_VENT);
            }

            //Remove after the lifetime OR if we overload/vent
            if ((lifetime > DAMAGE_BONUS_BUFF_TIME_FADE + DAMAGE_BONUS_BUFF_TIME_FULL + silentDuration
                    && lifetime > FLUX_BONUS_BUFF_TIME_FADE + FLUX_BONUS_BUFF_TIME_FULL + silentDuration)
                    || ship.getFluxTracker().isOverloadedOrVenting()) {
                ship.getAIFlags().unsetFlag(ShipwideAIFlags.AIFlags.DO_NOT_VENT);
                Global.getCombatEngine().removePlugin(this);
            }

            float fadeLifetimeDamage = Math.max(0f, lifetime - silentDuration - DAMAGE_BONUS_BUFF_TIME_FULL);
            float fadeLifetimeFlux = Math.max(0f, lifetime - silentDuration - FLUX_BONUS_BUFF_TIME_FULL);
            float damageBonus = (1f - (fadeLifetimeDamage / DAMAGE_BONUS_BUFF_TIME_FADE)) * MAX_DAMAGE_BONUS;
            float fluxBonus = (1f - (fadeLifetimeFlux / FLUX_BONUS_BUFF_TIME_FADE)) * MAX_FLUX_BONUS;

            ship.getMutableStats().getEnergyWeaponDamageMult().modifyPercent(id, damageBonus);
            ship.getMutableStats().getEnergyWeaponFluxCostMod().modifyPercent(id, fluxBonus);

            if (ship.equals(Global.getCombatEngine().getPlayerShip())) {
                Global.getCombatEngine().maintainStatusForPlayerShip(id + "damage", "graphics/icons/hullsys/displacer.png",
                        "Shock Jump", "Weapon damage increased by " + Math.round(damageBonus) + "%", false);
                Global.getCombatEngine().maintainStatusForPlayerShip(id + "flux", "graphics/icons/hullsys/displacer.png",
                        "Shock Jump", "Weapon flux cost reduced to " + Math.round(100f + fluxBonus) + "%", false);
            }

            EnumSet<WeaponType> weaponTypesToGlow = EnumSet.allOf(WeaponType.class);
            ship.setWeaponGlow(damageBonus / MAX_DAMAGE_BONUS, WEAPON_GLOW_COLOR, weaponTypesToGlow);
        }
    }
}