package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class loa_moestats extends BaseShipSystemScript {

    public static final float DAMAGE_BONUS_PERCENT = 1.5f;
    public static final float ROF_BONUS = 2f;
    public static final float FLUX_MODULATION = 0.5f;
    public static final float BEAM_FLUX_MODULATION = 1.5f;

    /* - Smoke visual stats - */
    private static final float SMOKE_PARTICLES_PER_SECOND = 25f;
    private static final float SMOKE_SPEED = 15f;
    private static final float SMOKE_ANGLE = 0f;
    private static final float SMOKE_SCATTER = 16f;
    private static final float SMOKE_OPACITY = 0.4f;
    private static final Color SMOKE_COLOR = new Color(255, 255, 255);
    private static final float SMOKE_MAX_DURATION = 0.7f;
    private static final float SMOKE_MIN_DURATION = 0.3f;
    private static final float SMOKE_MAX_SIZE = 10f;
    private static final float SMOKE_MIN_SIZE = 5f;

    //Internal timer
    private float tracker = 0f;

    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        float bonusPercent = DAMAGE_BONUS_PERCENT * effectLevel;
        float mult = ROF_BONUS * effectLevel;
        stats.getBeamWeaponDamageMult().modifyMult(id, bonusPercent);
        stats.getBallisticWeaponFluxCostMod().modifyMult(id, FLUX_MODULATION);
        stats.getEnergyWeaponFluxCostMod().modifyMult(id, FLUX_MODULATION);
        stats.getBeamWeaponFluxCostMult().modifyMult(id, BEAM_FLUX_MODULATION);
        stats.getBallisticRoFMult().modifyMult(id, mult);
        stats.getEnergyRoFMult().modifyMult(id, mult);

        /* - Visuals - */
        //Checks whether we should draw visuals at all (only draw when we are close enough to the viewport, )
        ShipAPI ship = (ShipAPI) stats.getEntity();
        if (ship == null) { return; }
        ViewportAPI viewport = Global.getCombatEngine().getViewport();
        if (!viewport.isNearViewport(ship.getLocation(), ship.getCollisionRadius() * 1.5f)) {
            return;
        }

        //Main part handling smoke: keeps a counter which depends on how many smoke particles we want per second
        tracker += Global.getCombatEngine().getElapsedInLastFrame();
        if (tracker > (1f / SMOKE_PARTICLES_PER_SECOND)) {
            //Handles smoke emission from all system weapon mounts
            for (WeaponSlotAPI testSlot : ship.getHullSpec().getAllWeaponSlotsCopy()) {
                if (!testSlot.isSystemSlot()) {
                    continue;
                }

                Vector2f positionOfSmoke = MathUtils.getRandomPointInCircle(testSlot.computePosition(ship), 1f);
                Vector2f speedOfSmoke = MathUtils.getRandomPointInCone(null, SMOKE_SPEED, testSlot.getAngle() - SMOKE_ANGLE + ship.getFacing(), testSlot.getAngle() + SMOKE_ANGLE + ship.getFacing());
                speedOfSmoke = Vector2f.add(speedOfSmoke, MathUtils.getRandomPointInCircle(null, SMOKE_SCATTER), null);

                Global.getCombatEngine().addSmokeParticle(positionOfSmoke,
                        speedOfSmoke, MathUtils.getRandomNumberInRange(SMOKE_MIN_SIZE, SMOKE_MAX_SIZE), SMOKE_OPACITY,
                        MathUtils.getRandomNumberInRange(SMOKE_MIN_DURATION, SMOKE_MAX_DURATION), SMOKE_COLOR);
            }
            //Updates our smoke tracker
            tracker -= (1f / SMOKE_PARTICLES_PER_SECOND);
        }
    }

    public void unapply(MutableShipStatsAPI stats, String id) {
        stats.getBeamWeaponDamageMult().unmodify(id);
        stats.getBallisticWeaponFluxCostMod().unmodify(id);
        stats.getEnergyWeaponFluxCostMod().unmodify(id);
        stats.getBeamWeaponFluxCostMult().unmodify(id);
        stats.getBallisticRoFMult().unmodify(id);
        stats.getEnergyRoFMult().unmodify(id);
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        float damageBonusPercent = DAMAGE_BONUS_PERCENT * effectLevel;
        float firerateBonusPercent = ROF_BONUS * effectLevel * 100f;
        if (index == 0) {
            return new StatusData("Boosting Weapons", false);
        } else if (index == 1) {
            return new StatusData("Modulating Weapon Flux", false);
        } else if (index == 2) {
            return new StatusData("Generating Hard Flux", false);
        }
        return null;
    }
}
