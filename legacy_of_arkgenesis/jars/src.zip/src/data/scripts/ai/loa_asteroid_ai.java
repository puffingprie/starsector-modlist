package data.scripts.ai;

import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipCommand;

public class loa_asteroid_ai implements MissileAIPlugin {

    private final MissileAPI missile;

    public loa_asteroid_ai(MissileAPI missile) {
        this.missile = missile;
    }

    @Override
    public void advance(float amount) {
        missile.giveCommand(ShipCommand.TURN_LEFT);
    }
}