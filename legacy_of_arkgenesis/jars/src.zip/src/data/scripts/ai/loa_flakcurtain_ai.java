package data.scripts.ai;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles the AI for the loa_aoeSpewerStats script and its related system
 * @author Nicke535
 */
public class loa_flakcurtain_ai implements ShipSystemAIScript {
    //Enable if the shipsystem is a toggle, disable otherwise
    private static final boolean TOGGLEABLE = false;

    //How much "weight" does the ship need to fire its system (it will not fire the system if the weight is below this value, or if there are allies too close)
    private static final float WEIGHT_TO_FIRE = 1f;

    //How much "weight" does each enemy missile, fighter or ship contribute?
    private static final float MISSILE_WEIGHT = 1f;
    private static final float FIGHTER_WEIGHT = 1f;
    private static final float SHIP_WEIGHT = 1f;

    //Detection range for missiles, fighters, enemies, allies and damaged allies, respectively
    private static final float MISSILE_DETECTION_RANGE = 300f;
    private static final float FIGHTER_DETECTION_RANGE = 250f;
    private static final float HOSTILE_DETECTION_RANGE = 200f;

    //How often we check for AI conditions (min, max). Keep relatively low
    private final IntervalUtil tracker = new IntervalUtil(0.2f, 0.35f);


    //Internal variables
    private ShipSystemAPI system;
    private ShipAPI ship;

    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.system = system;
    }

    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        tracker.advance(amount);

        //Wait for interval elapse before doing a check
        if (tracker.intervalElapsed()) {
            float currentWeight = 0f;

            //Gets all enemies in range, and registers their weight
            for (ShipAPI enemy : AIUtils.getNearbyEnemies(ship, Math.max(FIGHTER_DETECTION_RANGE, HOSTILE_DETECTION_RANGE))) {
                if (enemy.getHullSize().equals(ShipAPI.HullSize.FIGHTER) && MathUtils.getDistance(ship, enemy) <= FIGHTER_DETECTION_RANGE) {
                    currentWeight += FIGHTER_WEIGHT;
                } else if (MathUtils.getDistance(ship, enemy) <= HOSTILE_DETECTION_RANGE) {
                    currentWeight += SHIP_WEIGHT;
                }
            }
            //Also get missiles and register them as well if they're hostile
            for (MissileAPI missile : CombatUtils.getMissilesWithinRange(ship.getLocation(), MISSILE_DETECTION_RANGE)) {
                if (missile.getOwner() != ship.getOwner()) {
                    currentWeight += MISSILE_WEIGHT;
                }
            }

            if (currentWeight >= WEIGHT_TO_FIRE) {
                activateSystem();
            } else if (TOGGLEABLE) {
                deactivateSystem();
            }
        }
    }

    private void deactivateSystem() {
        if (system.isOn()) {
            ship.useSystem();
        }
    }

    private void activateSystem() {
        if (!system.isOn()) {
            ship.useSystem();
        }
    }
}
