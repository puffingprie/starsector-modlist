package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

/**
 * An AI for the Missile Manufactorum (<--rename to whatever the system is called), based on Gwyverns overall design
 * @author Nicke535
 */
public class loa_missileManufactorumAI implements ShipSystemAIScript {
    //Turns on DEBUG mode, printing out some extra help on-screen depending on what's going on
    private static final boolean DEBUG_MODE = false;

    //How long we have to wait to activate our system after firing any weapon, in seconds
    private static final float FIRING_WAIT_TIME = 1f;

    //We don't count as "attacking" anyone if we're at least this far away from the nearest enemy, regardless of AI flags
    private static final float ATTACK_RANGE = 2500f;

    //When is an enemy considered "close" or "far" by the AI?
    private static final float CLOSE_RANGE = 3500f;

    //The "high" and "low" hardflux levels we can dedicate to generating missiles (based on if they're outside or within CLOSE range)
    private static final float HIGH_HARDFLUX_LIMIT = 0.8f;
    private static final float LOW_HARDFLUX_LIMIT = 0.4f;

    //The highest flux level we're allowed to reach, hardflux or not: if our flux is higher than this, we deactivate the system
    private static final float REALLY_HIGH_FLUX_LEVEL = 0.95f;

    //"Grace amount" for flux before we start using the system, so we don't toggle it on-off-on too much
    //      Example: at 0.1, and LOW_HARDFLUX_LIMIT 0.4, we won't turn the system ON until we hit 30% hardflux, and won't turn it OFF until we hit 40% hardflux
    private static final float FLUX_GRACE_FRACTION = 0.15f;

    //How often we check for AI conditions (min, max)
    private final IntervalUtil tracker = new IntervalUtil(0.2f, 0.35f);

    //Internal variables
    private ShipSystemAPI system;
    private ShipAPI ship;
    private ShipwideAIFlags flags;
    private float firingWeaponCounter = 0f;

    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.system = system;
        this.flags = flags;
    }

    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        handleFiringWeaponCounter(amount);

        tracker.advance(amount);
        if (tracker.intervalElapsed()) {
            //Basic "blocking" conditions for the system
            if (firingWeaponCounter > 0f
                    || isOnTheAttack()
                    || isOnTheRun()
                    || hasMaxMissiles()
                    || ship.getFluxLevel() > REALLY_HIGH_FLUX_LEVEL) {
                toggleOff();
                return;
            }

            //Flux conditions: depending on how close the nearest target is, we allow different amounts of flux to be used for missile generation
            if (anyEnemiesInCloseRange()) {
                if (ship.getHardFluxLevel() <= (LOW_HARDFLUX_LIMIT-FLUX_GRACE_FRACTION)) {
                    toggleOn();
                } else if (ship.getHardFluxLevel() >= LOW_HARDFLUX_LIMIT) {
                    toggleOff();
                }
            } else {
                if (ship.getHardFluxLevel() <= (HIGH_HARDFLUX_LIMIT-FLUX_GRACE_FRACTION)) {
                    toggleOn();
                } else if (ship.getHardFluxLevel() >= HIGH_HARDFLUX_LIMIT) {
                    toggleOff();
                }
            }
        }
    }

    //Checks if the ship has any of the flags which constitute "running away" from a target
    private boolean isOnTheRun() {
        boolean running = flags.hasFlag(ShipwideAIFlags.AIFlags.RUN_QUICKLY) || flags.hasFlag(ShipwideAIFlags.AIFlags.BACK_OFF);
        if (DEBUG_MODE && running) {
            Global.getCombatEngine().addFloatingText(ship.getLocation(), "Running away : no missile regen",
                    20f, Color.RED, ship, 0f, 0.5f);
        }
        return running;
    }


    //Checks if the ship has any of the flags which constitute "attacking" a target
    private boolean isOnTheAttack() {
        boolean attacking = flags.hasFlag(ShipwideAIFlags.AIFlags.IN_ATTACK_RUN)
                || flags.hasFlag(ShipwideAIFlags.AIFlags.PURSUING)
                || flags.hasFlag(ShipwideAIFlags.AIFlags.AUTO_FIRING_AT_PHASE_SHIP)
                || flags.hasFlag(ShipwideAIFlags.AIFlags.HARASS_MOVE_IN);
        attacking = attacking && anyEnemiesInAttackRange();
        if (DEBUG_MODE && attacking) {
            Global.getCombatEngine().addFloatingText(ship.getLocation(), "Attacking a target : no missile regen",
                    20f, Color.RED, ship, 0f, 0.5f);
        }
        return attacking;
    }

    //Handles keeping track of whether we've recently shot a weapon or not
    private void handleFiringWeaponCounter(float amount) {
        firingWeaponCounter -= amount;
        for (WeaponAPI wep : ship.getAllWeapons()) {
            //If the weapon is currently firing, register that and exit the loop
            if (wep.isFiring()) {
                firingWeaponCounter = FIRING_WAIT_TIME;
                return;
            }
        }
    }

    private boolean anyEnemiesInCloseRange() {
        for (ShipAPI otherShip : CombatUtils.getShipsWithinRange(ship.getLocation(), CLOSE_RANGE)) {
            if (otherShip.getOwner() != ship.getOwner() && !otherShip.isHulk()) {
                if (DEBUG_MODE) {
                    Global.getCombatEngine().addFloatingText(ship.getLocation(), "Enemy is in close range",
                            20f, Color.YELLOW, ship, 0f, 0.5f);
                }
                return true;
            }
        }
        return false;
    }

    private boolean anyEnemiesInAttackRange() {
        for (ShipAPI otherShip : CombatUtils.getShipsWithinRange(ship.getLocation(), ATTACK_RANGE)) {
            if (otherShip.getOwner() != ship.getOwner() && !otherShip.isHulk()) {
                return true;
            }
        }
        return false;
    }

    //Checks if we have maximum missiles reloaded
    private boolean hasMaxMissiles() {
        for (WeaponAPI wep : ship.getAllWeapons()) {
            //Ignore non-missiles
            if (wep.getType() != WeaponAPI.WeaponType.MISSILE) {
                continue;
            }

            //Ignore missiles with unlimited max ammo/no max ammo
            if (wep.getMaxAmmo() <= 0 || wep.getMaxAmmo() > 99999f) {
                continue;
            }

            //If the weapon has less current ammo than max amo, we obviously don't have max missiles!
            if (wep.getAmmo() < wep.getMaxAmmo()) {
                return false;
            }
        }
        return true;
    }

    private void toggleOff() {
        if (system.isOn()) {
            ship.useSystem();
        }
    }

    private void toggleOn() {
        if (!system.isActive() && AIUtils.canUseSystemThisFrame(ship)) {
            ship.useSystem();
        }
    }
}
