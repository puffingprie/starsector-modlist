package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * AI for the Savior shipsystem; let's see how this goes.
 *
 * @author Nicke535
 */
public class loa_savior_ai implements ShipSystemAIScript {
    //Debug mode : when turned on, will print out the value of each valid spot each time it considers jumping offensively,
    //             and the risk of each spot each time it considers jumping defensively
    private static final boolean DEBUG_MODE = false;

    //Range of the system
    private static final float SYSTEM_RANGE = 3000f;

    //How often we check for AI conditions (min, max).
    private final IntervalUtil tracker = new IntervalUtil(0.55f, 1.05f);

    //Chance each interval [see above] that the system actually activates
    //      0.4f means it has a 40% to activate each time
    private static final float ACTIVATE_CHANCE = 0.4f;

    //How long we remember hull damage for the purposes of determining if we're in danger or not
    //      Needs to be longer than the tracker above to have ANY effect
    private static final float DAMAGE_REMEMBER_TIME = 2f;

    //How much hull damage must the ship take (either as an absolute value or a multiple of max hull) to be considered in danger?
    private static final float DAMAGE_DANGER_LEVEL_ABSOLUTE = 1000f;
    private static final float DAMAGE_DANGER_LEVEL_FRACTION = 0.2f;

    //What are the hardflux and softflux limits for the ship to be "in danger"?
    private static final float HARDFLUX_UNSAFE_LEVEL = 0.75f;
    private static final float SOFTFLUX_UNSAFE_LEVEL = 0.9f;

    //How long does the ship need to be at high soft/hard flux to be considered "in danger"?
    private static final float HARDFLUX_UNSAFE_TIME = 0.01f; //Don't set to 0!
    private static final float SOFTFLUX_UNSAFE_TIME = 3f;

    //How many times our DP must the enemy have for it to be considered "too risky" to jump?
    //  Works as a map, with different values for each captain personality
    private static final Map<String, Float> RISK_FACTOR_LIMIT_MAP = new HashMap<>();

    static {
        RISK_FACTOR_LIMIT_MAP.put(Personalities.RECKLESS, 40f);
        RISK_FACTOR_LIMIT_MAP.put(Personalities.AGGRESSIVE, 3f);
        RISK_FACTOR_LIMIT_MAP.put(Personalities.STEADY, 1.5f);
        RISK_FACTOR_LIMIT_MAP.put(Personalities.CAUTIOUS, 1.25f);
        RISK_FACTOR_LIMIT_MAP.put(Personalities.TIMID, 1f);
    }

    //Determines how many "steps" around a ship is checked for jump spots
    //      At 4, the cardinal directions are checked, at 8 southeast, southwest etc. are also included and so on
    //      Needs to be at least 1 to work
    private static final float AGGRESSIVE_DIRECTION_CHECK_FIDELITY = 8;

    //Determines how many steps around our own ship we check for defensive/escape jumps
    //      Works like the aggressive fidelity, but can be CONSIDERABLY higher since it's just one ship being checked
    private static final float ESCAPE_DIRECTION_CHECK_FIDELITY = 20f;

    //How much "value" does a spot need, at minimum, for a jump to be worthwhile?
    //      Expressed as a multiple of the Champion's DP
    private static final float MINIMUM_VALUE_TO_JUMP = 0.65f;

    //This is how much our current ship target's value is modified by, as a factor
    //      At above 1, we increase the effective value of jump spots related to our current ship target
    //      At below 1, we decrease it instead
    //      1f means that no special weight is added or removed to our current ship target
    private static final float TARGET_VALUE_FACTOR = 1f;

    //A constant determining the randomness of destination picking
    //      At 0f, ALL destinations that are worthwhile have the same chance of being picked
    //      At 2-3f, good destinations are considerably more likely to be picked than mediocre ones
    //      At 99f+ the best spot is practically guaranteed to be picked
    //      1f is the default value
    private static final float RANDOMNESS_EXPONENT_FACTOR = 85f;

    //We don't allow offensive jumps shorter than this if we're not losing the flux war (as defined by the stat below)
    private static final float MINIMUM_AGGRESSIVE_JUMP_RANGE = 1000f;

    //The factor for counting as "losing" (or at least not winning) the flux war, for the purpose of short-range jumps
    //      at 2f, you need twice the enemy's flux to count as losing, at 0.5f you need half the enemy's flux and so on
    private static final float FLUX_WAR_LOSS_FACTOR = 1.5f;

    //The ship never counts as loosing the flux war if it has less flux level than this, no matter how little the enemy has
    private static final float FLUX_WAR_LOSS_THRESHHOLD = 0.6f;

    //How large of a rear angle on an enemy counts as having "flanked them" for the purpose of calculating worthwhile spots?
    private static final float FLANKING_ANGLE = 125f;

    //How much larger will a target's value be if we flank them compared to if we don't?
    //      This is configurable per hullsize: flanking a frigate isn't really worthwhile and flanking a battleship is GREAT
    private static final Map<ShipAPI.HullSize, Float> FLANKING_VALUE_MULTIPLIERS = new HashMap<>();
    static {
        FLANKING_VALUE_MULTIPLIERS.put(ShipAPI.HullSize.FRIGATE, 1f);
        FLANKING_VALUE_MULTIPLIERS.put(ShipAPI.HullSize.DESTROYER, 1.1f);
        FLANKING_VALUE_MULTIPLIERS.put(ShipAPI.HullSize.CRUISER, 1.25f);
        FLANKING_VALUE_MULTIPLIERS.put(ShipAPI.HullSize.CAPITAL_SHIP, 1.5f);
    }

    //Multiplier for the DP value of Phase ships, for the purpose of calculating "valueable" jump spots
    private static final float PHASE_SHIP_VALUE_MULT = 0.5f;

    //The ship will wait for this many seconds after meeting an enemy ship before being allowed to actually make any offensive jumps
    private static final float WAIT_TIME_AFTER_FIRST_ENCOUNTER = 10f;


    //Utility in-script variables
    private ShipAPI ship;
    private ShipSystemAPI system;
    private ShipwideAIFlags flags;
    private CombatEngineAPI engine;
    private SharedSaviourData sharedData;
    private List<DamageData> damageData = new LinkedList<>();
    private float lastFrameHullLevel = 1f;
    private float timeInHighHardflux = 0f;
    private float timeInHighSoftflux = 0f;
    private ShipAPI currentShipJumpTarget = null;
    private float timeSinceInitialEncounter = 0f;


    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.system = system;
        this.flags = flags;
        this.engine = engine;
        this.sharedData = (SharedSaviourData) engine.getCustomData().get(this.getClass().getCanonicalName() + "shared_data_key");
        if (sharedData == null) {
            this.sharedData = new SharedSaviourData();
            engine.getCustomData().put(this.getClass().getCanonicalName() + "shared_data_key", this.sharedData);
        }
    }

    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        //Cleanup and return if we're dead
        if (!ship.isAlive()) {
            sharedData.reservedSpots.remove(ship);
            return;
        }

        //Ignore paused time
        if (engine.isPaused()) {
            return;
        }

        //If we are close to any enemy, tick up our initial encounter timer
        if (ship.areAnyEnemiesInRange()) {
            timeSinceInitialEncounter += amount;
        }

        //Ticks down and cleans damage data
        List<DamageData> toRemove = new LinkedList<>();
        for (DamageData data : damageData) {
            data.lifetime -= amount;
            if (data.lifetime < 0f) {
                toRemove.add(data);
            }
        }
        for (DamageData data : toRemove) {
            damageData.remove(data);
        }

        //Registers damage data for this frame
        if (ship.getHullLevel() < lastFrameHullLevel) {
            damageData.add(new DamageData((lastFrameHullLevel - ship.getHullLevel()) * ship.getMaxHitpoints(), DAMAGE_REMEMBER_TIME));
        }
        lastFrameHullLevel = ship.getHullLevel();

        //Registers flux data
        if (ship.getFluxLevel() > HARDFLUX_UNSAFE_LEVEL) {
            timeInHighHardflux += amount;
        } else {
            timeInHighHardflux = 0f;
        }
        if (ship.getFluxLevel() > SOFTFLUX_UNSAFE_LEVEL) {
            timeInHighSoftflux += amount;
        } else {
            timeInHighSoftflux = 0f;
        }

        //Unreserve our jump spot if we are currently not using our system
        if (!system.isActive() && system.getEffectLevel() <= 0f) {
            unreserveSpot();
        }

        //If the system is currently active, always "lock in" our ship target
        //Also store to a special variable so our system script can use that
        if (system.isActive() || system.getEffectLevel() > 0f) {
            ship.setShipTarget(currentShipJumpTarget);
            engine.getCustomData().put("LOA_SAVIOR_AI_TARGET_KEY" + ship.getId(), currentShipJumpTarget);
        } else {
            currentShipJumpTarget = null;
            engine.getCustomData().remove("LOA_SAVIOR_AI_TARGET_KEY" + ship.getId());
        }

        //Don't run jump checks if we can't use the system
        if (!AIUtils.canUseSystemThisFrame(ship) || system.getEffectLevel() > 0f) {
            return;
        }

        //Check if the AI is screaming at us to back off : if it is, or we are in too much danger, switch
        //to checking for escape jumps instead of aggressive ones
        if (flags.hasFlag(ShipwideAIFlags.AIFlags.IN_CRITICAL_DPS_DANGER)
                || shipIsInDanger()) {
            advanceEscape(amount, target);
            if (DEBUG_MODE) {
                engine.addFloatingText(ship.getLocation(), "WE ARE IN DANGER : HF time " + timeInHighHardflux + ", SF time " + timeInHighSoftflux,
                        50f, Color.GREEN, ship, 1f, 3f);
            }
        } else {
            //Wait for interval elapse before doing any proper checks for offensive jumps
            //      Also have a chance to not activate randomly, to seem more organic
            //      ALSO don't make offensive jumps until we've been near enemies for a little while
            tracker.advance(amount);
            if (tracker.intervalElapsed() && Math.random() < ACTIVATE_CHANCE && timeSinceInitialEncounter >= WAIT_TIME_AFTER_FIRST_ENCOUNTER) {
                advanceAggressive(amount, target);
            }
        }
    }

    //Advance loop for aggresive jumps
    private void advanceAggressive(float amount, ShipAPI shipTarget) {
        //We need this later
        float weaponEffectiveRange = getLongestWeaponRange(ship);

        //Find all enemy ships within jump range (with a bit extra, since we can jump in front of them), and calculate some potential jump sites from those
        List<JumpSpotData> potentialJumpSpots = new LinkedList<>();
        for (ShipAPI otherShip : CombatUtils.getShipsWithinRange(ship.getLocation(), SYSTEM_RANGE * 1.5f)) {
            //Ignore allies, dead ships and fighters
            if (!otherShip.isAlive() || otherShip.getOwner() == ship.getOwner() || otherShip.getHullSize().equals(ShipAPI.HullSize.FIGHTER)) {
                continue;
            }

            //Iterate over spots and add them to the list of potential spots if they are valid
            for (float angle = (otherShip.getFacing() + 180f); angle < (360f + otherShip.getFacing() + 180f); angle += (360f / AGGRESSIVE_DIRECTION_CHECK_FIDELITY)) {
                float radius = 0f;
                Vector2f spotToCheck = MathUtils.getPoint(otherShip.getLocation(), radius, angle);
                while (MathUtils.getDistance(spotToCheck, ship.getLocation()) < SYSTEM_RANGE    //In system range
                        && radius < weaponEffectiveRange) {                                     //In weapon range
                    if (isSpotValid(spotToCheck)) {
                        //Note that we have no value yet; we do that next step
                        // ADDITION 04/06-2020 : We only pick the closest valid spot in each direction to count as a potential spot
                        potentialJumpSpots.add(new JumpSpotData(0f, new Vector2f(spotToCheck), otherShip));
                        break;
                    }
                    radius += ship.getCollisionRadius() * 0.5f; //This could be changed to be slightly more accurate?
                    spotToCheck = MathUtils.getPoint(otherShip.getLocation(), radius, angle);
                }
            }
        }

        //Now that we have the potential jump spots, go through them all and calculate their value and risk factors
        //      Any spot with risk higher than what our current captain would allow don't have any chance of getting picked,
        //      neither does spots with lower value than we want to jump to
        WeightedRandomPicker<JumpSpotData> worthwhileSpots = new WeightedRandomPicker<>();
        for (JumpSpotData data : potentialJumpSpots) {
            if (isSpotSafe(data.spot)) {
                data.valueFactor = getSpotValue(data.spot);
                if (data.target == shipTarget) {
                    data.valueFactor *= TARGET_VALUE_FACTOR;
                }
                if (data.valueFactor > MINIMUM_VALUE_TO_JUMP) {
                    //Now that we've determined that it's worthwhile and safe, add to our random picker so we can pick one at random later
                    worthwhileSpots.add(data, (float) Math.pow(data.valueFactor, RANDOMNESS_EXPONENT_FACTOR));
                    if (DEBUG_MODE) {
                        engine.addFloatingText(data.spot, "" + data.valueFactor, 20f, Color.YELLOW, null, 0.5f, 1f);
                    }
                }
            }
        }

        //Were any spots worthwhile? If not, just return and do nothing
        if (worthwhileSpots.isEmpty()) {
            return;
        }

        //Now, pick one spot at random, weighted by its value, and set that as destination
        JumpSpotData destination = worthwhileSpots.pick();

        //Check if this is a short jump: if it is, we treat it as a mid-fight jump and only allow it if we're losing the flux war
        if (MathUtils.getDistance(destination.spot, ship.getLocation()) < MINIMUM_AGGRESSIVE_JUMP_RANGE) {
            if (ship.getFluxLevel() < shipTarget.getFluxLevel() * FLUX_WAR_LOSS_FACTOR
                    || ship.getFluxLevel() <= FLUX_WAR_LOSS_THRESHHOLD) {
                //If we fail this check, we wait a bit longer than usual to check for a new opportunity
                tracker.setElapsed(-tracker.getMaxInterval() * 2f);
                if (DEBUG_MODE) {
                    engine.addFloatingText(destination.spot, "We decided not to jump since we feel good staying here", 30f, Color.GREEN, ship, 0.5f, 2f);
                }
                return;
            }
        }

        currentShipJumpTarget = destination.target;
        useSystemOnLocation(destination.spot);
    }

    //Advance loop for defensive "escape" jumps
    private void advanceEscape(float amount, ShipAPI shipTarget) {
        //Finds spots around our ship and calculates which spot has the least risk factor
        //      For equal risk, prioritize jump range. For equal in both those regards, get as close to our own deploy side as possible
        JumpSpotData bestSpot = null;
        float radius = SYSTEM_RANGE;
        while (radius > ship.getCollisionRadius()) {
            for (float angle = 0f; angle < 360f; angle += (360f / ESCAPE_DIRECTION_CHECK_FIDELITY)) {
                Vector2f spotToCheck = MathUtils.getPoint(ship.getLocation(), radius, angle);
                if (isSpotValid(spotToCheck)) {
                    //Note that in this case, we treat "valueFactor" as "riskFactor"
                    float riskForSpot = getSpotRiskFactor(spotToCheck);
                    JumpSpotData newSpot = new JumpSpotData(riskForSpot, spotToCheck, null);
                    if (bestSpot == null) {
                        bestSpot = newSpot;
                    } else if (newSpot.valueFactor < bestSpot.valueFactor) {
                        bestSpot = newSpot;
                    } else if (newSpot.valueFactor == bestSpot.valueFactor) {
                        //Where we want to go depends on if we're the player or the enemy and our fleetgoal
                        float desiredDirection = engine.getFleetManager(ship.getOwner()).equals(engine.getFleetManager(FleetSide.PLAYER)) ? -1f : 1f;
                        if (engine.getFleetManager(ship.getOwner()).getGoal().equals(FleetGoal.ESCAPE)) {
                            desiredDirection *= -1f;
                        }
                        if (newSpot.spot.y * desiredDirection > bestSpot.spot.y * desiredDirection) {
                            bestSpot = newSpot;
                        }
                    }

                    if (DEBUG_MODE) {
                        Global.getCombatEngine().addFloatingText(newSpot.spot, "" + newSpot.valueFactor,
                                20f, Color.RED, null, 0.5f, 1f);
                    }
                }
            }
            radius -= ship.getCollisionRadius(); //This could be changed to be slightly more accurate?
        }

        //Of course, only activate if we found ANY spot
        if (bestSpot != null) {
            useSystemOnLocation(bestSpot.spot);
        }
    }

    //Checks if the ship is in danger, that is, if it has too much flux or has taken critical damage
    private boolean shipIsInDanger() {
        //Damage
        float damageTaken = 0f;
        for (DamageData data : damageData) {
            damageTaken += data.damage;
        }
        if (damageTaken > DAMAGE_DANGER_LEVEL_ABSOLUTE
                || damageTaken / (damageTaken + (ship.getHullLevel() * ship.getMaxHitpoints())) >= DAMAGE_DANGER_LEVEL_FRACTION) {
            return true;
        }

        //Flux
        if (timeInHighHardflux >= HARDFLUX_UNSAFE_TIME
                || timeInHighSoftflux >= SOFTFLUX_UNSAFE_TIME) {
            return true;
        }

        return false;
    }

    //Checks whether a spot is a valid landing site or not
    private boolean isSpotValid(Vector2f spot) {
        //First of all check if the spot is in range
        if (MathUtils.getDistance(spot, ship.getLocation()) > SYSTEM_RANGE) {
            return false;
        }

        //Then check for existing entities near the destination...
        List<ShipAPI> ships = CombatUtils.getShipsWithinRange(spot, ship.getCollisionRadius());
        for (ShipAPI potentialCollision : ships) {
            if (potentialCollision.getHullSize().equals(ShipAPI.HullSize.FIGHTER) || ship.equals(potentialCollision)) {
                continue;
            }
            if (MathUtils.getDistance(potentialCollision.getLocation(), spot) - ship.getCollisionRadius() - ship.getCollisionRadius() <= 0f) {
                return false;
            }
        }

        //...and any reservation that would collide with us
        for (Vector2f reservation : sharedData.reservedSpots.values()) {
            if (MathUtils.getDistance(reservation, spot) - (ship.getCollisionRadius() * 2f) <= 0f) {
                return false;
            }
        }
        return true;
    }

    //Checks if a spot is safe enough to jump to
    private boolean isSpotSafe(Vector2f spot) {
        float allowedRiskFactor = RISK_FACTOR_LIMIT_MAP.get(Personalities.STEADY);
        if (ship.getCaptain() != null) {
            allowedRiskFactor = RISK_FACTOR_LIMIT_MAP.get(ship.getCaptain().getPersonalityAPI().getId());
        }
        return getSpotRiskFactor(spot) <= allowedRiskFactor;
    }

    //Returns how much "risk factor" a spot has (this is effectively enemy DP / friendly DP)
    private float getSpotRiskFactor(Vector2f spot) {
        //Get all enemies within a reasonable distance of the target location: weapons with more than 2500 range are
        //pretty much always going to be in range anyhow, and are most likely artillery of some sort
        List<ShipAPI> shipsNearby = CombatUtils.getShipsWithinRange(spot, 2500f);
        List<ShipAPI> enemiesInRange = new LinkedList<>();
        for (ShipAPI otherShip : shipsNearby) {
            //Don't care about allies, fighters or dead ships
            if (otherShip.getOwner() == ship.getOwner()
                    || otherShip.getHullSize().equals(ShipAPI.HullSize.FIGHTER)
                    || !otherShip.isAlive()) {
                continue;
            }

            //Only ships in weapon range of the target spot count
            if (MathUtils.getDistance(otherShip.getLocation(), spot) - ship.getCollisionRadius() <= getLongestWeaponRange(otherShip)) {
                enemiesInRange.add(otherShip);
            }
        }

        //For each enemy in range, check for nearby allies : any allies found there will be saved so we can count their
        //DP to our own later. Also add up the enemies' DP while we're at it
        HashSet<ShipAPI> allies = new HashSet<>();
        float enemyDP = 0f;
        for (ShipAPI enemy : enemiesInRange) {
            float dpMod = 1f;
            //We count stations as having half the normal DP, to help with making us less afraid of stations
            if (enemy.isStation() || enemy.isStationModule()) {
                dpMod = 0.5f;
            }
            enemyDP += enemy.getMutableStats().getSuppliesToRecover().getBaseValue() * dpMod;
            for (ShipAPI ally : AIUtils.getNearbyEnemies(enemy, 2500f)) {
                //Don't count fighters, dead ships, or ourselves
                if (ally.getHullSize().equals(ShipAPI.HullSize.FIGHTER) || !ally.isAlive() || ally == ship) {
                    continue;
                }
                if (MathUtils.getDistance(ally.getLocation(), enemy.getLocation()) - enemy.getCollisionRadius() <= getLongestWeaponRange(ally)) {
                    allies.add(ally);
                }
            }
        }

        //Go through the allies and add their DP to the ally DP
        float allyDP = ship.getMutableStats().getSuppliesToRecover().getBaseValue();
        for (ShipAPI ally : allies) {
            allyDP += ally.getMutableStats().getSuppliesToRecover().getBaseValue();
        }

        //And return
        return enemyDP / allyDP;
    }

    //Returns how much "value factor" a spot has (based on how many targets are in weapon range, and maybe their state?)
    private float getSpotValue(Vector2f spot) {
        //Get all enemies within a weapon range of the spot
        List<ShipAPI> shipsNearby = CombatUtils.getShipsWithinRange(spot, getLongestWeaponRange(ship));
        float totalEnemyDPInRange = 0f;
        for (ShipAPI otherShip : shipsNearby) {
            //Don't care about allies, fighters or dead ships
            if (otherShip.getOwner() == ship.getOwner()
                    || otherShip.getHullSize().equals(ShipAPI.HullSize.FIGHTER)
                    || !otherShip.isAlive()) {
                continue;
            }

            //The DP of an enemy counts as being higher when we're behind them (weighted by hullsize, since flanking a
            // frigate won't do much good but flanking a battleship can win you the battle)
            float valueFromThisShip = otherShip.getMutableStats().getSuppliesToRecover().getBaseValue();
            if (Math.abs(MathUtils.getShortestRotation(otherShip.getFacing(), VectorUtils.getAngle(otherShip.getLocation(), spot)))
                    >= 180f - (FLANKING_ANGLE / 2f)) {
                valueFromThisShip *= FLANKING_VALUE_MULTIPLIERS.get(otherShip.getHullSize());
                if (DEBUG_MODE) {
                    engine.addFloatingText(spot, "Flanking bonus!", 30f, Color.GREEN, ship, 0.5f, 2f);
                }
            }
            if (otherShip.getShield() != null && otherShip.getShield().getType().equals(ShieldAPI.ShieldType.PHASE)) {
                valueFromThisShip *= PHASE_SHIP_VALUE_MULT;
            }
            totalEnemyDPInRange += valueFromThisShip;
        }

        // Return the DP as a factor of the jumping ship's DP
        return (totalEnemyDPInRange) / (ship.getMutableStats().getSuppliesToRecover().getBaseValue());
    }

    //Points the ship's system target correctly and activates the system
    private void useSystemOnLocation(Vector2f loc) {
        if (AIUtils.canUseSystemThisFrame(ship) || system.getEffectLevel() > 0f) {
            ship.getAIFlags().setFlag(ShipwideAIFlags.AIFlags.SYSTEM_TARGET_COORDS, 1f, new Vector2f(loc));
            ship.getMouseTarget().set(loc.x, loc.y);
            ship.useSystem();
            //Also reserve the spot so no other system tries to jump to it
            reserveSpot(loc);

            if (DEBUG_MODE) {
                engine.addFloatingText(loc, "We've decided to jump here!", 30f, Color.GREEN, null, 0.5f, 5f);
            }
        }
    }

    //Shorthand for getting the longest (non-missile) weapon range on a ship
    private float getLongestWeaponRange(ShipAPI source) {
        //Go through all weapons, discard missiles, and return the highest range
        float maxRange = 0f;
        for (WeaponAPI wep : source.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE) {
                continue;
            }

            if (maxRange < wep.getRange()) {
                maxRange = wep.getRange();
            }
        }
        return maxRange;
    }

    //Un-reserves the ship's jump spot so others can jump there
    private void unreserveSpot() {
        sharedData.reservedSpots.remove(ship);
    }

    //Reserves a location so others won't jump to it
    private void reserveSpot(Vector2f spot) {
        sharedData.reservedSpots.put(ship, spot);
    }


    //Class keeping track of the shared data multiple saviors need to coordinate and avoid collisions
    private class SharedSaviourData {
        HashMap<ShipAPI, Vector2f> reservedSpots = new HashMap<>();
    }


    //Class for managing damage data (for danger calculation)
    private class DamageData {
        float damage;
        float lifetime;

        DamageData(float damage, float lifetime) {
            this.damage = damage;
            this.lifetime = lifetime;
        }
    }


    //Class for managing data about a potential jump spot
    private class JumpSpotData {
        float valueFactor;
        Vector2f spot;
        ShipAPI target;

        JumpSpotData(float valueFactor, Vector2f spot, ShipAPI target) {
            this.valueFactor = valueFactor;
            this.spot = spot;
            this.target = target;
        }
    }
}
