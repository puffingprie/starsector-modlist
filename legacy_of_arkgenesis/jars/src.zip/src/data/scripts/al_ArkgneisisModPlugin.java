
package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.procgen.Constellation;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import data.scripts.ai.al_siegemissile_ai;
import data.scripts.ai.loa_CanMissileAI;
import data.scripts.ai.loa_PDMissileAI;
import data.scripts.ai.loa_RodMissileAI;
import data.scripts.ai.loa_aoetorpedo_ai;
import data.scripts.ai.loa_asteroid_ai;
import data.scripts.ai.loa_conemissile_ai;
import data.scripts.campaign.*;
import data.scripts.campaign.intel.bar.events.ChampionBarEventCreator;
import data.scripts.campaign.intel.bar.events.loa_RevealMarketBarEventCreator;
//import data.world.LoA_AnarakaadConstellation;
//import data.world.LoA_AnarakaadConstellation.LoA_SystemLoc;
//import data.world.LoA_XSystem;
//import data.world.LoA_YSystem;
import data.world.al_magec;
import data.world.al_mayasura;
import data.world.al_yma;
import data.world.al_zagan;
import data.world.loa_anargaia;
import org.dark.shaders.light.LightData;
import org.dark.shaders.util.ShaderLib;
import org.dark.shaders.util.TextureData;
import exerelin.campaign.SectorManager;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;

public class al_ArkgneisisModPlugin extends BaseModPlugin
{
    public static final String SECTOR_AGE_KEY = "$LoA_sectorAge";
    public static final String SECTOR_SIZE_KEY = "$LoA_sectorSize";

    private transient static StarAge SECTOR_AGE = StarAge.AVERAGE;
    private transient static String SECTOR_SIZE = "small"; // Assume anything other than "small" is normal-sized
    
    
    //Custom Missile AIs
    public static final String SIEGE_MISSILE = "al_nuclear_cannon";
    public static final String ASTEROID_MISSILE = "loa_asteroid";
    public static final String ROD_MISSILE = "al_rod_mrm";
    public static final String CAN_MISSILE = "al_cone_missile";
    public static final String CAN_CAN = "loa_can_can";
    public static final String NEEDLE_MISSILE = "loa_needle_missile";
    public static final String MOSAIC_TORPEDO = "loa_mosaic_torpedo";
    
	
	//Loads in if we have Nexerelin or not; this is important for some later script checking
    public static final boolean isExerelin;
    static
    {
        boolean foundExerelin;
        if (Global.getSettings().getModManager().isModEnabled("nexerelin")) {
            foundExerelin = true;
		} else {
			foundExerelin = false;
		}
        isExerelin = foundExerelin;
    }

    @Override
    public void onApplicationLoad()
    {
        boolean hasLazyLib = Global.getSettings().getModManager().isModEnabled("lw_lazylib");
        if (!hasLazyLib)
        {
            throw new RuntimeException("Legacy of Arkgneisis requires LazyLib!"
                    + "\nGet it at http://fractalsoftworks.com/forum/index.php?topic=5444");
        }
        
        boolean hasMagicLib = Global.getSettings().getModManager().isModEnabled("MagicLib");
        if (!hasMagicLib)
        {
            throw new RuntimeException("Legacy of Arkgneisis requires MagicLib!"
                    + "\nGet it at http://fractalsoftworks.com/forum/index.php?topic=13718.0");
        }
        
        boolean hasShaderLib = Global.getSettings().getModManager().isModEnabled("shaderLib");
        if (!hasShaderLib)
        {
            throw new RuntimeException("Legacy of Arkgneisis requires GraphicsLib!"
                     + "\nGet it at http://fractalsoftworks.com/forum/index.php?topic=10982");
        }
        else
        {
            ShaderLib.init();
            LightData.readLightDataCSV("data/lights/al_light_data.csv");
            TextureData.readTextureDataCSV("data/lights/al_texture_data.csv");
        }

        try {
            loa_raid_economy.setupBlackAndWhitelist();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onNewGame()
    {
        SharedData.getData().getPersonBountyEventData().addParticipatingFaction("al_ars"); // Posts bounties
        initAnarakis();
        
//         SectorAPI sector = Global.getSector();
//        // Sector age and size are gotten using a rule command silently inserted into new game creation
//        sector.getMemoryWithoutUpdate().set(SECTOR_AGE_KEY, SECTOR_AGE);
//        sector.getMemoryWithoutUpdate().set(SECTOR_SIZE_KEY, SECTOR_SIZE);
//
//        // Place hand-made systems into a map to pass to the constellation generator
//        Map<StarSystemAPI, LoA_SystemLoc> anarakaadSystems = new HashMap<>();
//
//        StarSystemAPI s = LoA_XSystem.generate(sector);
//        LoA_SystemLoc loc = new LoA_SystemLoc(180f, 2000f); // angle, distance
//        anarakaadSystems.put(s, loc);
//
//        s = LoA_YSystem.generate(sector);
//        loc = new LoA_SystemLoc(0f, 3500f);
//        anarakaadSystems.put(s, loc);
//
//        Constellation constellar = LoA_AnarakaadConstellation.generate(sector, anarakaadSystems);
    }


    //We want to do this slightly after normal new game, to be sure all systems have had time to update their tags and such
    @Override
    public void onNewGameAfterTimePass() {
        loa_generatejunkteaserscript.spawnJunkTeasers(Global.getSector());
    }

    //To give Anargaia the correct administrator, it has to be added after economy startup, it seems
    @Override
    public void onNewGameAfterEconomyLoad() {
        MarketAPI market = Global.getSector().getEconomy().getMarket("loa_anargaia_station_market");
        if (market != null) {
            PersonAPI arkaranAGI = Global.getFactory().createPerson();
            arkaranAGI.setFaction("al_ars");
            arkaranAGI.setGender(FullName.Gender.MALE);
            arkaranAGI.setPostId(Ranks.POST_FACTION_LEADER);
            arkaranAGI.setRankId(Ranks.FACTION_LEADER);
            arkaranAGI.getName().setFirst(loa_anargaia.ADMIN_FIRST_NAME);
            arkaranAGI.getName().setLast(loa_anargaia.ADMIN_LAST_NAME);
            arkaranAGI.setPortraitSprite(loa_anargaia.ADMIN_PORTRAIT_PATH);

            arkaranAGI.getStats().increaseSkill(Skills.SPACE_OPERATIONS);
            arkaranAGI.getStats().increaseSkill(Skills.PLANETARY_OPERATIONS);
            arkaranAGI.getStats().increaseSkill(Skills.INDUSTRIAL_PLANNING);
            arkaranAGI.setAICoreId(Commodities.ALPHA_CORE);

            market.setAdmin(arkaranAGI);
        }
    }

    public void onGameLoad(boolean newGame) {
        Global.getSector().addTransientListener(new loa_PersistentUnlocker());
        addBarEvents();

        //On game load, we also remove all orbital junk in Anargaia: kessler syndrome begone!
        StarSystemAPI anargaia = Global.getSector().getStarSystem("Anargaia");
        if (anargaia != null) {
            for (SectorEntityToken junk : anargaia.getEntitiesWithTag(Tags.ORBITAL_JUNK)) {
                junk.getContainingLocation().removeEntity(junk);
            }
        }
        //Also, add a transient script to handle our Close Air Support fighters
        Global.getSector().addTransientScript(new loa_closeairsupportmanager());
    }

	protected void addBarEvents() {
        BarEventManager bar = BarEventManager.getInstance();
        if (!bar.hasEventCreator(ChampionBarEventCreator.class)) {
            bar.addEventCreator(new ChampionBarEventCreator());
        }
        if (!bar.hasEventCreator(loa_RevealMarketBarEventCreator.class)) {
            bar.addEventCreator(new loa_RevealMarketBarEventCreator());
        }
    }

    @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(MissileAPI missile, ShipAPI launchingShip)
    {
        switch (missile.getProjectileSpecId())
        {
            case SIEGE_MISSILE:
                return new PluginPick<MissileAIPlugin>(new al_siegemissile_ai(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SET);
            case ROD_MISSILE:
                return new PluginPick<MissileAIPlugin>(new loa_RodMissileAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SET);
            case ASTEROID_MISSILE:
                return new PluginPick<MissileAIPlugin>(new loa_asteroid_ai(missile), CampaignPlugin.PickPriority.MOD_SET);
            case CAN_MISSILE:
                return new PluginPick<MissileAIPlugin>(new loa_conemissile_ai(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SET);
            case CAN_CAN:
                return new PluginPick<MissileAIPlugin>(new loa_CanMissileAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SET);
            case NEEDLE_MISSILE:
                return new PluginPick<MissileAIPlugin>(new loa_PDMissileAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SET);
            case MOSAIC_TORPEDO:
                return new PluginPick<MissileAIPlugin>(new loa_aoetorpedo_ai(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SET);
            default:
                return null;
        }
    }

    private static void initAnarakis()
    {
        //Always add in our scripts
        Global.getSector().addScript(new loa_champblueprintscript());
        Global.getSector().addScript(new loa_campaign_relations_plugin());
        Global.getSector().addScript(new loa_adjust_markets_plugin());

        // Is this a standard game, or Nexerelin *not* Corvus mode?
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");  
        if (haveNexerelin && !SectorManager.getManager().isCorvusMode()) {
            return;
        }

        // Ok, then place our stations in vanilla star systems!
        new al_magec().generate(Global.getSector());
        new al_mayasura().generate(Global.getSector());
        new al_yma().generate(Global.getSector());
        new al_zagan().generate(Global.getSector());


        //Also add in our special station generation and the Capitol
        MarketAPI anarGaia = new loa_anargaia().generate(Global.getSector());
        Global.getSector().addScript(new loa_spawnRandomMarketsPlugin(anarGaia));
        Global.getSector().addScript(new loa_MarketRevealHandler());
    }
    
    public static void setSectorAge(StarAge sectorAge) {
        SECTOR_AGE = sectorAge;
    }

    public static void setSectorSize(String sectorSize) {
        SECTOR_SIZE = sectorSize;
    }
}
