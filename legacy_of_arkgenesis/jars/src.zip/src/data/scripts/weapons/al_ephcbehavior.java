//By Nicke535
//Spawns "hyperspace holes" which are later tracked by NicToyHyperspaceShotTracker
package data.scripts.weapons;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.plugins.al_HyperspaceShotTracker;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class al_ephcbehavior implements OnHitEffectPlugin {
    private static final float HOLE_DURATION = 0.5f;                            //How long does the hyperspace hole last before collapsing?
    private static final int BASE_ARC_COUNT = 1;                                //The number of EMP arcs we get as a base, without considering enemy armor
    private static final int BONUS_ARCS_FROM_ARMOR = 2;                         //The maximum amount of "bonus" EMP arcs we can get from the enemy having high remaining armor
    private static final Color HOLE_COLOR = new Color(155, 235, 255); //This is the color of the hyperspace hole while it is active and when detonating
    private static final float EXPLOSION_SIZE = 40f;                            //How big the explosion is when the hole collapses; purely visual
    private static final float PARTICLE_SIZE = 120f;                             //How big is the "extra particle" spawned during the explosion? This size also
    private static final float PARTICLE_DURATION = 0.4f;                        //How long does that extra particle last
    private static final float LIGHTNING_MIN_RANGE = 50f;                      //The minimum range past which our lightning spreads
    private static final float LIGHTNING_MAX_RANGE = 150f;                      //The maximum range to which our lightning spreads
    private static final float LIGHTNING_DAMAGE_PERCENT = 0.3f;                //Percentage of the projectile's damage that the lightning bolts deal. 0.3f would mean 30% of projectile damage per lightning bolt
    private static final float LIGHTNING_EMP_PERCENT = 0f;                    //Percentage of the projectile's damage that the lightning bolts deal as EMP. 0.3f would mean 30% of projectile EMP per lightning bolt

    @Override
    public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target, Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
        //Ignore shield hits, and if we *somehow* miss our target in an on-hit script, we'd rather skip the script than crash
        if (shieldHit || target == null) {
            return;
        }

        //Only spawn the hyperspace hole on ships
        if (target instanceof ShipAPI) {
            ShipAPI ship = (ShipAPI)target;
            ArmorGridAPI aGrid = ship.getArmorGrid();

            //This is our armor percentage (so between 0f and 1f) for hit-calculation in the target point
            float armorValue = 0f;

            //First, we get the original hit grid cell and its armor value
            int[] originalCell = ship.getArmorGrid().getCellAtLocation(point);
            armorValue += aGrid.getArmorFraction(originalCell[0], originalCell[1]);

            //Then, we try and find the directly-adjacent locations
            for (int ix = -1; ix < 2; ix++) {
                for (int iy = -1; iy < 2; iy++) {
                    //This is if we found the central armor grid... we don't take that one into consideration, we checked it earlier
                    if (ix == 0 && iy == 0) {
                        continue;
                    }

                    //Otherwise, get the armor value of the current cell
                    armorValue += aGrid.getArmorFraction(originalCell[0]+ix, originalCell[1]+iy);
                }
            }

            //After that, we find the remote locations; these run with slightly less beautiful code, but are otherwise similar.
            //  Note, however, that they only count half of their armor for damage calculation; this is the vanilla behaviour
            //Top/bottom grid pieces
            for (int ix = -1; ix < 2; ix++) {
                armorValue += aGrid.getArmorFraction(originalCell[0]+ix, originalCell[1]+2)/2f;
                armorValue += aGrid.getArmorFraction(originalCell[0]+ix, originalCell[1]-2)/2f;
            }
            //Right/left grid pieces
            for (int iy = -1; iy < 2; iy++) {
                armorValue += aGrid.getArmorFraction(originalCell[0]+2, originalCell[1]+iy)/2f;
                armorValue += aGrid.getArmorFraction(originalCell[0]-2, originalCell[1]+iy)/2f;
            }

            //Finally, we divide the value by 15 to get an average over all of the cells (9 * 1 + 12 * 0.5 = 15)
            armorValue /= 15f;

            //Then, we add our huperspace hole to the tracker
            al_HyperspaceShotTracker.addHyperspaceHole(HOLE_DURATION, point, BASE_ARC_COUNT + (int)(BONUS_ARCS_FROM_ARMOR*armorValue), HOLE_COLOR,
                    EXPLOSION_SIZE, HOLE_COLOR,PARTICLE_SIZE,PARTICLE_DURATION,LIGHTNING_MAX_RANGE, LIGHTNING_MIN_RANGE, LIGHTNING_DAMAGE_PERCENT*projectile.getDamageAmount(),
                    LIGHTNING_EMP_PERCENT * projectile.getDamageAmount(), (ShipAPI)target);
        }
    }
}
