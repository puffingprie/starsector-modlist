package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.combat.*;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Base type for an ammo-swapper gun script: can be extended to change behaviour easily between several similar weapons
 * @author Nicke535
 */
public class loa_BaseAmmoSwapperGunScript implements EveryFrameWeaponEffectPlugin {
    //--Stats below: note that muzzle flashes are definted as multipliers from a base value, so play around a bit with them--//
    //Stats for the type-1 (HE) shot
    protected ReplacementStatSheet getType1Stats() {
        return new ReplacementStatSheet(
                "hellbore",
                0f,
                0f);
    }

    //Stats for the type-2 (Kinetic) shot
    protected ReplacementStatSheet getType2Stats() {
        return new ReplacementStatSheet(
                "gauss",
                0f,
                0f);
    }

    //Internal script stuff
    private List<DamagingProjectileAPI> registeredProjectiles = new ArrayList<DamagingProjectileAPI>();


    //Does nothing by default
    protected void handleAnimation(WeaponAPI weapon, int activeAmmoType, float swapTimeRemaining) {
        return;
    }

    //By default, only prevents the weapon from firing while swapping ammo type
    protected void handleExtraEffects(WeaponAPI weapon, int activeAmmoType, float swapTimeRemaining) {
        if (weapon.getCooldownRemaining() < swapTimeRemaining) {
            weapon.setRemainingCooldownTo(Math.max(weapon.getCooldownRemaining(), swapTimeRemaining));
        }
    }

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        ShipAPI ship = weapon.getShip();

        Object ammoSwapperTimeRemaining = engine.getCustomData().get("loa_AmmoSwapperSwapTimeRemaining" + ship.getId());
        if (ammoSwapperTimeRemaining instanceof Float) {
            //Handles animation
            handleAnimation(weapon, ship.getSystem().getAmmo(), (float)ammoSwapperTimeRemaining);

            //Handles other effects that might be relevant depending on mode
            handleExtraEffects(weapon, ship.getSystem().getAmmo(), (float)ammoSwapperTimeRemaining);
        }


        //Clean up projectiles that are no longer loaded in memory
        List<DamagingProjectileAPI> cleanList = new ArrayList<>();
        for (DamagingProjectileAPI proj : registeredProjectiles) {
            if (!engine.isEntityInPlay(proj)) {
                cleanList.add(proj);
            }
        }
        for (DamagingProjectileAPI proj : cleanList) {
            registeredProjectiles.remove(proj);
        }

        //Finds all projectiles within a a short range from our weapon
        for (DamagingProjectileAPI proj : CombatUtils.getProjectilesWithinRange(weapon.getLocation(), 200f)) {
            //Saves some memory, and makes the rest of the code slightly more compact, while also ignoring anything not from our weapon
            if (proj.getProjectileSpecId() == null || proj.getWeapon() != weapon || registeredProjectiles.contains(proj) || !engine.isEntityInPlay(proj)) {
                continue;
            }

            //Only dummy shots are swapped
            if (proj.getProjectileSpecId().contains("loa_nickeshot_dummy")) {
                //Stores the data all swapped shots need anyway
                Vector2f loc = proj.getLocation();
                float projAngle = proj.getFacing();
                float projDamage = proj.getDamageAmount();
                ReplacementStatSheet repStats = getType1Stats();
                if (ship.getSystem().getAmmo() == 2) {
                    repStats = getType2Stats();
                }

                //Spawns the shot, with some inaccuracy
                float angleOffset = MathUtils.getRandomNumberInRange(-repStats.inaccuracy / 2, repStats.inaccuracy / 2) + MathUtils.getRandomNumberInRange(-repStats.inaccuracy / 2, repStats.inaccuracy / 2);
                DamagingProjectileAPI newProj = (DamagingProjectileAPI)engine.spawnProjectile(ship, weapon, repStats.weaponName, loc, projAngle + angleOffset, ship.getVelocity());
                //Varies the speed very slightly, for a more artillery-esque look
                float rand = MathUtils.getRandomNumberInRange(1-repStats.speedVariation, 1+repStats.speedVariation);
                newProj.getVelocity().x *= rand;
                newProj.getVelocity().y *= rand;
                //Removes the original projectile
                engine.removeEntity(proj);
                registeredProjectiles.add(newProj);
            }
        }
    }

    protected class ReplacementStatSheet {
        protected final String weaponName;
        protected final float inaccuracy;
        protected final float speedVariation;

        protected ReplacementStatSheet(String weaponName, float inaccuracy, float speedVariation) {
            this.weaponName = weaponName;
            this.inaccuracy = inaccuracy;
            this.speedVariation = speedVariation;
        }
    }
}
