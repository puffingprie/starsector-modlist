package data.scripts.weapons.gigaton;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.SettingsAPI;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles the beam-related behaviour of the Gigaton Lance
 * NOTE: this assumes that the Gigaton Lance is mounted in a turret, and not a hardpoint or hidden slot. If you
 *       want support for that too, just ask me and I'll add it in
 * @author Nicke535
 */
public class loa_GigatonLanceWeaponBeamBehaviour implements EveryFrameWeaponEffectPlugin {
    //ADDITION 10/7 2020
    //The loop sound to play when the weapon is firing, if the player is close enough to see the beam
    //      I'd recommend turning off vanilla's loop sound if using this since it'll pretty much be the same result but
    //      worse and only when the gun is visible
    private static final String FIRE_LOOP_SOUND = "loa_gigaton_beam";

    //Damage bonus for armor-reduction purposes. Helpful due to the nature of having a whole bunch of small beams
    //50f means 50% increase of damage for armor-reduction purposes
    //ONLY works if this is the only weapon on the ship.
    private static final float ANTI_ARMOR_BONUS = 2000f;

    //The dispersal cone at max fire-chargeup: this shrinks as the beams get thinner
    private static final float MAX_DISPERSAL_ANGLE = 1f;

    //The color in the center and fringe of the meta-beam: each individual beam is assumed to be mono-colored, to not
    // give away the effect too much. Remember that the beam will still look pretty much white near the muzzle due to
    // additive color blending on beams
    private static final Color CENTER_COLOR = Color.white;
    private static final Color FRINGE_COLOR = new Color(1f, 0.5f, 0f, 0f);

    //String key for managing the range penalty on the gun while it's on cooldown
    private static final String RANGE_PENALTY_KEY = "loa_gigaton_lance_cooldown";

    //String key for managing the damage bonus of the beam to armor
    private static final String ARMOR_EFFECTIVENESS_KEY = "loa_gigaton_lance_antiarmor_bonus";

    //String key for storing charge level data (it's wierd due to being a burst beam)
    public static final String CHARGELEVEL_DATA_KEY = "loa_gigaton_lance_cooldown";


    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        //Always apply damage mult bonus
        weapon.getShip().getMutableStats().getHitStrengthBonus().modifyPercent(ARMOR_EFFECTIVENESS_KEY, ANTI_ARMOR_BONUS);

        //Check if we're firing the weapon: if we aren't, manage its range (and custom data) but nothing more
        if (!weapon.isFiring()) {
            //Adjust the weapon's range to zero if we are on cooldown: we are assumed to be the only beam weapon on the ship
            if (weapon.getCooldownRemaining() > 0f) {
                weapon.getShip().getMutableStats().getBeamWeaponRangeBonus().modifyMult(RANGE_PENALTY_KEY, 0.001f);
            } else {
                weapon.getShip().getMutableStats().getBeamWeaponRangeBonus().unmodify(RANGE_PENALTY_KEY);
            }

            return;
        }

        //Get all the beams that belong to this gun and put them in a list
        List<BeamAPI> beams = new ArrayList<>();
        for (BeamAPI beam : engine.getBeams()) {
            if (beam.getWeapon() == weapon) {
                beams.add(beam);
            }
        }

        //If we didn't find any beams, or just one beam, return
        if (beams.isEmpty() || beams.size() == 1f) {
            return;
        }

        //Calculate dispersal angle for the current frame. Also store charge level data for other scripts
        float chargeLevel = beams.get(0).getBrightness();
        float dispersalAngle = MAX_DISPERSAL_ANGLE*chargeLevel;

        //And now for the big part: adjust each turret angle offset and beam color depending on where in the list
        // they are (this corresponds to their location in the offset list)
        weapon.ensureClonedSpec();
        for (int i = 0; i < beams.size(); i++) {
            float progress = (0.5f - (i / (beams.size()-1f))) * 2f; //Goes from 1f to -1f, with 0f being center
            weapon.getSpec().getTurretAngleOffsets().set(i, progress * (dispersalAngle/2f));
            Color colorForThisBeam = Misc.interpolateColor(CENTER_COLOR, FRINGE_COLOR, Math.abs(progress));
            beams.get(i).setCoreColor(colorForThisBeam);
            beams.get(i).setFringeColor(colorForThisBeam);
        }

        //Checks the two outmost beams and get their closest position to the sound listener
        Vector2f listenerPos = Global.getSoundPlayer().getListenerPos();
        Vector2f pos1 = Misc.closestPointOnSegmentToPoint(beams.get(0).getFrom(), beams.get(0).getTo(), listenerPos);
        Vector2f pos2 = Misc.closestPointOnSegmentToPoint(beams.get(0).getFrom(), beams.get(0).getTo(), listenerPos);
        Vector2f closestSoundPos = pos1;
        if (MathUtils.getDistance(pos2, listenerPos) < MathUtils.getDistance(pos1, listenerPos)) {
            closestSoundPos = pos2;
        }
        Global.getSoundPlayer().playLoop(FIRE_LOOP_SOUND, weapon.getShip(), 1f, chargeLevel, closestSoundPos, Misc.ZERO);
    }
}
