//By Nicke535, this script allows a beam weapon to fire from alternating barrels
//NEW VERSION: also spawns muzzle flashes (originally by MesoTroniK, as far as i know) and supports multiple alternating beams, while removing some unecessary features
package data.scripts.weapons;

import com.fs.starfarer.api.combat.*;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class al_plasmadriveralternator implements EveryFrameWeaponEffectPlugin {
    //These two maps are for setting the "actual" offsets of the weapon: the position of the offsets in the .wpn file are ignored, only the amount of offsets matter
    private static final Map<Integer, Vector2f> HARDPOINT_OFFSETS = new HashMap<Integer, Vector2f>();
    static {
        HARDPOINT_OFFSETS.put(0, new Vector2f(29f, -4.5f));
        HARDPOINT_OFFSETS.put(1, new Vector2f(29f, 4.5f));
    }
    private static final Map<Integer, Vector2f> TURRET_OFFSETS = new HashMap<Integer, Vector2f>();
    static {
        TURRET_OFFSETS.put(0, new Vector2f(25f, -4.5f));
        TURRET_OFFSETS.put(1, new Vector2f(25f, 4.5f));
    }

    //Muzzle flash specifications go here
    private static final Color MUZZLE_FLASH_COLOR = new Color(150, 150, 255, 255);
    private static final float MUZZLE_FLASH_DURATION = 1f;
    private static final float MUZZLE_FLASH_SIZE = 0.01f;

    //Instantiates variables we will use later
    private int counter = 0;
    private boolean runOnce = true;
    private float lastChargeLevel = 0.0f;
    private float lastCooldownRemaining = 0.0f;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        //Don't run if we are paused, or our if weapon is null
        if (engine.isPaused() || weapon == null) {
            return;
        }

        //When we are firing, reset our runOnce variable so we know we have started firing again
        float chargeLevel = weapon.getChargeLevel();
        if (chargeLevel > 0) {
            runOnce = true;
        }

        //Code for rendering a muzzle flash for each beam
        float cooldownRemaining = weapon.getCooldownRemaining();
        if (chargeLevel > lastChargeLevel || lastCooldownRemaining < cooldownRemaining) {
            Vector2f weaponLocation = new Vector2f(weapon.getLocation().x, weapon.getLocation().y);
            ShipAPI ship = weapon.getShip();
            Vector2f shipVelocity = ship.getVelocity();
            //Runs once for each offset, and only run for the type of turret we have
            if (weapon.getSlot().isHardpoint()) {
                for (int i = 0; i < weapon.getSpec().getHardpointFireOffsets().size(); i++) {
                    //Gets our location for the muzzle flash
                    Vector2f muzzleLocation = weaponLocation;
                    muzzleLocation.y += weapon.getSpec().getHardpointFireOffsets().get(i).y; //Somewhat misleading, since the weapon is turned 90 degrees "incorrectly" when considering coordinates
                    muzzleLocation.x += weapon.getSpec().getHardpointFireOffsets().get(i).x;
                    muzzleLocation = VectorUtils.rotateAroundPivot(muzzleLocation, weapon.getLocation(), weapon.getCurrAngle(), weapon.getLocation());

                    //And then add the muzzle flash, if we should
                    if (chargeLevel > lastChargeLevel) {
                        engine.spawnExplosion(muzzleLocation, shipVelocity, MUZZLE_FLASH_COLOR, MUZZLE_FLASH_SIZE, MUZZLE_FLASH_DURATION);
                    }
                }
            } else if (weapon.getSlot().isTurret()) {
                for (int i = 0; i < weapon.getSpec().getTurretFireOffsets().size(); i++) {
                    //Gets our location for the muzzle flash
                    Vector2f muzzleLocation = weaponLocation;
                    muzzleLocation.y += weapon.getSpec().getTurretFireOffsets().get(i).y; //Somewhat misleading, since the weapon is turned 90 degrees "incorrectly" when considering coordinates
                    muzzleLocation.x += weapon.getSpec().getTurretFireOffsets().get(i).x;
                    muzzleLocation = VectorUtils.rotateAroundPivot(muzzleLocation, weapon.getLocation(), weapon.getCurrAngle(), weapon.getLocation());

                    //And then add the muzzle flash, if we should
                    if (chargeLevel > lastChargeLevel) {
                        engine.spawnExplosion(muzzleLocation, shipVelocity, MUZZLE_FLASH_COLOR, MUZZLE_FLASH_SIZE, MUZZLE_FLASH_DURATION);
                    }
                }
            } else {
                for (int i = 0; i < weapon.getSpec().getHiddenFireOffsets().size(); i++) {
                    //Gets our location for the muzzle flash
                    Vector2f muzzleLocation = weaponLocation;
                    muzzleLocation.y += weapon.getSpec().getHiddenFireOffsets().get(i).x; //Somewhat misleading, since the weapon is turned 90 degrees "incorrectly" when considering coordinates
                    muzzleLocation.x += weapon.getSpec().getHiddenFireOffsets().get(i).y;
                    muzzleLocation = VectorUtils.rotateAroundPivot(muzzleLocation, weapon.getLocation(), weapon.getCurrAngle(), weapon.getLocation());

                    //And then add the muzzle flash, if we should
                    if (chargeLevel > lastChargeLevel) {
                        engine.spawnExplosion(muzzleLocation, shipVelocity, MUZZLE_FLASH_COLOR, MUZZLE_FLASH_SIZE, MUZZLE_FLASH_DURATION);
                    }
                }
            }
        }
        //Finally, adjust our previous-frame variables
        lastChargeLevel = chargeLevel;
        lastCooldownRemaining = cooldownRemaining;

        //Once we stop firing, switch our beams one step along our list of offsets
        if (weapon.getChargeLevel() <= 0f && runOnce) {
            runOnce = false;

            //Here's where the magic happens: get our next fire position, and switch our beam over to that one.
            //Runs once per offset in the original weapon file. Uses different fire positions depending on if we are a turret or hardpoint
            counter++;
            for (int i = 0; i < weapon.getSpec().getHardpointFireOffsets().size(); i++) {
                int tempI = counter + i;
                while (HARDPOINT_OFFSETS.get(tempI) == null) {
                    tempI -= HARDPOINT_OFFSETS.size();
                }
                weapon.getSpec().getHardpointFireOffsets().set(i, HARDPOINT_OFFSETS.get(tempI));
            }
            for (int i = 0; i < weapon.getSpec().getTurretFireOffsets().size(); i++) {
                int tempI = counter + i;
                while (TURRET_OFFSETS.get(tempI) == null) {
                    tempI -= TURRET_OFFSETS.size();
                }
                weapon.getSpec().getTurretFireOffsets().set(i, TURRET_OFFSETS.get(tempI));
            }
            for (int i = 0; i < weapon.getSpec().getHiddenFireOffsets().size(); i++) {
                int tempI = counter + i;
                while (TURRET_OFFSETS.get(tempI) == null) {
                    tempI -= TURRET_OFFSETS.size();
                }
                weapon.getSpec().getHiddenFireOffsets().set(i, TURRET_OFFSETS.get(tempI));
            }
        }
    }
}
