//By Nicke535
//Spawns "hyperspace holes" which are later tracked by NicToyHyperspaceShotTracker
package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.plugins.loa_hyperspace_tracker_small;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class loa_hypercannon_onhit implements OnHitEffectPlugin {
    private static final float HOLE_DURATION = 0.3f;                            //How long does the hyperspace hole last before collapsing?
    private static final String SOUND_EFFECT = "loa_warprift_suck";                //ID for the sound when a hyperspace hole is generated
    private static final float DAMAGE_MULT = 0.33f;                             //Percentage of projectile damage dealt once the hole detonates (1f = 100%)


    @Override
    public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target, Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
        //If we *somehow* miss our target in an on-hit script, we'd rather skip the script than crash
        if (target == null || shieldHit) {
            return;
        }

        //Only spawn the hyperspace hole on ships
        if (target instanceof ShipAPI) {
            ShipAPI ship = (ShipAPI)target;

            //Always spawn a sound effect when a hole is generated
            Global.getSoundPlayer().playSound(SOUND_EFFECT, 1f, 1f, point, ship.getVelocity());

            //Otherwise, we add our hyperspace hole to the tracker with damage
            loa_hyperspace_tracker_small.addHyperspaceHole(HOLE_DURATION, point, projectile.getDamageAmount() * DAMAGE_MULT, (ShipAPI)target);
        }
    }
}
