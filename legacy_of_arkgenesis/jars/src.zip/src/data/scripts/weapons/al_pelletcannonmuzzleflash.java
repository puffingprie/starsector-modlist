package data.scripts.weapons;
 
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
 
public class al_pelletcannonmuzzleflash implements EveryFrameWeaponEffectPlugin
{
    private static final Color MUZZLE_FLASH_COLOR = new Color(155, 255, 255, 255);
    private static final float MUZZLE_FLASH_DURATION = 1.5f;
    private static final float MUZZLE_FLASH_BRIGHTNESS = 1f;
    private static final float MUZZLE_FLASH_SIZE = 50f;
    private static final float MUZZLE_OFFSET_HARDPOINT_UP = 44.0f;
    private static final float MUZZLE_OFFSET_TURRET_UP = 38.0f;
    private float lastChargeLevel = 0.0f;
    private float lastCooldownRemaining = 0.0f;
 
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon)
    {
        if (engine.isPaused())
        {
            return;
        }
 
        float chargeLevel = weapon.getChargeLevel();
        float cooldownRemaining = weapon.getCooldownRemaining();
 
        if (chargeLevel > lastChargeLevel || lastCooldownRemaining < cooldownRemaining)
        {
            Vector2f weaponLocation = weapon.getLocation();
            ShipAPI ship = weapon.getShip();
            float shipFacing = weapon.getCurrAngle();
            Vector2f shipVelocity = ship.getVelocity();
            Vector2f muzzleLocation = MathUtils.getPointOnCircumference(weaponLocation, weapon.getSlot().isHardpoint() ? MUZZLE_OFFSET_HARDPOINT_UP
                    : MUZZLE_OFFSET_TURRET_UP, shipFacing);
 
            if (lastCooldownRemaining < cooldownRemaining)
            {
                engine.addHitParticle(muzzleLocation, shipVelocity, MUZZLE_FLASH_SIZE, MUZZLE_FLASH_BRIGHTNESS, MUZZLE_FLASH_DURATION, MUZZLE_FLASH_COLOR);
            }
        }
 
        lastChargeLevel = chargeLevel;
        lastCooldownRemaining = cooldownRemaining;
    }
}