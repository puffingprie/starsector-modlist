package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

import java.awt.*;

public class al_empcore_glow implements EveryFrameWeaponEffectPlugin {
    //The color of our glow sprite: if this is not pure white, the glow sprite is expected to be pure white, instead
    private static final float[] COLORS = {255f/255f, 255f/255f, 255f/255f};

    //How fast the glow color "ramps up"; 2f means it takes 2 seconds to reach maximum glow
    private static final float RAMP_UP_TIME = 1f;

    //How fast the glow color "ramps down" once the system turns off; 2f means it takes 2 seconds to go from maximum glow to no glow
    private static final float RAMP_DOWN_TIME = 5f;

    //A tracker of our current brightness
    private float currentBrightness = 0f;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        ShipAPI ship = weapon.getShip();
        if (ship == null) {
            return;
        }

        //If our system has non-zero effectlevel, increase our brightness
        if (weapon.getShip().getSystem().getEffectLevel() > 0f) {
            currentBrightness += amount/RAMP_UP_TIME;
        }
        //Otherwise, decrease our brightness
        else {
            currentBrightness -= amount/RAMP_DOWN_TIME;
        }

        //Ensure the brightness is within the 0f-1f range
        currentBrightness = Math.min(1f, Math.max(0f, currentBrightness));

        //A piece should never have glowing lights
        if (ship.isPiece()) {
            currentBrightness = 0f;
        }

        //Switches to the proper sprite, since we use 2 to hide ourselves in the refit screen
        if (currentBrightness > 0) {
            weapon.getAnimation().setFrame(1);
        } else {
            weapon.getAnimation().setFrame(0);
        }

        //Now, set the color to the one we want, and include opacity
        Color colorToUse = new Color(COLORS[0], COLORS[1], COLORS[2], currentBrightness);

        //And finally actually apply the color
        weapon.getSprite().setColor(colorToUse);
    }
}