package data.scripts.weapons;

import com.fs.starfarer.api.combat.*;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * A very basic ammo swapper gun script
 * @author Nicke535
 */
public class loa_BasicAmmoSwapperGunScript extends loa_BaseAmmoSwapperGunScript {
    //--Stats for the shot types below: note that muzzle flashes are defined as multipliers from a base value, so play around a bit with them--//
    @Override
    protected ReplacementStatSheet getType1Stats() {
        return new ReplacementStatSheet(
                "loa_nicke_gun_ke",			//Id of the weapon to use in this mode
                0f,							//Inaccuracy (above the weapon's normal inaccuracy)
                0f);						//Speed variation, IE how much does the shot's velocity randomly vary (as a multiplier)
    }

    //Stats for the type-2 (Kinetic) shot
    @Override
    protected ReplacementStatSheet getType2Stats() {
        return new ReplacementStatSheet(
                "loa_nicke_gun_he",		    //Id of the weapon to use in this mode
                0f,							//Inaccuracy (above the weapon's normal inaccuracy)
                0f);					    //Speed variation, IE how much does the shot's velocity randomly vary (as a multiplier)
    }

    //Animation work goes in here (selecting frame etc.)
    @Override
    protected void handleAnimation(WeaponAPI weapon, int activeAmmoType, float swapTimeRemaining) {
        //Got nothing right now, just continue on our merry way
        return;
    }


    //By default, only prevents the weapon from firing while swapping ammo type
    @Override
    protected void handleExtraEffects(WeaponAPI weapon, int activeAmmoType, float swapTimeRemaining) {
        //Call default implementation
        super.handleExtraEffects(weapon, activeAmmoType, swapTimeRemaining);
    }
}