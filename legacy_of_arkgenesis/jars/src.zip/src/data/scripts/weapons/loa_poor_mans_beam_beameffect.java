package data.scripts.weapons;

import com.fs.starfarer.api.combat.*;

/**
 * Causes a beam to fade out in size over its firing sequence, despite not reaching its chargeDown state
 * @author Nicke535
 */
public class loa_poor_mans_beam_beameffect implements BeamEffectPlugin {
    /**
     * How long should the beam wait before starting to fade in size?
     */
    private static final float NON_FADE_DURATION = 0.1f;

    /**
     * How long does it take for the beam to fade to 0 thickness, after it starts fading?
     */
    private static final float THICKNESS_FADE_DURATION = 1f;

    /**
     * Degree on the fadeout-curve : 1f equals linear falloff, 2f quadratic etc.
     */
    private static final float FALLOFF_DEGREE = 1f;

    //Script-used, don't touch
    private float beamWidth = -1f;
    private float counter = 0f;

    @Override
    public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
        // Don't bother with any unecessary checks
        if (beam.getWeapon().getShip() == null) {
            return;
        }

        WeaponAPI weapon = beam.getWeapon();

        //Reads how wide the beam is originally; only do this if we haven't already found out
        if (beamWidth == -1f) {
            beamWidth = beam.getWidth();
        }

        //Reset our variables if we aren't firing anymore
        if (!weapon.isFiring() || weapon.getChargeLevel() <= 0f) {
            counter = 0f;
            beam.setWidth(beamWidth);
            return;
        }

        counter += amount;

        //Calculate how thick the beam should be this frame
        if (counter > NON_FADE_DURATION) {
            float thicknessFactor = 1f - ((counter- NON_FADE_DURATION)/THICKNESS_FADE_DURATION);
            if (thicknessFactor < 0f) {
                thicknessFactor = 0f;
            }
            thicknessFactor = (float)Math.pow(thicknessFactor, FALLOFF_DEGREE);

            beam.setWidth(beamWidth*thicknessFactor);
        }
    }
}