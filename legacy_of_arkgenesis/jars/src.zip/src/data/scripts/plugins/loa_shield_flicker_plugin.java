package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class loa_shield_flicker_plugin extends BaseEveryFrameCombatPlugin {
    //What prefixes can our ships start with to get the shield-flicker effect?
    private static final List<String> VALID_PREFIXES = new ArrayList<>();
    static {
        VALID_PREFIXES.add("loamt_");
        VALID_PREFIXES.add("loamtg_");
        VALID_PREFIXES.add("loamtp_");
    }

    //List of hullmod IDs that turn off the shield-flickering effect
    private static final List<String> DISABLING_HULLMODS = new ArrayList<>();
    static {
        DISABLING_HULLMODS.add("hardenedshieldemitter");
        DISABLING_HULLMODS.add("loamt_shieldcoreupgrade");
    }

    //What is our "default" shield color?
    private static final Color DEFAULT_SHIELD_INNER_COLOR = new Color(150,50,255,75);
    private static final Color DEFAULT_SHIELD_RING_COLOR = new Color(250,255,255,255);

    //What shield color do we get from flickering?
    private static final Color FLICKER_SHIELD_INNER_COLOR = new Color(200,50,255,50);
    private static final Color FLICKER_SHIELD_RING_COLOR = new Color(250,255,255,200);

    //The longest and shortest possible delays between flickers
    private static final float FLICKER_MAX_DELAY = 0.1f;
    private static final float FLICKER_MIN_DELAY = 0.01f;

    //Maximum and minimum flicker duration for any "one flicker"
    private static final float FLICKER_MAX_DURATION = 0.05f;
    private static final float FLICKER_MIN_DURATION = 0.01f;

    //The ID we insert our flicker handlers with; only important part is that it's unique, nothing else really matters
    private static final String FLICKER_HANDLER_ID = "loa_flicker_handler_id";


    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        //Run for every ship on the map, but discard ones that don't have a matching ID tag or that have any of the disabling hullmods
        for (ShipAPI ship : Global.getCombatEngine().getShips()) {
            boolean shouldFlicker = false;
            for (String prefix : VALID_PREFIXES) {
                if (ship.getHullSpec().getHullId().startsWith(prefix)) {
                    shouldFlicker = true;
                    break;
                }
            }
            for (String mod : DISABLING_HULLMODS) {
                if (ship.getVariant().hasHullMod(mod)) {
                    shouldFlicker = false;
                    break;
                }
            }
            if (!shouldFlicker) { continue; }

            //If the shields are off (or we have no shields), this does nothing
            ShieldAPI shield = ship.getShield();
            if (shield == null || shield.isOff() || shield.getType() == ShieldAPI.ShieldType.NONE || shield.getType() == ShieldAPI.ShieldType.PHASE) {
                return;
            }

            //Tick our flicker handler
            if (Global.getCombatEngine().getCustomData().get(ship.getId() + FLICKER_HANDLER_ID) instanceof FlickerHandler) {
                ((FlickerHandler)Global.getCombatEngine().getCustomData().get(ship.getId() + FLICKER_HANDLER_ID)).tick(amount, shield);
            }
            //If we don't have a flicker handler yet, add one and tick it
            else {
                FlickerHandler handler = new FlickerHandler();
                Global.getCombatEngine().getCustomData().put(ship.getId() + FLICKER_HANDLER_ID, handler);
                handler.tick(amount, shield);
            }
        }
    }


    //Class for flicker handlers: handles everything flicker-related. All config is above; don't touch this one
    private class FlickerHandler {
        private IntervalUtil triggerInterval = new IntervalUtil(FLICKER_MIN_DELAY, FLICKER_MAX_DELAY);
        private float currentFlickerDuration = 0f;

        void tick (float amount, ShieldAPI shield) {
            //Trigger new flickers, and advance existing ones
            currentFlickerDuration -= amount;
            triggerInterval.advance(amount);
            if (triggerInterval.intervalElapsed()) {
                currentFlickerDuration = MathUtils.getRandomNumberInRange(FLICKER_MIN_DURATION,FLICKER_MAX_DURATION);
            }

            //Changes shield color depending on flicker status
            float flickerProgress = (float)Math.pow(Math.min(1f, Math.max(0f, currentFlickerDuration/FLICKER_MAX_DURATION)), 1.5f);
            shield.setInnerColor(Misc.interpolateColor(DEFAULT_SHIELD_INNER_COLOR, FLICKER_SHIELD_INNER_COLOR, flickerProgress));
            shield.setRingColor(Misc.interpolateColor(DEFAULT_SHIELD_RING_COLOR, FLICKER_SHIELD_RING_COLOR, flickerProgress));
        }
    }
}
