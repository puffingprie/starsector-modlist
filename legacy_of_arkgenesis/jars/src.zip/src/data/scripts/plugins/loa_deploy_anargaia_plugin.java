package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple script that deploys Anargaia into battle should it somehow end up in reserves
 * @author Nicke535
 */
public class loa_deploy_anargaia_plugin extends BaseEveryFrameCombatPlugin {
    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        CombatEngineAPI engine = Global.getCombatEngine();

        //Check the reserves of both fleets
        for (FleetMemberAPI member : engine.getFleetManager(FleetSide.PLAYER).getReservesCopy()) {
            //If the reserve is Anargaia, deploy it
            if (member.getHullId().contains("loa_arscapitol_core")) {
                ShipAPI anargaia = engine.getFleetManager(FleetSide.PLAYER).spawnFleetMember(member,
                        new Vector2f(0f, engine.getFleetManager(FleetSide.PLAYER).getDeploymentYOffset()/2f - engine.getMapHeight()/3f),
                        90f, 0f);
                //On the player side, anargaia is always an ally
                anargaia.setAlly(true);
            }
        }
        for (FleetMemberAPI member : engine.getFleetManager(FleetSide.ENEMY).getReservesCopy()) {
            //If the reserve is Anargaia, deploy it
            if (member.getHullId().contains("loa_arscapitol_core")) {
                engine.getFleetManager(FleetSide.ENEMY).spawnFleetMember(member,
                        new Vector2f(0f, engine.getFleetManager(FleetSide.ENEMY).getDeploymentYOffset()/2f + engine.getMapHeight()/3f),
                        -90f, 0f);
            }
        }
    }
}
