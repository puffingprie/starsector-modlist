//By Nicke535
//Used in conjunction with the loa_awacs shipsystem script to give AWACS bonuses to ships
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.shipsystems.loa_awacs;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_awacs_bonus_applier_plugin extends BaseEveryFrameCombatPlugin {

    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        //Iterates through all ships on the map
        for (ShipAPI ship : Global.getCombatEngine().getShips()) {
            //We don't care about this ship if it's disabled or not allied
            if (ship.isHulk()) {
                continue;
            }

            //Check all nearby friendly ships and see if they are an AWACS provider
            int highestBonusFound = 0;
            List<ShipAPI> allies = AIUtils.getNearbyAllies(ship, loa_awacs.ACTIVE_RANGE);
            allies.add(ship);
            for (ShipAPI ally : allies) {
                //If they're dead, they don't count
                if (!ally.isAlive()) {
                    continue;
                }

                //Most common case: no awacs tracker stat. Disregard this ally
                if (ally.getMutableStats().getDynamic().getStat(loa_awacs.TRACKER_STAT_ID + "_1").getModifiedValue() <= 1f) {
                    continue;
                }

                //Check which level of bonus the ally is providing
                if (ally.getMutableStats().getDynamic().getStat(loa_awacs.TRACKER_STAT_ID + "_3").getModifiedValue() > 1f) {
                    highestBonusFound = 3;
                    break; //If we find a lvl 3 bonus, we don't care about the rest of the allies: we're maxed
                } else if (ally.getMutableStats().getDynamic().getStat(loa_awacs.TRACKER_STAT_ID + "_2").getModifiedValue() > 1f) {
                    highestBonusFound = 2;
                } else {
                    highestBonusFound = 1;
                }
            }

            //Applies (or removes) our range bonus depending on highest bonus found
            float targetMult = 1f;
            if (highestBonusFound >= 3) {
                targetMult = loa_awacs.STAGE_3_RANGE_MULTS.get(ship.getHullSize());
            } else if (highestBonusFound >= 2) {
                targetMult = loa_awacs.STAGE_2_RANGE_MULTS.get(ship.getHullSize());
            } else if (highestBonusFound >= 1) {
                targetMult = loa_awacs.STAGE_1_RANGE_MULTS.get(ship.getHullSize());
            }
            if (targetMult > 1f) {
                ship.getMutableStats().getBallisticWeaponRangeBonus().modifyPercent(loa_awacs.BONUS_ID, (targetMult-1f)*100f);
                ship.getMutableStats().getEnergyWeaponRangeBonus().modifyPercent(loa_awacs.BONUS_ID, (targetMult-1f)*100f);
            } else {
                ship.getMutableStats().getBallisticWeaponRangeBonus().unmodify(loa_awacs.BONUS_ID);
                ship.getMutableStats().getEnergyWeaponRangeBonus().unmodify(loa_awacs.BONUS_ID);
            }
        }
    }
}