//By Nicke535, causes a set list of projectiles to act as "EMP flak", detonating at a certain range from missiles and ships while firing an EMP arc at them
//Any projectile which exists in all "stat maps" will have this behaviour enabled
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_zapflakplugin extends BaseEveryFrameCombatPlugin {

    /*
        All these maps correspond to different stats that can be modified
        individually for each projectile the script tracks. If a projectile
        exists in any of these maps, it must exist in all of the maps.
     */

    //----------------------------------------------------MECHANICS-----------------------------------------------------
    //Range for the "flak" to trigger
    private static final Map<String, Float> TRIGGER_RANGE = new HashMap<String, Float>();
    static {
        TRIGGER_RANGE.put("loa_zapflakshot", 40f);
    }

    //Percentage of the projectile's damage done by the ensuing EMP arc (1f = 100%, 0.5f = 50%)
    private static final Map<String, Float> DAMAGE_PERCENTAGE = new HashMap<String, Float>();
    static {
        DAMAGE_PERCENTAGE.put("loa_zapflakshot", 1f);
    }

    //Percentage of the projectile's EMP damage done by the ensuing EMP arc (1f = 100%, 0.5f = 50%)
    private static final Map<String, Float> EMP_PERCANTAGE = new HashMap<String, Float>();
    static {
        EMP_PERCANTAGE.put("loa_zapflakshot", 1f);
    }

    //Damage type of the EMP arc
    private static final Map<String, DamageType> DAMAGE_TYPE = new HashMap<String, DamageType>();
    static {
        DAMAGE_TYPE.put("loa_zapflakshot", DamageType.ENERGY);
    }

    //--------------------------------------------------AUDIOVISUALS----------------------------------------------------
    //Color of the EMP arc's center
    private static final Map<String, Color> BOLT_CENTER_COLOR = new HashMap<String, Color>();
    static {
        BOLT_CENTER_COLOR.put("loa_zapflakshot", new Color(255, 255, 255));
    }

    //Color of the EMP arc's edge
    private static final Map<String, Color> BOLT_EDGE_COLOR = new HashMap<String, Color>();
    static {
        BOLT_EDGE_COLOR.put("loa_zapflakshot", new Color(0, 100, 255));
    }

    //Minimum width for the EMP arc
    private static final Map<String, Float> BOLT_MIN_WIDTH = new HashMap<String, Float>();
    static {
        BOLT_MIN_WIDTH.put("loa_zapflakshot", 12f);
    }

    //Maximum width for the EMP arc
    private static final Map<String, Float> BOLT_MAX_WIDTH = new HashMap<String, Float>();
    static {
        BOLT_MAX_WIDTH.put("loa_zapflakshot", 15f);
    }

    //The sound played when the projectile fires the bolt
    private static final Map<String, String> BOLT_SOUND = new HashMap<String, String>();
    static {
        BOLT_SOUND.put("loa_zapflakshot", "loa_hightech_zap");
    }

    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        if (Global.getCombatEngine() == null || Global.getCombatEngine().isPaused()) {
            return;
        }
        CombatEngineAPI engine = Global.getCombatEngine();

        //Runs once on each projectile that matches one of the IDs specified in our maps
        for (DamagingProjectileAPI proj : engine.getProjectiles()) {
            //Ignore dead projectiles, and projectiles that don't match our IDs, and projectiles with collisionClass NONE
            if (proj.getProjectileSpecId() == null || proj.didDamage() || !TRIGGER_RANGE.keySet().contains(proj.getProjectileSpecId()) || proj.getCollisionClass().equals(CollisionClass.NONE)) {
                continue;
            }
            String specID = proj.getProjectileSpecId();

            //Stores our project location for later use
            Vector2f projPos = proj.getLocation();

            //Check for all missiles and ships within the activation range of the projectile: if any is in range, detonate on the closest one
            List<CombatEntityAPI> targets = CombatUtils.getEntitiesWithinRange(projPos, TRIGGER_RANGE.get(specID));
            CombatEntityAPI closestTarget = null;
            float closestDistance = -1f;
            for (CombatEntityAPI target : targets) {
                //Ignore non-missile, non-ship targets and any eventual allied targets
                if (!(target instanceof MissileAPI || target instanceof ShipAPI) || target.getOwner() == proj.getOwner()) {
                    continue;
                }

                //Ignore phased and collision-less targets
                if ((target instanceof ShipAPI && ((ShipAPI) target).isPhased()) || target.getCollisionClass().equals(CollisionClass.NONE)) {
                    continue;
                }

                //If the target is a non-fighter ship, we check against (and save) its "true" distance from the projectile, and ignore it if it's too far away
                float trueDistance = MathUtils.getDistance(target, proj);
                if (target instanceof ShipAPI && !((ShipAPI) target).getHullSize().equals(ShipAPI.HullSize.FIGHTER)) {
                    trueDistance = getActualDistance(projPos, target, true);
                    if (trueDistance > TRIGGER_RANGE.get(specID)) {
                        continue;
                    }
                }

                //...and now for the ugly stuff. We don't want stuff to get hit under other ships' shields, so we run a check for that
                boolean targetShielded = false;
                for (ShipAPI shielder : CombatUtils.getShipsWithinRange(projPos, target.getCollisionRadius())) {
                    //If the shielder *is* the target, ignore it
                    if ((target instanceof ShipAPI) && (shielder == (ShipAPI)target)) {
                        continue;
                    }

                    //Ignore if the shielder doesn't have a shield, or it's too far away from our current target to matter
                    if (shielder.getShield() == null || MathUtils.getDistance(shielder.getShield().getLocation(), target.getLocation()) > shielder.getShield().getRadius()) {
                        continue;
                    }

                    //Only run check if the shields are on and facing the projectile
                    if (shielder.getShield().isOn() && shielder.getShield().isWithinArc(projPos)) {
                        //If the shielder has all these attributes, we run proper math. First, get some nice points we can work with.
                        Vector2f checkPointShield = MathUtils.getPointOnCircumference(shielder.getShield().getLocation(), shielder.getShield().getRadius(),
                                VectorUtils.getAngle(shielder.getShield().getLocation(), projPos));
                        Vector2f checkVector = VectorUtils.getDirectionalVector(projPos, target.getLocation());
                        checkVector.scale(target.getCollisionRadius()*2f);
                        checkVector = Vector2f.add(checkVector, target.getLocation(), new Vector2f(0f, 0f));
                        Vector2f checkPointHull = CollisionUtils.getCollisionPoint(projPos, checkVector, target);

                        //If our checkpoint on the hull is null, we'll have to use a more rough calculation instead
                        //      Whatever wierd collision box the thing has, it's messed up
                        float distanceToHull;
                        if (checkPointHull == null) {
                            distanceToHull = getActualDistance(projPos, target, false);
                        } else {
                            distanceToHull = MathUtils.getDistance(checkPointHull, projPos);
                        }

                        //Is the shield closer to us than the target's *actual* hull (no targeting circles here, too imprecise)? If so, don't count this target as a valid target
                        if (MathUtils.getDistance(checkPointShield, projPos) <= distanceToHull) {
                            targetShielded = true;
                            break;
                        }
                    }
                }
                if (targetShielded) {
                    continue;
                }

                //If this is the first valid target we test, call it closest. Otherwise, check if it is closer than the current closest one
                if (closestTarget == null) {
                    closestTarget = target;
                    closestDistance = trueDistance;
                } else if (closestDistance > trueDistance) {
                    closestTarget = target;
                }
            }

            //Don't do anything if we didn't find a target
            if (closestTarget == null) {
                continue;
            }

            //If the closest target is a shipAPI, we use a slightly more sophisticated targeting algorithm to find a collision point
            Vector2f collisionPoint = new Vector2f(closestTarget.getLocation().x, closestTarget.getLocation().y);
            if (closestTarget instanceof ShipAPI) {
                Vector2f newCollisionPoint = null;

                //First; did we hit shields? If so, only check against enemy shield radius instead of their "proper" collision bounds
                if (closestTarget.getShield() != null && closestTarget.getShield().isOn() && closestTarget.getShield().isWithinArc(projPos)) {
                    newCollisionPoint = MathUtils.getPointOnCircumference(closestTarget.getShield().getLocation(), closestTarget.getShield().getRadius(),
                            VectorUtils.getAngle(closestTarget.getShield().getLocation(), projPos));
                }
                //Otherwise, we run some quick math to ensure a collision point (draw a line through the entirety of the enemy ship)
                //  ...unless it *somehow* is split down the middle where we checked... in which case we're all out of luck and will just choose the center
                //  as our target location, consequences be damned: it's too expensive to run even better checks in this extremely rare special case
                else {
                    Vector2f checkVector = VectorUtils.getDirectionalVector(projPos, closestTarget.getLocation());
                    checkVector.scale(closestTarget.getCollisionRadius());
                    checkVector = Vector2f.add(checkVector, closestTarget.getLocation(), new Vector2f(0f, 0f));
                    newCollisionPoint = CollisionUtils.getCollisionPoint(projPos, checkVector, closestTarget);
                }

                //If we succesfully achieved a new collisionPoint, we use that one instead of the original one
                if (newCollisionPoint != null) {
                    collisionPoint = newCollisionPoint;
                }
            }

            //Actually spawns the EMP arc (or at least, what looks like it)
            fakeEMPArc(proj.getSource(), projPos, proj, closestTarget, collisionPoint, DAMAGE_TYPE.get(specID), proj.getDamageAmount() * DAMAGE_PERCENTAGE.get(specID),
                    proj.getEmpAmount() * EMP_PERCANTAGE.get(specID), BOLT_SOUND.get(specID), MathUtils.getRandomNumberInRange(BOLT_MIN_WIDTH.get(specID), BOLT_MAX_WIDTH.get(specID)),
                    BOLT_EDGE_COLOR.get(specID), BOLT_CENTER_COLOR.get(specID));

            //And finally, removes our projectile (and sets its collisionClass to NONE, since it should be dead by now anyhow)
            proj.setCollisionClass(CollisionClass.NONE);
            engine.removeEntity(proj);
        }
    }


    //Function for faking an EMP arc; deals damage to a point and spawns a fake EMP arc to the same point
    //The supplied point must be within the target's bounds
    private void fakeEMPArc (ShipAPI damageSource, Vector2f sourcePoint, CombatEntityAPI anchor, CombatEntityAPI target, Vector2f targetPoint, DamageType damageType, float damage,
                             float emp, String sound, float width, Color centerColor, Color edgeColor) {
        //First, deal damage to our "real" target
        Global.getCombatEngine().applyDamage(target, targetPoint, damage, damageType, emp, false, false, damageSource, true);

        //Then, spawns a fake entity so we can target *it* with the bolt
        CombatEntityAPI fakeEntity = new SimpleEntity(targetPoint);

        //And then spawns the visual bolt itself
        Global.getCombatEngine().spawnEmpArc(damageSource, sourcePoint, anchor, fakeEntity,
                damageType, //Damage type
                0f, //Damage
                0f, //Emp
                100000f, //Max range
                null, //Impact sound
                width, // thickness of the lightning bolt
                centerColor, //Central color
                edgeColor);//Fringe Color

        //And finally spawns a sound effect, since the arc function fails to do so properly against SimpleEntities
        Global.getSoundPlayer().playSound(sound, 1f, 1f, targetPoint, new Vector2f(0f, 0f));
    }


    //By MesoTroniK, fixes some targeting issues vanilla's Misc.getTargetingRadius() function
    private static float getActualDistance(Vector2f from, CombatEntityAPI target, boolean considerShield) {
        if (considerShield && (target instanceof ShipAPI)) {
            ShipAPI ship = (ShipAPI) target;
            ShieldAPI shield = ship.getShield();
            if (shield != null && shield.isOn() && shield.isWithinArc(from)) {
                return MathUtils.getDistance(from, shield.getLocation()) - shield.getRadius();
            }
        }
        return MathUtils.getDistance(from, target.getLocation()) - Misc.getTargetingRadius(from, target, false);
    }
}