//By Nicke535
//Tracks special projectiles which are used in tandem with the EMP bomb shipsystem. All projectiles must be added to this plugin via startTrackingProjectile
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.FleetInteractionDialogPluginImpl;
import com.fs.starfarer.api.input.InputEventAPI;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class al_empcore_plugin extends BaseEveryFrameCombatPlugin {
    //------------------------------------CHANGE THESE VARIABLES FOR BALANCE/VISUALS------------------------------------
    //The maximum amount of lightning bolts any individual target can recieve (this can be set on a hullsize basis)
    private final static Map<HullSize, Integer> MAX_BOLTS_PER_TARGET = new HashMap<HullSize, Integer>();
    static {
        MAX_BOLTS_PER_TARGET.put(HullSize.FIGHTER, 1);
        MAX_BOLTS_PER_TARGET.put(HullSize.FRIGATE, 2);
        MAX_BOLTS_PER_TARGET.put(HullSize.DESTROYER, 3);
        MAX_BOLTS_PER_TARGET.put(HullSize.CRUISER, 4);
        MAX_BOLTS_PER_TARGET.put(HullSize.CAPITAL_SHIP, 5);
    }

    //The maximum time a projectile is allowed to exist: for AI reasons, this *should* be equal to or less than RANGE/PROJECTILE_SPEED as defined in weapon_data.csv for the projectile's weapon.
    //Can vary per projectile spec ID, if multiple ones are used. DEFAULT is used for any projectile ID not defined in the list
    private final static Map<String, Float> LIFETIME_MAP = new HashMap<String, Float>();
    static {
        LIFETIME_MAP.put("DEFAULT", 3f);
        LIFETIME_MAP.put("al_empcore_frigate_proj", 3f);
        LIFETIME_MAP.put("al_empcore_destroyer_proj", 3f);
        LIFETIME_MAP.put("al_empcore_cruiser_proj", 3f);
        LIFETIME_MAP.put("al_empcore_capital_proj", 3f);
    }

    //The maximum number of EMP arcs each projectile spawns when detonated
    //Can vary per projectile spec ID, if multiple ones are used. DEFAULT is used for any projectile ID not defined in the list
    private final static Map<String, Integer> ARC_MAP = new HashMap<String, Integer>();
    static {
        ARC_MAP.put("DEFAULT", 10);
        ARC_MAP.put("al_empcore_frigate_proj", 5);
        ARC_MAP.put("al_empcore_destroyer_proj", 10);
        ARC_MAP.put("al_empcore_cruiser_proj", 15);
        ARC_MAP.put("al_empcore_capital_proj", 20);
    }

    //The damage of each EMP arc spawned
    //Can vary per projectile spec ID, if multiple ones are used. DEFAULT is used for any projectile ID not defined in the list
    private final static Map<String, Float> DAMAGE_MAP = new HashMap<String, Float>();
    static {
        DAMAGE_MAP.put("DEFAULT", 10f);
        DAMAGE_MAP.put("al_empcore_frigate_proj", 250f);
        DAMAGE_MAP.put("al_empcore_destroyer_proj", 250f);
        DAMAGE_MAP.put("al_empcore_cruiser_proj", 250f);
        DAMAGE_MAP.put("al_empcore_capital_proj", 250f);
    }

    //The EMP damage of each EMP arc spawned
    //Can vary per projectile spec ID, if multiple ones are used. DEFAULT is used for any projectile ID not defined in the list
    private final static Map<String, Float> EMP_MAP = new HashMap<String, Float>();
    static {
        EMP_MAP.put("DEFAULT", 50f);
        EMP_MAP.put("al_empcore_frigate_proj", 75f);
        EMP_MAP.put("al_empcore_destroyer_proj", 100f);
        EMP_MAP.put("al_empcore_cruiser_proj", 150f);
        EMP_MAP.put("al_empcore_capital_proj", 200f);
    }

    //The area-of-effect the explosion has when at full power
    //Can vary per projectile spec ID, if multiple ones are used. DEFAULT is used for any projectile ID not defined in the list
    private static final Map<String, Float> AOE_SIZE_MAP = new HashMap<String, Float>();
    static {
        AOE_SIZE_MAP.put("DEFAULT", 100f);
        AOE_SIZE_MAP.put("al_empcore_frigate_proj",300f);
        AOE_SIZE_MAP.put("al_empcore_destroyer_proj", 400f);
        AOE_SIZE_MAP.put("al_empcore_cruiser_proj", 500f);
        AOE_SIZE_MAP.put("al_empcore_capital_proj", 600f);
    }

    //A projectile spawns this many fewer EMP arcs when hitting something rather than detonating normally; this *can* reduce arc count below zero, which simply means it doesn't fire any arcs
    private static final int ARC_PENALTY_ON_HIT = 3;

    //The power a projectile "starts" at; it gradually grows up to a power of 1f over its lifetime. A value of 0.5f means starting at 50% of the maximum power
    //Power is directly proportional to arc spawn count, and its square root is proportional to the damage of each arc and the AoE
    private static final float STARTING_POWER = 0.1f;

    //VISUAL ONLY: the chance each frame that a small decorative lightning bolt is spawned. Multiplied with power, so at 50% charge it spawns half as many deco bolts
    private static final float DECO_BOLT_CHANCE = 0.07f;

    //VISUAL ONLY: the size of the projectile's additional glow when at maximum power. Scales linearly with power
    private static final float DECO_GLOW_SIZE = 140f;

    //VISUAL ONLY: the distance at which the "suck-in" particles are spawned when at maximum power. Scales linearly with power
    private static final float DECO_SUCKER_SIZE = 120f;

    //VISUAL ONLY: the color of the suck-in particles
    private static final Color SUCK_PARTICLE_COLOR = new Color(150, 200, 255);

    //VISUAL ONLY: the color of the main glow
    private static final Color GLOW_PARTICLE_COLOR = new Color(0, 50, 255);

    //VISUAL ONLY: the color of the lighting bolts (is then blended with a pure white core)
    private static final Color BOLT_COLOR = new Color(50, 100, 255);

    //VISUAL ONLY: the size of the explosion particle which spawns once the bomb detonates
    private static final float EXPLOSION_SIZE = 350f;

    //VISUAL ONLY: the duration of the explosion particle which spawns once the bomb detonates
    private static final float EXPLOSION_DURATION = 1f;

    //SOUND: The sound the projectile makes when detonating
    private static final String EXPLOSION_SOUND = "al_empcore_explosion";

    //SOUND: the sound of the lightning bolts themselves (vanilla uses "tachyon_lance_emp_impact")
    private static final String BOLT_SOUND = "al_emoverload_zap";

    //SOUND: The sound the projectile makes while active
    private static final String LOOP_SOUND = "al_empcore_loop";

    //--------------------------------THESE ARE SCRIPT-USED AND SHOULD REMAIN UNCHANGED---------------------------------
    //Our list of projectiles that the script will check in each advance() check
    private Map<DamagingProjectileAPI, DataStorage> projectiles = new HashMap<DamagingProjectileAPI, DataStorage>();


    //Function for adding a new projectile to be tracked
    public static void startTrackingProjectile (DamagingProjectileAPI proj, ShipAPI target, float topSpeed) {
        //Only run if we have a stored plugin in our engine
        if (Global.getCombatEngine().getCustomData().get("al_empcore_plugin") instanceof al_empcore_plugin) {
            //Creates a data storage for later use
            DataStorage data = new DataStorage(target, -1f, topSpeed);

            //Add the projectile so it's tracked properly (don't add it if we have already added it)
            if (!((al_empcore_plugin) Global.getCombatEngine().getCustomData().get("al_empcore_plugin")).projectiles.containsKey(proj)) {
                ((al_empcore_plugin)Global.getCombatEngine().getCustomData().get("al_empcore_plugin")).projectiles.put(proj, data);
            }
        }
    }

    //Initializer function
    @Override
    public void init(CombatEngineAPI engine) {
        //Reinitialize the data
        projectiles.clear();

        //Puts the plugin in the right spot in our combat engine, this is necessary so we don't use static variable saving unnecessarily
        engine.getCustomData().put("al_empcore_plugin", this);
    }

    //Main advance loop
    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        CombatEngineAPI engine = Global.getCombatEngine();
        if (engine == null){return;}
        if (engine.isPaused()){return;}

        //Iterate through all our projectiles
        List<DamagingProjectileAPI> toRemove = new ArrayList<>();
        for (DamagingProjectileAPI proj : projectiles.keySet()) {
            //Saves our maximum lifetime for later use
            float maxLifetime = LIFETIME_MAP.get("DEFAULT");
            if (LIFETIME_MAP.get(proj.getProjectileSpecId()) != null) {
                maxLifetime = LIFETIME_MAP.get(proj.getProjectileSpecId());
            }

            //Calculates our "power" this frame; this effects visual flair and how strong the detonation is
            float power = STARTING_POWER + (1f - STARTING_POWER) * (proj.getElapsed()/maxLifetime);

            //If our projectile hit something this frame, detonate it with slightly less force than otherwise
            if (proj.didDamage()) {
                handleExplosion(proj, power, true);
                toRemove.add(proj);
                continue;
            }

            //If our projectile is too far away from its target (when checking maximum possible AoE), or our target is phased, detonate it early
            float aoe = AOE_SIZE_MAP.get("DEFAULT");
            if (AOE_SIZE_MAP.get(proj.getProjectileSpecId()) != null) {
                aoe = AOE_SIZE_MAP.get(proj.getProjectileSpecId());
            }
            if (MathUtils.getDistance(projectiles.get(proj).target, proj.getLocation()) >= aoe || projectiles.get(proj).target.isPhased() || projectiles.get(proj).target.getCollisionClass().equals(CollisionClass.NONE)) {
                handleExplosion(proj, power, false);
                toRemove.add(proj);
                continue;
            }
            aoe *= Math.sqrt(power);

            //If our projectile has existed longer than it is allowed to, or for some reason has stopped charging, detonate it normally
            if (proj.getElapsed() > maxLifetime || power <= projectiles.get(proj).previousCharge) {
                handleExplosion(proj, power, false);
                toRemove.add(proj);
                continue;
            }

            //If the projectile *didn't* explode, we spawn some visual flair to indicate how "powered up" the projectile is, starting with particle effects
            for (int i = 0; i < 200 * power * amount; i++) {
                //The particles spawn at a set distance from our projectile and travel inwards over their lifetime
                Vector2f startPos = MathUtils.getPointOnCircumference(proj.getLocation(), DECO_SUCKER_SIZE*power, MathUtils.getRandomNumberInRange(0f, 360f));

                //Slightly randomize lifetime for visual effect
                float lifetime = 0.3f * MathUtils.getRandomNumberInRange(0.75f, 1.25f);

                //Calculates our velocity vector so it always points towards our projectile's center, and reaches that center exactly at the end of our lifetime
                Vector2f velocity = new Vector2f(proj.getVelocity().x * lifetime, proj.getVelocity().y * lifetime);
                velocity.x += proj.getLocation().x - startPos.x;
                velocity.y += proj.getLocation().y - startPos.y;
                velocity.scale(1f/lifetime);

                //Gets a slightly random particle size to look more "energetic"
                float particleSize = MathUtils.getRandomNumberInRange(3f, 7f);

                //Finally, actually spawn the particle
                engine.addSmoothParticle(startPos, velocity, particleSize, 1f, lifetime, SUCK_PARTICLE_COLOR);
            }

            //This is the main "glow" particle, making the projectile look bigger than it is. Has minor size and brightness jitter so it looks more unstable
            engine.addSmoothParticle(proj.getLocation(), proj.getVelocity(), DECO_GLOW_SIZE * power * MathUtils.getRandomNumberInRange(0.95f, 1.05f),
                    1f * MathUtils.getRandomNumberInRange(0.98f, 1f), amount*2f, GLOW_PARTICLE_COLOR);

            //Then, has a small chance of spawning a minor lightning bolt each frame which is purely decorative
            if (Math.random() < DECO_BOLT_CHANCE*power) {
                //Picks a random "nearby" point; targets within half the normal AoE size and a sixth of the normal AoE size
                Vector2f targetPoint = MathUtils.getPointOnCircumference(proj.getLocation(), aoe * MathUtils.getRandomNumberInRange(1f/6f, 1f/2f), MathUtils.getRandomNumberInRange(0f, 360f));

                //Spawns a fake entity so we can target it with the bolt
                CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

                //And then spawns the bolt itself
                Global.getCombatEngine().spawnEmpArc(proj.getSource(), proj.getLocation(), proj, targetEntity,
                        DamageType.ENERGY, //Damage type
                        0f, //Damage
                        0f, //Emp
                        100000f, //Max range
                        BOLT_SOUND, //Impact sound
                        MathUtils.getRandomNumberInRange(7f, 11f) * (float)Math.sqrt(power), // thickness of the lightning bolt
                        new Color(255, 255, 255), //Central color
                        BOLT_COLOR); //Fringe Color

                //Fix for how vanilla culls EMP arc sounds
                Global.getSoundPlayer().playSound(BOLT_SOUND, 1f, 1f, proj.getLocation(), proj.getVelocity());
            }

            //After the visuals, we do some quick-and-dirty targeting and speed code for missiles
            if (proj instanceof MissileAPI) {
                proj.getVelocity().scale(projectiles.get(proj).topSpeed / proj.getVelocity().length());
                if (((MissileAPI) proj).getMissileAI() instanceof GuidedMissileAI) {
                    ((GuidedMissileAI) ((MissileAPI) proj).getMissileAI()).setTarget(projectiles.get(proj).target);
                }
            }

            //Finally, stores our current charge so we can easily check whether a projectile has been shot down by PD or not, and play a little loop sound
            projectiles.get(proj).previousCharge = power;
            Global.getSoundPlayer().playLoop(LOOP_SOUND, proj, power, power, proj.getLocation(), proj.getVelocity());
        }

        //Removes all the projectiles that should be removed
        for (DamagingProjectileAPI proj : toRemove) {
            projectiles.remove(proj);
            proj.setCollisionClass(CollisionClass.NONE);
            engine.removeEntity(proj);
        }
    }

    //Handles the explosion of a projectile. Should be called just before removing a projectile
    private void handleExplosion (DamagingProjectileAPI proj, float power, boolean hitSomething){
        //Plays our explosion sound
        Global.getSoundPlayer().playSound(EXPLOSION_SOUND, 1f, 1f, proj.getLocation(), proj.getVelocity());

        //Spawns a small explosion to hide that our projectile just dissapeared
        Global.getCombatEngine().spawnExplosion(proj.getLocation(), new Vector2f(0f, 0f), BOLT_COLOR, EXPLOSION_SIZE * power, EXPLOSION_DURATION);

        //Calculates how many arcs we will fire: note that we fire fewer arcs if we hit something with the projectile. Should this become <=0, we skip the rest of the script
        float arcNumber = ARC_MAP.get("DEFAULT");
        if (ARC_MAP.get(proj.getProjectileSpecId()) != null) {
            arcNumber = ARC_MAP.get(proj.getProjectileSpecId());
        }
        arcNumber *= power;
        if (hitSomething) {arcNumber -= ARC_PENALTY_ON_HIT;}
        if (arcNumber <= 0) {
            return;
        }

        //Calculates our damage and EMP for the explosion
        float damage = DAMAGE_MAP.get("DEFAULT");
        float emp = EMP_MAP.get("DEFAULT");
        if (DAMAGE_MAP.get(proj.getProjectileSpecId()) != null) {
            damage = DAMAGE_MAP.get(proj.getProjectileSpecId());
        }
        if (EMP_MAP.get(proj.getProjectileSpecId()) != null) {
            emp = EMP_MAP.get(proj.getProjectileSpecId());
        }
        damage *= Math.sqrt(power);
        emp *= Math.sqrt(power);

        //Saves how many times each affected ship has been hit, so we can utilize MAX_BOLTS_PER_TARGET properly
        Map<ShipAPI, Integer> targetHitMap = new HashMap<ShipAPI, Integer>();

        //Finds all valid targets in range and saves them to a list
        float arcRange = AOE_SIZE_MAP.get("DEFAULT");
        if (AOE_SIZE_MAP.get(proj.getProjectileSpecId()) != null) {
            arcRange = AOE_SIZE_MAP.get(proj.getProjectileSpecId());
        }
        arcRange *= Math.sqrt(power);
        List<ShipAPI> targetList = new ArrayList<ShipAPI>();
        for (ShipAPI temp : CombatUtils.getShipsWithinRange(proj.getLocation(), arcRange)) {
            //Ignore ships that are allied or untargetable
            if (temp.isPhased() || temp.getOwner() == proj.getOwner() || temp.getCollisionClass().equals(CollisionClass.NONE)) {
                continue;
            }

            targetList.add(temp);
            targetHitMap.put(temp, 0);
        }
        
        //NEW: deals AoE damage, too (super low early)
        float extraMult = 1f;
        if (power < 1f) {extraMult = 0.5f;}
        handleEMPAoE(targetList, proj, damage*power*extraMult, emp*power*extraMult, arcRange);
        
        //Runs a number of times depending on our arc count
        int counter = 0;
        while (counter < arcNumber) {
            counter++;

            //If we are out of targets, we spawn a deco bolt randomly in our area
            if (targetList.isEmpty()) {
                //Picks a random point that is within normal AoE size and outside a sixth of the normal AoE size
                Vector2f targetPoint = MathUtils.getPointOnCircumference(proj.getLocation(), arcRange * MathUtils.getRandomNumberInRange(1f/6f, 1f), MathUtils.getRandomNumberInRange(0f, 360f));

                //Spawns a fake entity so we can target it with the bolt
                CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

                //And then spawns the bolt itself
                Global.getCombatEngine().spawnEmpArc(proj.getSource(), proj.getLocation(), proj, targetEntity,
                        DamageType.ENERGY, //Damage type
                        0f, //Damage
                        0f, //Emp
                        100000f, //Max range
                        BOLT_SOUND, //Impact sound
                        MathUtils.getRandomNumberInRange(9f, 13f) * (float)Math.sqrt(power), // thickness of the lightning bolt
                        new Color(255, 255, 255), //Central color
                        BOLT_COLOR); //Fringe Color
            }

            //Otherwise, we spawn a bolt on a random nearby target
            else {
                //Gets a random target in our list
                ShipAPI target = targetList.get(MathUtils.getRandomNumberInRange(0, targetList.size()-1));

                //Registers that the target has been hit once: if it has been hit the maximum amount of times, remove it from the valid target list
                targetHitMap.put(target, targetHitMap.get(target)+1);
                if (targetHitMap.get(target) >= MAX_BOLTS_PER_TARGET.get(target.getHullSize())) {
                    targetList.remove(target);
                }

                //Then, we simply fire an EMP arc at the target with stats based on power
                Global.getCombatEngine().spawnEmpArc(proj.getSource(), proj.getLocation(), proj, target,
                        DamageType.ENERGY, //Damage type
                        damage * MathUtils.getRandomNumberInRange(0.95f, 1.05f) , //Damage
                        emp * MathUtils.getRandomNumberInRange(0.95f, 1.05f), //Emp
                        100000f, //Max range
                        BOLT_SOUND, //Impact sound
                        MathUtils.getRandomNumberInRange(9f, 13f) * (float)Math.sqrt(power), // thickness of the lightning bolt
                        new Color(255, 255, 255), //Central color
                        BOLT_COLOR); //Fringe Color
            }
        }
    }
    
    //Function to simplify adding the new code, this handles the AoE part of the EMP bomb for all targets
    private void handleEMPAoE (List<ShipAPI> targets, DamagingProjectileAPI proj, float damage, float emp, float range) {
        //Runs once per target
        for (ShipAPI target : targets) {
            //To simulate our AoE, we apply the damage each 0.5 degrees in a radial pattern from our projectile. Should *both* these "collision rays" miss, we stop the calculations
            float currentAngleOffset = 0f;
            float angleToTarget = VectorUtils.getAngle(proj.getLocation(), target.getLocation());

            //Never go more than 180 degrees in either direction, that's a full lap!
            boolean missedLastTime = false;
            while (currentAngleOffset < 180f) {
                //Makes it easier to write angles later
                float angleRight = (float)Math.toRadians(angleToTarget+currentAngleOffset);
                float angleLeft = (float)Math.toRadians(angleToTarget-currentAngleOffset);

                //Gets our right-side checker point
                Vector2f checkerPointRight = new Vector2f(proj.getLocation().x+(float)(Math.cos(angleRight)*range), proj.getLocation().y+(float)(Math.sin(angleRight)*range));

                //Gets where we collide with the target
                Vector2f hitPointRight = CollisionUtils.getCollisionPoint(proj.getLocation(), checkerPointRight, target);

                //If this one is a miss, skip its damage application and log that
                boolean rightMiss = false;
                if (hitPointRight != null) {
                    missedLastTime = false;

                    //This was apparently a hit; apply EMP damage at the point we hit (don't ignore shields!)
                    Global.getCombatEngine().applyDamage(target, hitPointRight, damage * 0.1f, DamageType.ENERGY, emp, false, true, proj.getSource(), false);
                } else {
                    rightMiss = true;
                }

                //Gets our left-side checker point
                Vector2f checkerPointLeft = new Vector2f(proj.getLocation().x+(float)(Math.cos(angleLeft)*range), proj.getLocation().y+(float)(Math.sin(angleLeft)*range));

                //Gets where we collide with the target
                Vector2f hitPointLeft = CollisionUtils.getCollisionPoint(proj.getLocation(), checkerPointLeft, target);

                //If this one is a miss, skip its damage application: if the right side was *also* a miss, we log that we missed entirely this time. If this happens *twice* in a row, we stop hit calculations
                if (hitPointLeft != null) {
                    missedLastTime = false;

                    //This was apparently a hit; apply EMP damage at the point we hit (don't ignore shields!)
                    Global.getCombatEngine().applyDamage(target, hitPointLeft, damage * 0.01f, DamageType.ENERGY, emp*0.1f, false, true, proj.getSource(), false);
                } else {
                    if (rightMiss) {
                        if (missedLastTime) {
                            break;
                        } else {
                            missedLastTime = true;
                        }
                    }
                }

                //Iterate up our angle
                currentAngleOffset += 0.5f;
            }
        }
    }
    
    private static class DataStorage {
        public ShipAPI target;
        public float previousCharge;
        public float topSpeed;

        public DataStorage (ShipAPI target, float previousCharge, float topSpeed) {
            this.target = target;
            this.previousCharge = previousCharge;
            this.topSpeed = topSpeed;
        }
    }
}
