package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatAssignmentType;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI;
import com.fs.starfarer.api.combat.CombatTaskManagerAPI;
import com.fs.starfarer.api.combat.DeployedFleetMemberAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

/**
 *
 * @author Thaago with some functions based on Gwyvern/Blothorn code.
 * Help and cleaning from Nick, thanks!
 */
public class loa_awacsordermanager extends BaseEveryFrameCombatPlugin{
    private final static Logger LOGGER = Global.getLogger(loa_awacsordermanager.class);
    
    //base time interval for checking and reapplying lists and orders
    private final static float CHECK_TIME = 1.0f;
    private IntervalUtil maintInterval = new IntervalUtil(CHECK_TIME, CHECK_TIME + 0.090909f);
    
    //When enabled, the player side is automatically handled instead of the ally side
    private static final boolean TOURNAMENT_MODE = false;
    
    //Prints various debug logs to the console when enabled
    private static final boolean DEBUG_MODE = false;
    
    //CombatEngineAPI engine
    CombatEngineAPI engineInstance;
    
    //fleet managers and task managers for sides
    private CombatFleetManagerAPI allyFleetManager;
    private CombatTaskManagerAPI allyTaskManager;

    private CombatFleetManagerAPI enemyFleetManager;
    private CombatTaskManagerAPI enemyTaskManager;
    
    //awacs maps for each side
    private HashMap <ShipAPI,ShipAPI> alliedAwacsData = new HashMap<>();
    private HashMap <ShipAPI,ShipAPI> enemyAwacsData = new HashMap<>();
    
    //value hashmap cache for each side
    private HashMap <ShipAPI,Float> alliedEscorteeValues = new HashMap<>();
    private HashMap <ShipAPI,Float> enemyEscorteeValues = new HashMap<>();
    
    //ordered escort list for each side - needed out here?
    List<ShipAPI> alliedEscortees = new ArrayList<>();
    List<ShipAPI> enemyEscortees = new ArrayList<>();
    
    //enums
    private final static EnumSet<WeaponAPI.WeaponType> WEAPON_TYPES = EnumSet.of(
            WeaponAPI.WeaponType.BALLISTIC,
            WeaponAPI.WeaponType.COMPOSITE,
            WeaponAPI.WeaponType.ENERGY,
            WeaponAPI.WeaponType.HYBRID,
            WeaponAPI.WeaponType.SYNERGY,
            WeaponAPI.WeaponType.UNIVERSAL
    );
    private final static EnumSet<CombatAssignmentType> ESCORT_TYPES = EnumSet.of(
            CombatAssignmentType.LIGHT_ESCORT,
            CombatAssignmentType.MEDIUM_ESCORT,
            CombatAssignmentType.HEAVY_ESCORT
    );
    
    //initialization at combat start
    @Override
    public void init(CombatEngineAPI engine) {
        if (engine == null) {
            return;
        }
        engineInstance = engine;
        
        allyFleetManager = engine.getFleetManager(FleetSide.PLAYER);
        //In tournament mode, the player fleet is controlled rather than the ally fleet
        boolean allyFleet = !TOURNAMENT_MODE;
        allyTaskManager = allyFleetManager.getTaskManager(allyFleet);
        enemyFleetManager = engine.getFleetManager(FleetSide.ENEMY);
        enemyTaskManager = enemyFleetManager.getTaskManager(false);
        engine.getCustomData().put("loa_awacs_order_manager", this);
    }
    
    //every frame
    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        
        //not sure how this could happen, but is on campaign load
        if(engineInstance == null) {
            LOGGER.info("loa_awacs_order_manager:105: advance called with null engine");
            return;
        }
        
        //advance interval timer
        if(!engineInstance.isPaused()){
            maintInterval.advance(amount);
        }

        // At intervals do the maintenance run
        if (maintInterval.intervalElapsed()){
            ////////////
        //
        //    PLAYER SIDE
        //
        ////////////
        
            //this for loop maintains the ship lists
            //List<DeployedFleetMemberAPI> playerSideDFMs = allyFleetManager.getAllEverDeployedCopy();
            List<ShipAPI> allAllyEverDeployedCopyList = new ArrayList();
            
            for(DeployedFleetMemberAPI dfm : allyFleetManager.getAllEverDeployedCopy()){
                ShipAPI ship = dfm.getShip();
                allAllyEverDeployedCopyList.add(ship);//saves ships from dfms
                
                //doing escortees first, so that it looks at both players and allies
                //its in the escort hash
                if(alliedEscorteeValues.containsKey(ship)){
                    //buts not valid
                    if(!isValidEscortee(ship)){
                        //remove it
                        alliedEscorteeValues.remove(ship);
                    }
                //its not in the escort hash    
                } else {
                    //and is valid
                    if(isValidEscortee(ship)){
                        //add it and set its value
                        alliedEscorteeValues.put(ship, targetScore(ship));
                    }
                }

                //We only count player-side awacs ships in tournament mode
                //if the ship is a player ship AND this is normal campaign,
                //then this continues and the awacs ship is not counted at all
                if(!ship.isAlly() && !TOURNAMENT_MODE) {
                    continue;
                }
                
                //its in the awacs data keys
                if (alliedAwacsData.containsKey(ship)){
                    //but is not valid
                    if(!isValidAwacs(ship)){
                        //remove from awacs data, including the value (target)
                        alliedAwacsData.remove(ship);
                    }
                // not in awacs data keys    
                } else {
                    //and is valid
                    if (isValidAwacs(ship)){
                        //add it with a null target
                        alliedAwacsData.put(ship, null);
                    }
                }
                
                
            }
            //check for the case of the alleverdeployed getting cleared and remove awacs ship
            for (ShipAPI ship:alliedAwacsData.keySet()){
                if (!allAllyEverDeployedCopyList.contains(ship)){
                    alliedAwacsData.remove(ship);
                }
            }
            allAllyEverDeployedCopyList.clear();//just in case
            
            // end deployed fleet member list maintenance for allies
            
            //sort by score 
            //make list of entries and values
            List<Entry<ShipAPI,Float>> tempList = new LinkedList<Entry<ShipAPI,Float>> (alliedEscorteeValues.entrySet());
            //sort list of entries and value
            Collections.sort(tempList,new ShipValueSorter());
            //and save list of entries in order
            alliedEscortees.clear();
            for (Entry<ShipAPI,Float> e1 : tempList){
                alliedEscortees.add(e1.getKey());
            }
            
            if (DEBUG_MODE) {
                //lets do som readouts (if enabled, of course)!
                for (ShipAPI awacsShip : alliedAwacsData.keySet()){
                    LOGGER.info("Allied ship in awacs Keys: " + awacsShip.getName());
                }

                LOGGER.info("Allied all ever deployed size: " + allyFleetManager.getAllEverDeployedCopy().size());

                for (ShipAPI escorteeShip :  alliedEscortees ){
                    LOGGER.info("Allied ship in escortee sorted list: " + escorteeShip.getName() +" which is: " + escorteeShip.isAlive());
                }
            }
            
            //check each ship target in the awacsData and update, then give it its order
            //note: retreating awacs ships have been removed
            for (ShipAPI awacsShip : alliedAwacsData.keySet()){
                //if the value (target) is null or not valid, set the new first available
                if (alliedAwacsData.get(awacsShip)== null || !isValidEscortee(alliedAwacsData.get(awacsShip))){
                    alliedAwacsData.put(awacsShip, firstAvailableEscortee(alliedEscortees,alliedAwacsData.values()));
                }
                
                
                
                //if after all this target is still null, well that sucks
                if (alliedAwacsData.get(awacsShip)==null){
                    continue;
                }
                
                //assign orders
                DeployedFleetMemberAPI target = allyFleetManager.getDeployedFleetMember(alliedAwacsData.get(awacsShip));
                CombatFleetManagerAPI.AssignmentInfo escortAssignment = 
                        allyTaskManager.createAssignment(CombatAssignmentType.LIGHT_ESCORT, target, false);
                
                allyTaskManager.giveAssignment(allyFleetManager.getDeployedFleetMember(awacsShip), escortAssignment, false);
                
                if (DEBUG_MODE) {
                    LOGGER.info("P/A: Gave Escort order to: " + awacsShip.getName());
                    LOGGER.info("P/A: It is escorting: " + alliedAwacsData.get(awacsShip).getName());
                }
                
            }//end updating alliedAwacsData values and assigning orders

        
        
            ////////////
            //
            //    ENEMY SIDE
            //
            ////////////
            //maintain the ship lists.
            List<ShipAPI> allEnemyEverDeployedCopyList = new ArrayList();
            for(DeployedFleetMemberAPI dfm : enemyFleetManager.getAllEverDeployedCopy()){
                    ShipAPI ship = dfm.getShip();
                    allEnemyEverDeployedCopyList.add(ship);//saves ships from dfms

                    //its in the awacs data keys
                    if (enemyAwacsData.containsKey(ship)){
                        //but is not valid
                        if(!isValidAwacs(ship)){
                            //remove from awacs data, including the value (target)
                            enemyAwacsData.remove(ship);
                        }
                    // not in awacs data keys    
                    } else {
                        //and is valid
                        if (isValidAwacs(ship)){
                            //add it with a null target
                            enemyAwacsData.put(ship, null);
                        }
                    }

                    //its in the escort hash
                    if(enemyEscorteeValues.containsKey(ship)){
                        //buts not valid
                        if(!isValidEscortee(ship)){
                            //remove it
                            enemyEscorteeValues.remove(ship);
                        }
                    //its not in the escort hash    
                    } else {
                        //and is valid
                        if(isValidEscortee(ship)){
                            //add it and set its value
                            enemyEscorteeValues.put(ship, targetScore(ship));
                        }
                    }
                } 
                //check for the case of the alleverdeployed getting cleared and remove awacs ship
                for (ShipAPI ship:enemyAwacsData.keySet()){
                    if (!allEnemyEverDeployedCopyList.contains(ship)){
                        enemyAwacsData.remove(ship);
                    }
                }
                allEnemyEverDeployedCopyList.clear();//just in case

            // end deployed fleet member list maintenance for enemies

                //sort by score 
                //make list of entries and values
                List<Entry<ShipAPI,Float>> tempListEnemy = new LinkedList<Entry<ShipAPI,Float>> (enemyEscorteeValues.entrySet());
                //sort list of entries and value
                Collections.sort(tempListEnemy,new ShipValueSorter());
                //and save list of entries in order
                enemyEscortees.clear();
                for (Entry<ShipAPI,Float> e1 : tempListEnemy){
                    enemyEscortees.add(e1.getKey());
                }

                //lets do som readouts (if enabled, of course)!
                if (DEBUG_MODE) {
                    for (ShipAPI awacsShip : enemyAwacsData.keySet()){
                        LOGGER.info("Enemy ship in awacs Keys: " + awacsShip.getName());
                    }

                    for (ShipAPI escorteeShip :  enemyEscortees ){
                        LOGGER.info("Enemy ship in escortee sorted list: " + escorteeShip.getName() +" which is: " + escorteeShip.isAlive());
                    }
                }

                //check each ship target in the awacsData and update, then give it its order
                //note: retreating awacs ships have been removed
                for (ShipAPI awacsShip : enemyAwacsData.keySet()){
                    //if the value (target) is null or not valid, set the new first available
                    if (enemyAwacsData.get(awacsShip)== null || !isValidEscortee(enemyAwacsData.get(awacsShip))){
                        enemyAwacsData.put(awacsShip, firstAvailableEscortee(enemyEscortees,enemyAwacsData.values()));
                    }



                    //if after all this target is still null, well that sucks
                    if (enemyAwacsData.get(awacsShip)==null){
                        continue;
                    }

                    //assign orders
                    DeployedFleetMemberAPI target = enemyFleetManager.getDeployedFleetMember(enemyAwacsData.get(awacsShip));
                    CombatFleetManagerAPI.AssignmentInfo escortAssignment = 
                            enemyTaskManager.createAssignment(CombatAssignmentType.LIGHT_ESCORT, target, false);

                    enemyTaskManager.giveAssignment(enemyFleetManager.getDeployedFleetMember(awacsShip), escortAssignment, false);

                    if (DEBUG_MODE) {
                        LOGGER.info("Enemy: Gave Escort order to: " + awacsShip.getName());
                        LOGGER.info("Enemy: It is escorting: " + enemyAwacsData.get(awacsShip).getName());
                    }

                }// END ENEMY SECTION
            
            }//end maint interval block 
        
        
    }// END ADVANCE
    
    
    //Helper function: True if a valid awacs ship. Needs tobe alive and not retreating and have the right system and not be a fighter
    private boolean isValidAwacs(ShipAPI ship){
        if (ship == null || ship.isFighter() || ship.getSystem() == null){
            return false;
        }
        
        if (ship.getSystem().getId().equals("loa_awacs") && ship.isAlive() && !ship.isRetreating()){
            return true;
        }
        //else
        return false;
    }
    
    //Helper function: True if alive and not retreating AND not a fighter!
    private boolean isValidEscortee(ShipAPI ship){
        if (ship == null){
            return false;
        }
        
        if (!ship.isFighter() && ship.isAlive() && !ship.isRetreating()) {
            return true;
        }
        //else
        return false;
    }
    
    //Helper function: returns first ship in given list (escortees) not already in the other list (current targets)
    private ShipAPI firstAvailableEscortee(List<ShipAPI> escortees, Collection<ShipAPI> awacsTargets){
        for (ShipAPI ship : escortees){
            if (ship != null && !awacsTargets.contains(ship)){
                return ship;
            }
        }
        return null;
    }
    
    //Helper function: returns the score of the ship
    //removed caching functionality to avoid side effects/externalities
    private float targetScore(ShipAPI ship) {
        ShipHullSpecAPI spec = ship.getHullSpec();
        
        if (spec.hasTag("CARRIER") && !spec.hasTag("COMBAT")) {
            return -1.0f;
        }
        
        if (spec.isPhase()) return -1.0f;
        
        float slotValue = 0.0f;
        for (WeaponSlotAPI slot : spec.getAllWeaponSlotsCopy()) {
            //Ignore empty slots...
            if (!ship.getVariant().getFittedWeaponSlots().contains(slot.getId())) {
                continue;
            }
            
            //...and slots which have weapons of the wrong type
            if (!WEAPON_TYPES.contains(slot.getWeaponType())) {
                continue;
            }
            switch(slot.getSlotSize()) {
                case SMALL:
                    slotValue += 1.0f;
                    break;
                case MEDIUM:
                    slotValue += 5.0f;
                    break;
                case LARGE:
                    slotValue += 25.0f;
                    break;
            }
        }
        // This means that DP dominates, but large slot advantages can overcome minor DP differences to e.g.
        // deprioritize combat carriers.
        float score = ship.getDeployCost() + 0.1f*slotValue;
        
        return score;
    }
    
    
    
    // Helper class: Sorts by score in descending order    
    private class ShipValueSorter implements Comparator<Entry<ShipAPI,Float>>{
        
        public int compare(Entry<ShipAPI,Float> e1, Entry<ShipAPI,Float> e2){
            //invert order for high to low
            return -1*(e1.getValue().compareTo(e2.getValue()));
                }
        }
    
}
