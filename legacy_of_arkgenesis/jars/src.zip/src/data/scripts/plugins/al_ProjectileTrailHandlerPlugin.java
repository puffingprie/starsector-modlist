//By Nicke535, handles the stranger projectiles in the mod... really, i wanted to split this up, but we are running way too many plugins as it is
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;

import java.awt.*;
import java.util.*;
import java.util.List;

import static org.lwjgl.opengl.GL11.GL_ONE;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;

import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.plugins.MagicTrailPlugin;

public class al_ProjectileTrailHandlerPlugin extends BaseEveryFrameCombatPlugin {

    //A map of all the trail sprites used (note that all the sprites must be under SRD_fx): ensure this one has the same keys as the other maps
    private static final Map<String, String> TRAIL_SPRITES = new HashMap<String, String>();
    static {
        TRAIL_SPRITES.put("al_pellet_tiny", "al_particletrail");
        TRAIL_SPRITES.put("al_pellet_small", "al_particletrail");
        TRAIL_SPRITES.put("al_pellet_medium", "al_particletrail");
        TRAIL_SPRITES.put("al_pellet_large", "al_particletrail");
        TRAIL_SPRITES.put("loa_er_shot", "loa_electrontrail");
        TRAIL_SPRITES.put("loa_er_f_shot", "loa_electrontrail");
        TRAIL_SPRITES.put("loa_her_shot", "loa_electrontrail");
        TRAIL_SPRITES.put("al_bullshot", "al_smoketrail");
        
    }

    //A map for known projectiles and their IDs: should be cleared in init
    private Map<DamagingProjectileAPI, Float> projectileTrailIDs = new WeakHashMap<DamagingProjectileAPI, Float>();

    //Used when doing dual-core sprites
    private Map<DamagingProjectileAPI, Float> projectileTrailIDs2 = new WeakHashMap<DamagingProjectileAPI, Float>();

    //--------------------------------------THESE ARE ALL MAPS FOR DIFFERENT VISUAL STATS FOR THE TRAILS: THEIR NAMES ARE FAIRLY SELF_EXPLANATORY---------------------------------------------------
    private static final Map<String, Float> TRAIL_DURATIONS_IN = new HashMap<String, Float>();
    static {
        TRAIL_DURATIONS_IN.put("al_pellet_tiny", 0f);
        TRAIL_DURATIONS_IN.put("al_pellet_small", 0f);
        TRAIL_DURATIONS_IN.put("al_pellet_medium", 0f);
        TRAIL_DURATIONS_IN.put("al_pellet_large", 0f);
        TRAIL_DURATIONS_IN.put("loa_er_shot", 0f);
        TRAIL_DURATIONS_IN.put("loa_er_f_shot", 0f);
        TRAIL_DURATIONS_IN.put("loa_her_shot", 0f);
        TRAIL_DURATIONS_IN.put("al_bullshot", 0f);
        

    }
    private static final Map<String, Float> TRAIL_DURATIONS_MAIN = new HashMap<String, Float>();
    static {
        TRAIL_DURATIONS_MAIN.put("al_pellet_tiny", 0f);
        TRAIL_DURATIONS_MAIN.put("al_pellet_small", 0f);
        TRAIL_DURATIONS_MAIN.put("al_pellet_medium", 0f);
        TRAIL_DURATIONS_MAIN.put("al_pellet_large", 0f);
        TRAIL_DURATIONS_MAIN.put("loa_er_shot", 0f);
        TRAIL_DURATIONS_MAIN.put("loa_er_f_shot", 0f);
        TRAIL_DURATIONS_MAIN.put("loa_her_shot", 0f);
        TRAIL_DURATIONS_MAIN.put("al_bullshot", 0f);
       
    }
    private static final Map<String, Float> TRAIL_DURATIONS_OUT = new HashMap<String, Float>();
    static {
        TRAIL_DURATIONS_OUT.put("al_pellet_tiny", 1.5f);
        TRAIL_DURATIONS_OUT.put("al_pellet_small", 1.1f);
        TRAIL_DURATIONS_OUT.put("al_pellet_medium", 0.7f);
        TRAIL_DURATIONS_OUT.put("al_pellet_large", 0.3f);
        TRAIL_DURATIONS_OUT.put("loa_er_shot", 0.2f);
        TRAIL_DURATIONS_OUT.put("loa_er_f_shot", 0.2f);
        TRAIL_DURATIONS_OUT.put("loa_her_shot", 0.35f);
        TRAIL_DURATIONS_OUT.put("al_bullshot", 0.8f);
        
    }
    private static final Map<String, Float> START_SIZES = new HashMap<String, Float>();
    static {
        START_SIZES.put("al_pellet_tiny", 2f);
        START_SIZES.put("al_pellet_small", 7f);
        START_SIZES.put("al_pellet_medium", 12f);
        START_SIZES.put("al_pellet_large", 17f);
        START_SIZES.put("loa_er_shot", 20f);
        START_SIZES.put("loa_er_f_shot", 10f);
        START_SIZES.put("loa_her_shot", 25f);
        START_SIZES.put("al_bullshot", 1f);
       
    }
    private static final Map<String, Float> END_SIZES = new HashMap<String, Float>();
    static {
        END_SIZES.put("al_pellet_tiny", 0f);
        END_SIZES.put("al_pellet_small", 0f);
        END_SIZES.put("al_pellet_medium", 0f);
        END_SIZES.put("al_pellet_large", 0f);
        END_SIZES.put("loa_er_shot", 0f);
        END_SIZES.put("loa_er_f_shot", 0f);
        END_SIZES.put("loa_her_shot", 0f);
        END_SIZES.put("al_bullshot", 15f);
       
    }
    private static final Map<String, Color> TRAIL_START_COLORS = new HashMap<String, Color>();
    static {
        TRAIL_START_COLORS.put("al_pellet_tiny", new Color(150,255,255));
        TRAIL_START_COLORS.put("al_pellet_small", new Color(150,255,255));
        TRAIL_START_COLORS.put("al_pellet_medium", new Color(150,255,255));
        TRAIL_START_COLORS.put("al_pellet_large", new Color(150,255,255));
        TRAIL_START_COLORS.put("loa_er_shot", new Color(255,255,150));
        TRAIL_START_COLORS.put("loa_er_f_shot", new Color(255,255,150));
        TRAIL_START_COLORS.put("loa_her_shot", new Color(255,255,150));
        TRAIL_START_COLORS.put("al_bullshot", new Color(255,255,255));
        

    }
    private static final Map<String, Color> TRAIL_END_COLORS = new HashMap<String, Color>();
    static {
        TRAIL_END_COLORS.put("al_pellet_tiny", new Color(150,255,255));
        TRAIL_END_COLORS.put("al_pellet_small", new Color(150,255,255));
        TRAIL_END_COLORS.put("al_pellet_medium", new Color(150,255,255));
        TRAIL_END_COLORS.put("al_pellet_large", new Color(150,255,255));
        TRAIL_END_COLORS.put("loa_er_shot", new Color(255,255,150));
        TRAIL_END_COLORS.put("loa_er_f_shot", new Color(255,255,150));
        TRAIL_END_COLORS.put("loa_her_shot", new Color(255,255,150));
        TRAIL_END_COLORS.put("al_bullshot", new Color(255,255,255));
       
    }
    private static final Map<String, Float> TRAIL_OPACITIES = new HashMap<String, Float>();
    static {
        TRAIL_OPACITIES.put("al_pellet_tiny", 1f);
        TRAIL_OPACITIES.put("al_pellet_small", 1f);
        TRAIL_OPACITIES.put("al_pellet_medium", 1f);
        TRAIL_OPACITIES.put("al_pellet_large", 1f);
        TRAIL_OPACITIES.put("loa_er_shot", 1f);
        TRAIL_OPACITIES.put("loa_er_f_shot", 1f);
        TRAIL_OPACITIES.put("loa_her_shot", 1f);
        TRAIL_OPACITIES.put("al_bullshot", 0.3f);
        
    }
    private static final Map<String, Integer> TRAIL_BLEND_SRC = new HashMap<String, Integer>();
    static {
        TRAIL_BLEND_SRC.put("al_pellet_tiny", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("al_pellet_small", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("al_pellet_medium", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("al_pellet_large", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("loa_er_shot", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("loa_er_f_shot", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("loa_her_shot", GL_SRC_ALPHA);
        TRAIL_BLEND_SRC.put("al_bullshot", GL_SRC_ALPHA);
        
    }
    private static final Map<String, Integer> TRAIL_BLEND_DEST = new HashMap<String, Integer>();
    static {
        TRAIL_BLEND_DEST.put("al_pellet_tiny", GL_ONE);
        TRAIL_BLEND_DEST.put("al_pellet_small", GL_ONE);
        TRAIL_BLEND_DEST.put("al_pellet_medium", GL_ONE);
        TRAIL_BLEND_DEST.put("al_pellet_large", GL_ONE);
        TRAIL_BLEND_DEST.put("loa_er_shot", GL_ONE);
        TRAIL_BLEND_DEST.put("loa_er_f_shot", GL_ONE);
        TRAIL_BLEND_DEST.put("loa_her_shot", GL_ONE);
        TRAIL_BLEND_DEST.put("al_bullshot", GL_ONE);
       
    }
    private static final Map<String, Float> TRAIL_LOOP_LENGTHS = new HashMap<String, Float>();
    static {
        TRAIL_LOOP_LENGTHS.put("al_pellet_tiny", -1f);
        TRAIL_LOOP_LENGTHS.put("al_pellet_small", -1f);
        TRAIL_LOOP_LENGTHS.put("al_pellet_medium", -1f);
        TRAIL_LOOP_LENGTHS.put("al_pellet_large", -1f);
        TRAIL_LOOP_LENGTHS.put("loa_er_shot", -1f);
        TRAIL_LOOP_LENGTHS.put("loa_er_f_shot", -1f);
        TRAIL_LOOP_LENGTHS.put("loa_her_shot", -1f);
        TRAIL_LOOP_LENGTHS.put("al_bullshot", 400f);
        
    }
    private static final Map<String, Float> TRAIL_SCROLL_SPEEDS = new HashMap<String, Float>();
    static {
        TRAIL_SCROLL_SPEEDS.put("al_pellet_tiny", 0f);
        TRAIL_SCROLL_SPEEDS.put("al_pellet_small", 0f);
        TRAIL_SCROLL_SPEEDS.put("al_pellet_medium", 0f);
        TRAIL_SCROLL_SPEEDS.put("al_pellet_large", 0f);
        TRAIL_SCROLL_SPEEDS.put("loa_er_shot", 0f);
        TRAIL_SCROLL_SPEEDS.put("loa_er_f_shot", 0f);
        TRAIL_SCROLL_SPEEDS.put("loa_her_shot", 0f);
        TRAIL_SCROLL_SPEEDS.put("al_bullshot", 50f);
        
    }
    private static final Map<String, Boolean> TRAIL_SHARES_SIDEWAY_VELOCITY = new HashMap<String, Boolean>();
    static {
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("al_pellet_tiny", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("al_pellet_small", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("al_pellet_medium", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("al_pellet_large", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("loa_er_shot", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("loa_er_f_shot", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("loa_her_shot", true);
        TRAIL_SHARES_SIDEWAY_VELOCITY.put("al_bullshot", false);

    }

    @Override
    public void init(CombatEngineAPI engine) {
        //Reinitialize the lists
        projectileTrailIDs.clear();
        projectileTrailIDs2.clear();
    }

    @Override
    public void advance (float amount, List<InputEventAPI> events) {
        if (Global.getCombatEngine() == null || Global.getCombatEngine().isPaused()) {
            return;
        }
        CombatEngineAPI engine = Global.getCombatEngine();

        //Runs once on each projectile that matches one of the IDs specified in our maps
        for (DamagingProjectileAPI proj : engine.getProjectiles()) {
            //Ignore already-collided projectiles, and projectiles that don't match our IDs
            if (proj.getProjectileSpecId() == null || proj.didDamage()) {
                continue;
            }

            //-------------------------------------------For visual effects---------------------------------------------
            if (!TRAIL_SPRITES.keySet().contains(proj.getProjectileSpecId())) {
                continue;
            }
            String specID = proj.getProjectileSpecId();
            SpriteAPI spriteToUse = Global.getSettings().getSprite("al_fx", TRAIL_SPRITES.get(specID));

            //If we haven't already started a trail for this projectile, get an ID for it
            if (projectileTrailIDs.get(proj) == null) {
                projectileTrailIDs.put(proj, MagicTrailPlugin.getUniqueID());
            }

            //Calculates sideway velocity for the projectile, if we have that option enabled
            Vector2f sidewayVel = new Vector2f(0f,0f);
            if (TRAIL_SHARES_SIDEWAY_VELOCITY.get(specID)) {
                //First, get the vector for its "true forward" velocity
                Vector2f frontVector = new Vector2f((float)FastTrig.cos(Math.toRadians(proj.getFacing())), (float)FastTrig.sin(Math.toRadians(proj.getFacing())));

                //Then, we use dot product to determine how much of our "actual" speed vector lines up with our "true forward" velocity
                float lengthOfProjection = Vector2f.dot(frontVector, proj.getVelocity());

                //Then, we remove our projected velocity from our actual velocity
                frontVector.scale(lengthOfProjection);
                sidewayVel = Vector2f.sub(proj.getVelocity(), frontVector, new Vector2f(0f, 0f));
            }

            //Then, actually spawn a trail
            //Custom for my_smoky_projectile1: example projectile for a wispy smoky fadeout trail.
            //Configure endSpeedSize and endAngleVelSize to get more or less spread
            if (specID.equals("loa_nickeshot") ||  specID.equals("loa_nickeshot_he")) {
                float endSpeedSize = 360f;
                float endAngleVelSize = 360f;
                MagicTrailPlugin.addTrailMemberAdvanced(proj, projectileTrailIDs.get(proj), spriteToUse, proj.getLocation(),
                        0f, MathUtils.getRandomNumberInRange(-endSpeedSize, endSpeedSize), proj.getFacing() - 180f,
                        0f, MathUtils.getRandomNumberInRange(-endAngleVelSize, endAngleVelSize),
                        START_SIZES.get(specID), END_SIZES.get(specID), TRAIL_START_COLORS.get(specID), TRAIL_END_COLORS.get(specID),
                        TRAIL_OPACITIES.get(specID), TRAIL_DURATIONS_IN.get(specID), TRAIL_DURATIONS_MAIN.get(specID),
                        TRAIL_DURATIONS_OUT.get(specID), TRAIL_BLEND_SRC.get(specID),
                        TRAIL_BLEND_DEST.get(specID), TRAIL_LOOP_LENGTHS.get(specID), TRAIL_SCROLL_SPEEDS.get(specID),
                        sidewayVel, null, CombatEngineLayers.CONTRAILS_LAYER, 1f);

            //Default case: no special trail attributes
            } else {
                MagicTrailPlugin.addTrailMemberAdvanced(proj, projectileTrailIDs.get(proj), spriteToUse, proj.getLocation(),
                        0f, 0f, proj.getFacing() - 180f,0f, 0f,
                        START_SIZES.get(specID), END_SIZES.get(specID), TRAIL_START_COLORS.get(specID), TRAIL_END_COLORS.get(specID),
                        TRAIL_OPACITIES.get(specID), TRAIL_DURATIONS_IN.get(specID), TRAIL_DURATIONS_MAIN.get(specID),
                        TRAIL_DURATIONS_OUT.get(specID), TRAIL_BLEND_SRC.get(specID), TRAIL_BLEND_DEST.get(specID),
                        TRAIL_LOOP_LENGTHS.get(specID), TRAIL_SCROLL_SPEEDS.get(specID), sidewayVel, null,
                        CombatEngineLayers.CONTRAILS_LAYER, 1f);
            }
        }
    }
}