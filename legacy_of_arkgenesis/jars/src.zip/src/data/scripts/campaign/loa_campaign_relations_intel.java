package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class loa_campaign_relations_intel extends BaseIntelPlugin {
    //The ID for the Anarakis
    private static final String MAIN_FACTION = "al_ars";

    //Which faction are we angry at this time?
    private FactionAPI factionToBeAngryAt = null;

    //Which faction hired us? Can be ourselves, meaning no-one hired us
    private FactionAPI factionThatHired = null;

    //How long does the intel show for after the event ends?
    private static final float DAYS_TO_LAST_AFTER_ENDING = 30f;

    //In-script tracker to remain longer than usual
    private float daysAfterEnding = 0f;

    //Why is this needed?
    private boolean customEnding = false;

    //Main advance function; runs the normal apply stuff, and ticks down our "ending" counter
    @Override
    public void advanceImpl(float amount) {
        //Only handle this stuff if we've already started ending
        if (customEnding) {
            daysAfterEnding += Misc.getDays(amount);
            if (daysAfterEnding > DAYS_TO_LAST_AFTER_ENDING) {
                endImmediately();
                Global.getSector().removeScript(this);
            }
        }
    }

    //Whether the Intel is done or not. By default, it's linked to "endAfterDelay()" in some way
    @Override
    public boolean isDone() {
        return super.isDone();
    }

    //Initializer function
    public loa_campaign_relations_intel(FactionAPI factionToBeAngryAt, FactionAPI factionThatHired) {
        this.factionToBeAngryAt = factionToBeAngryAt;
        this.factionThatHired = factionThatHired;
    }

    //The function for when we "actually" end. Clears up memory, removes us from the sector, and clears some unnecessary variables
    @Override
    protected void notifyEnded() {
        super.notifyEnded();
        Global.getSector().removeScript(this);
    }

    //My own function, ends the intel since we are no longer hostile. Has a delay for "properly" ending stuff
    public void endThisIntel () {
        customEnding = true;
        endAfterDelay();
    }

    //Not *entirely* sure what this does. Probably related to rules.csv
    @Override
    public boolean callEvent(String ruleId, InteractionDialogAPI dialog,
                             List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        return true;
    }

    //Running this function ends the event, after a delay (around a couple of days, as far as I can tell)
    @Override
    public void endAfterDelay() {
        super.endAfterDelay();
    }


    //The function for adding all bullet-points in the Intel tooltip. This one doesn't have bullet-points, so it's effectively unused
    protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode) {

        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        float pad = 3f;
        float opad = 10f;

        float initPad = pad;
        if (mode == ListInfoMode.IN_DESC) initPad = opad;

        Color tc = getBulletColorForMode(mode);

        bullet(info);
        boolean isUpdate = getListInfoParam() != null;

        unindent(info);
    }

    //The function for writing the detailed info in the Intel screen.
    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
        Color c = getTitleColor(mode);
        info.setParaSmallInsignia();
        info.addPara(getName(), c, 0f);
        info.setParaFontDefault();
        addBulletPoints(info, mode);
    }

    //The small description for the intel screen.
    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        Color tc = Misc.getTextColor();
        float pad = 3f;
        float opad = 10f;

        //We use slightly different texts depending on whether the event is ending or not. We also have different text if we were sponsored
        if (isEnding()) {
            if (factionThatHired == Global.getSector().getFaction(MAIN_FACTION)) {
                LabelAPI label = info.addPara("The " + Global.getSector().getFaction(MAIN_FACTION).getDisplayName() + " are scaling back their attacks against "
                                + factionToBeAngryAt.getDisplayNameWithArticle() + ". It seems they got what they wanted, and relations have somewhat normalized.",
                        opad);
                label.setHighlightColors(Global.getSector().getFaction(MAIN_FACTION).getBaseUIColor(), factionToBeAngryAt.getBaseUIColor());
                label.setHighlight(Global.getSector().getFaction(MAIN_FACTION).getDisplayName(), factionToBeAngryAt.getDisplayName());
            } else {
                LabelAPI label = info.addPara("The " + Global.getSector().getFaction(MAIN_FACTION).getDisplayName() + " are scaling back their attacks against "
                                + factionToBeAngryAt.getDisplayNameWithArticle() + " and relations are starting to normalize. Rumors and various intel heavily suggest that "
                                + factionThatHired.getDisplayNameWithArticle() + " sponsored the attack, but have now cut the funding.",
                        opad);
                label.setHighlightColors(Global.getSector().getFaction(MAIN_FACTION).getBaseUIColor(), factionToBeAngryAt.getBaseUIColor(), factionThatHired.getBaseUIColor());
                label.setHighlight(Global.getSector().getFaction(MAIN_FACTION).getDisplayName(), factionToBeAngryAt.getDisplayName(), factionThatHired.getDisplayName());
            }
        } else {
            LabelAPI label = info.addPara("The " + Global.getSector().getFaction(MAIN_FACTION).getDisplayName() + "  are currently targeting "
                            + factionToBeAngryAt.getDisplayNameWithArticle() + " with regular attacks. "
                            + "It remains unknown whether this is an independant initiative, or if they are being funded by someone else.", opad);
            label.setHighlightColors(Global.getSector().getFaction(MAIN_FACTION).getBaseUIColor(), factionToBeAngryAt.getBaseUIColor());
            label.setHighlight(Global.getSector().getFaction(MAIN_FACTION).getDisplayName(), factionToBeAngryAt.getDisplayName());
        }

        addBulletPoints(info, ListInfoMode.IN_DESC);
    }

    //Sets which icon the Intel screen should display. Can vary based on circumstances, but a single one often works just fine
    //Should probably be set to the Anarakis faction icon... or maybe the raided faction's icon?
    @Override
    public String getIcon() {
        return Global.getSettings().getSpriteName("loa_intel", "loa_raid");
    }

    //This sets which "tags" the event has in the Intel screen. For example, giving it the Tags.INTEL_STORY tag makes it appear in the "Story" sub-category
    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        tags.add(Tags.INTEL_HOSTILITIES);
        tags.add(MAIN_FACTION);
        return tags;
    }

    //Sorting-related; see it as a form of "how important is the even" thingy. Lower number = more important
    @Override
    public IntelSortTier getSortTier() {
        return IntelSortTier.TIER_4;
    }

    //What string to sort with, when sorting alphabetically
    public String getSortString() {
        return "Society Raids";
    }

    //The name of the event; can vary based on circumstances. I decided to just make it say "Ended" when completed
    public String getName() {
        if (isEnded() || isEnding()) {
            return "Society Raids - Ended";
        }
        return "Society Raids";
    }

    //Here, you can set which faction's UI colors to use. The default is to use the player's faction.
    //Should probably be switched to the Anarakis faction
    @Override
    public FactionAPI getFactionForUIColors() {
        return Global.getSector().getFaction(MAIN_FACTION);
    }

    //This just seems to call back to the name again
    public String getSmallDescriptionTitle() {
        return getName();
    }

    //Where does this event "originate" on the map
    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        return Global.getSector().getPlayerFleet();
    }

    //Whether the intel should be removed from the intel screen. By default only called once the event is over
    @Override
    public boolean shouldRemoveIntel() {
        return isEnded();
    }

    //Which sound the Comms should make from getting the intel. Some default values include:
    //  getSoundMajorPosting();
    //  getSoundStandardUpdate();
    //  getSoundLogUpdate();
    //  getSoundColonyThreat();
    //  getSoundStandardPosting();
    //  getSoundStandardUpdate();
    //Other values can be inputted, from sounds.json
    @Override
    public String getCommMessageSound() {
        return getSoundStandardPosting();
    }

    //Gets the faction that hired this specific intel
    public FactionAPI getFactionThatHired() {
        return factionThatHired;
    }
}



