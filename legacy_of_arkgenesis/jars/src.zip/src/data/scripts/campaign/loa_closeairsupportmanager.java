package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.hullmods.loa_closeairsupport;

import java.util.List;

/**
 * Manages adding and removing the Close Air Support hullmod from ships with LoA's CAS fighters
 */
public class loa_closeairsupportmanager implements EveryFrameScript {
    //How often the game should verify the player fleet has the right hullmods when not in refit. Counted in seconds
    private IntervalUtil longTimer = new IntervalUtil(9f, 11f);

    //The hullmod to add/remove should the ship have any of the required fighters
    public static final String HULLMOD_ID = "loa_closeairsupport";

    //We check every frame whether we are in the refit screen, and if so, we run "truly" every frame
    //Otherwise, we only run once every couple of seconds or so, to save on performance
    @Override
    public void advance(float amount) {
        boolean shouldRun = false;

        boolean inRefit = false;
        if (Global.getCombatEngine() != null
            && Global.getCurrentState().equals(GameState.CAMPAIGN)
            && Global.getSector().isPaused()) {
            inRefit = true;
        }

        if (Global.getCurrentState().equals(GameState.COMBAT)) {
            return;
        }

        if (inRefit) {
            shouldRun = true;
        } else {
            longTimer.advance(amount);
            if (longTimer.intervalElapsed()) {
                shouldRun = true;
            }
        }

        if (shouldRun) {
            CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();

            //Iterates through all ships in the player fleet
            for (FleetMemberAPI member : playerFleet.getFleetData().getMembersListCopy()) {
                ShipVariantAPI variant = member.getVariant();

                //Check if we have any of the required fighters (or fighters at all!)
                boolean updated = false;
                if (variant != null && !variant.getWings().isEmpty()) {
                    List<String> wings = variant.getWings();
                    boolean hasSupportWing = false;
                    for (int i = 0; i < wings.size(); i++) {
                        FighterWingSpecAPI wing = variant.getWing(i);
                        if (wing != null && //One-frame issue with how refit works
                                loa_closeairsupport.wingHasSupportBonus(wing.getId())) {
                            hasSupportWing = true;
                            break;
                        }
                    }
                    if (hasSupportWing && !variant.hasHullMod(HULLMOD_ID)) {
                        updated = true;
                        variant.addMod(HULLMOD_ID);
                    } else if (!hasSupportWing && variant.hasHullMod(HULLMOD_ID)) {
                        updated = true;
                        variant.removeMod(HULLMOD_ID);
                    }
                }

                if (updated) {
                    member.updateStats();
                }
            }
        }
    }

    //Seeing as we're UI related, running while paused seems like a good idea
    @Override
    public boolean runWhilePaused() {
        return true;
    }

    //Never stop running
    @Override
    public boolean isDone() {
         return false;
    }
}
