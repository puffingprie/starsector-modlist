//By Nicke535, spawns markets in the campaign similar to how Pirate and Pather bases are spawned
package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.deciv.DecivTracker;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.al_ArkgneisisModPlugin;
import exerelin.campaign.SectorManager;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class loa_spawnRandomMarketsPlugin implements EveryFrameScript {
    //A debug logger to more easily track what the script is doing
    public static Logger log = Global.getLogger(loa_spawnRandomMarketsPlugin.class);

    //The faction which gets new markets added for them
    static final public String OUR_FACTION = "al_ars";

    //Our faction will unlock this ship once all market slots are filled
    static final private String FACTION_SPECIAL_SHIP_UNLOCK = "loamt_gaillard";

    //The industries all markets start with when spawned
    static final private List<String> STARTING_INDUSTRIES = new ArrayList<>();
    static {
        STARTING_INDUSTRIES.add("loa_asteroid_orbitalstation");
        STARTING_INDUSTRIES.add(Industries.SPACEPORT);
        
    }

    //A whitelist for non-procgen systems that can get markets added to them
    static final private List<String> WHITELISTED_SYSTEMS = new ArrayList<>();
    static {
        //WHITELISTED_SYSTEMS.add("zagan");
        WHITELISTED_SYSTEMS.add("duzhak");
        //WHITELISTED_SYSTEMS.add("yma");
        //WHITELISTED_SYSTEMS.add("magec");
        //WHITELISTED_SYSTEMS.add("mayasura");
        //WHITELISTED_SYSTEMS.add("westernesse");
        //WHITELISTED_SYSTEMS.add("thule");
        //WHITELISTED_SYSTEMS.add("kumarikandam");
        //WHITELISTED_SYSTEMS.add("isirah");
        //WHITELISTED_SYSTEMS.add("tyle");
        //WHITELISTED_SYSTEMS.add("algebbar");
        WHITELISTED_SYSTEMS.add("tia");
        WHITELISTED_SYSTEMS.add("penelopesstar");
        WHITELISTED_SYSTEMS.add("ursulo");
    }

    //The possible market names the spawned markets can have (not counting suffixes, those are handled seperately)
    static final private List<String> POSSIBLE_NAMES = new ArrayList<>();
    static {
        POSSIBLE_NAMES.add("Adder");
        POSSIBLE_NAMES.add("Alpha");
        POSSIBLE_NAMES.add("Beta");
        POSSIBLE_NAMES.add("Chandelier");
        POSSIBLE_NAMES.add("Conglomerate");
        POSSIBLE_NAMES.add("Castle");
        POSSIBLE_NAMES.add("Chameleon");
        POSSIBLE_NAMES.add("Cobra");
        POSSIBLE_NAMES.add("Delta");
        POSSIBLE_NAMES.add("Dragon");
        POSSIBLE_NAMES.add("Existential");
        POSSIBLE_NAMES.add("Echo");
        POSSIBLE_NAMES.add("Etch");
        POSSIBLE_NAMES.add("Fortress");
        POSSIBLE_NAMES.add("Fulcrum");
        POSSIBLE_NAMES.add("Ferrous");
        POSSIBLE_NAMES.add("Gamma");
        POSSIBLE_NAMES.add("Genocide");
        POSSIBLE_NAMES.add("Gecko");
        POSSIBLE_NAMES.add("Holdout");
        POSSIBLE_NAMES.add("Hognose");
        POSSIBLE_NAMES.add("Indignity");
        POSSIBLE_NAMES.add("Igneous");
        POSSIBLE_NAMES.add("Iguana");
        POSSIBLE_NAMES.add("Jump Point");
        POSSIBLE_NAMES.add("Kappa");
        POSSIBLE_NAMES.add("Karaoke");
        POSSIBLE_NAMES.add("Krait");
        POSSIBLE_NAMES.add("Komodo");
        POSSIBLE_NAMES.add("Lima");
        POSSIBLE_NAMES.add("Lug");
        POSSIBLE_NAMES.add("Lever");
        POSSIBLE_NAMES.add("Lupo");
        POSSIBLE_NAMES.add("Lizard");
        POSSIBLE_NAMES.add("Manifest");
        POSSIBLE_NAMES.add("Monitor");
        POSSIBLE_NAMES.add("Merlin");
        POSSIBLE_NAMES.add("Neo");
        POSSIBLE_NAMES.add("Newt");
        POSSIBLE_NAMES.add("Operation");
        POSSIBLE_NAMES.add("Outcrop");
        POSSIBLE_NAMES.add("Parasol");
        POSSIBLE_NAMES.add("Plutonic");
        POSSIBLE_NAMES.add("Python");
        POSSIBLE_NAMES.add("Pivot");
        POSSIBLE_NAMES.add("Pulley");
        POSSIBLE_NAMES.add("Quixote");
        POSSIBLE_NAMES.add("Rotary");
        POSSIBLE_NAMES.add("Rocky");
        POSSIBLE_NAMES.add("Raptor");
        POSSIBLE_NAMES.add("Rex");
        POSSIBLE_NAMES.add("Rampart");
        POSSIBLE_NAMES.add("Sigma");
        POSSIBLE_NAMES.add("Silicate");
        POSSIBLE_NAMES.add("Saurus");
        POSSIBLE_NAMES.add("Sidewinder");
        POSSIBLE_NAMES.add("Salamander");
        POSSIBLE_NAMES.add("Theta");
        POSSIBLE_NAMES.add("Tower");
        POSSIBLE_NAMES.add("Toad");
        POSSIBLE_NAMES.add("Tegu");
        POSSIBLE_NAMES.add("Undercroft");
        POSSIBLE_NAMES.add("Uber");
        POSSIBLE_NAMES.add("Victory");
        POSSIBLE_NAMES.add("Viper");
        POSSIBLE_NAMES.add("Window");
        POSSIBLE_NAMES.add("Wyvern");
        POSSIBLE_NAMES.add("Xeno");
        POSSIBLE_NAMES.add("Yellow");
        POSSIBLE_NAMES.add("Zeta");
    }

    //The maximum distance a market can spawn away from the sector's center. Making this too low *might* cause issues
    static final private float MAX_SPAWN_DISTANCE = 25000f;

    //The cooldowns between market spawns; the more markets have already spawned, the closer the cooldown gets to
    //the maximum (and vice versa). Specified in days
    static final private float MINIMUM_SPAWN_COOLDOWN = 30f;
    static final private float MAXIMUM_SPAWN_COOLDOWN = 90f;

    //The maximum total number of markets this script can spawn, in total
    static final private int MAX_MARKETS_SPAWNED = 5;

    //How many tier 2/3 markets can exist at any given time
    static final private int MAX_TIER_2_MARKETS = 2;
    static final private int MAX_TIER_3_MARKETS = 2;

    //How long do we have to wait with spawning new markets if we lose our headquarters?
    static final private float COOLDOWN_AFTER_HEADQUARTER_LOSS = 1f;

    //Cooldown for a given system in case its market is destroyed, so we don't immediately respawn in the same spot
    static final private float COOLDOWN_PER_SYSTEM_AFTER_BASE_LOSS = 1f;


    //  --- Internal script variables below: don't touch! ---
    //Stores all our existing markets (or rather, their upgrade handlers), so we can check when we need new ones
    public List<loa_UpgradingMarketHandler> existingMarkets = new ArrayList<>();

    //The current headquarters we have. If null, we don't have a headquarters at the moment and can't spawn markets
    private MarketAPI headquarters = null;

    //How long we have left until a new headquarters is declared
    private float cooldownLeftForNewHeadquarters = COOLDOWN_AFTER_HEADQUARTER_LOSS;

    //If we lost our original headquarters at some point. If so, we get half the market spawn rate
    private boolean lostOriginalHeadquarters = false;

    //The timer for spawning new markets
    private float marketSpawnCooldown = 0f;

    //Cooldown for the individual systems, in case our base there has been recently destroyed (or the base is still there!)
    private HashMap<StarSystemAPI, Float> systemSpawnCooldowns = new HashMap<>();

    //An extra timer for checking some semi-common occurances
    private float sinceLastMarketCheck = 0f;


    //Initializer; just reads a headquarters
    public loa_spawnRandomMarketsPlugin (MarketAPI headquarters) {
        this.headquarters = headquarters;
        log.info(String.format("Successfully added the market spawner script; our headquarters is [%s]", headquarters.getName()));
    }


    //Main Advance function; adds new markets up to a cap, with a cooldown
    @Override
    public void advance(float amount) {
        //Check if the faction is entirely gone; in that case, don't do anything as the script is about to be deleted
        if (Misc.getFactionMarkets(Global.getSector().getFaction(OUR_FACTION)).isEmpty()) {
            return;
        }

        //Tick down our system-unique cooldowns
        for (StarSystemAPI system : systemSpawnCooldowns.keySet()) {
            float currentCooldown = systemSpawnCooldowns.get(system);
            systemSpawnCooldowns.put(system, currentCooldown-Misc.getDays(amount));
        }

        //Check the condition of our headquarters; if it's somehow gone or another faction has stolen it, we count as having lost it
        if (headquarters == null || !headquarters.getFactionId().equals(OUR_FACTION)) {
            lostOriginalHeadquarters = true;
            headquarters = null;
            cooldownLeftForNewHeadquarters -= Misc.getDays(amount);

            //Once our cooldown for getting a new HQ is up, select the biggest market we have to be the new one
            if (cooldownLeftForNewHeadquarters <= 0f) {
                cooldownLeftForNewHeadquarters = COOLDOWN_AFTER_HEADQUARTER_LOSS;
                loa_UpgradingMarketHandler newHQ = null;
                for (loa_UpgradingMarketHandler potentialHQ : existingMarkets) {
                    if (newHQ == null) {
                        newHQ = potentialHQ;
                    } else if (newHQ.getCurrentTier() < potentialHQ.getCurrentTier()) {
                        newHQ = potentialHQ;
                    }
                }
                if (newHQ != null) {
                    headquarters = newHQ.getMarket();
                    if (al_ArkgneisisModPlugin.isExerelin) {
                        headquarters.setHidden(false);
                        SectorManager.factionRespawned(headquarters.getFaction(), headquarters);
                    }
                }
            }
        }

        //Occasionally remove markets from other sources to give us a free new market
        sinceLastMarketCheck += Misc.getDays(amount);
        if (sinceLastMarketCheck >= 2f) {
            sinceLastMarketCheck = 0f;
            List<MarketAPI> factionMarkets = Misc.getFactionMarkets(Global.getSector().getFaction(OUR_FACTION));
            List<MarketAPI> toRemove = new ArrayList<>();
            for (MarketAPI market : factionMarkets) {
                if (headquarters != market) {
                    boolean existing = false;
                    for (loa_UpgradingMarketHandler entry : existingMarkets) {
                        if (entry.getMarket() == market) {
                            existing = true;
                            break;
                        }
                    }
                    if (!existing) {
                        toRemove.add(market);
                    }
                }
            }

            for (MarketAPI market : toRemove) {
                //Each removed market needs to be removed, but is also scavenged for a new base (with 1 month of upgrades per market size)
                List<StarSystemAPI> validSystems = getValidSpawnSystems();

                //If our list of systems is empty, we stop here; there simply aren't any places to spawn them!
                if (validSystems.size() <= 0) {
                    return;
                }

                //Now that we have a list of valid systems, pick one at random to try and spawn in.
                //  Run this up to 10 times, or until the spawning is successful
                loa_UpgradingMarketHandler resultingHandler = null;
                for (int i = 0; i < 10; i++) {
                    resultingHandler = spawnMarket(validSystems.get(MathUtils.getRandomNumberInRange(0, validSystems.size()-1)));
                    if (resultingHandler != null) {
                        break;
                    }
                }

                //If we didn't get any handler, the script didn't successfully create a market. In this case, it's fine, since it's a "bonus" market
                if (resultingHandler != null) {
                    //Since we got a valid handler, we add it to our list of handlers and prevent spawns in that system for the foreseeable future
                    existingMarkets.add(resultingHandler);
                    systemSpawnCooldowns.put(resultingHandler.getMarket().getStarSystem(), Float.MAX_VALUE);
                    //Then, since this was a special spawn, we advance the upgrade handler a couple of months depending on removed market size
                    for (int i = 0; i < market.getSize(); i++) {
                        resultingHandler.advance(Global.getSector().getClock().convertToSeconds(30f));
                    }
                }

                //The actual market removal runs here
                log.info(Global.getSector().getFaction(OUR_FACTION).getDisplayNameWithArticle()+" has abandoned the market "+market.getName());
                DecivTracker.removeColony(market, false);
                factionMarkets.remove(market);
            }

            //In addition, on the same timer, also check if we can currently unlock the special ship we get for having full market capacity
            boolean getsSpecialShip = false;
            if (existingMarkets.size() >= MAX_MARKETS_SPAWNED) {
                //Sneaky re-use here: if we don't have room to upgrade to tier 2 or 3, it means those tiers are full
                if (headquarters != null
                    && !roomToUpgradeToTier(2, null)
                    && !roomToUpgradeToTier(3, null)) {
                    getsSpecialShip = true;
                }
            }
            if (getsSpecialShip) {
                if (!Global.getSector().getFaction(OUR_FACTION).knowsShip(FACTION_SPECIAL_SHIP_UNLOCK)) {
                    Global.getSector().getFaction(OUR_FACTION).addKnownShip(FACTION_SPECIAL_SHIP_UNLOCK, true);
                    log.info("Special ship unlock has been added to the Anarakis! Their enemies best beware!");
                }
            } else {
                if (Global.getSector().getFaction(OUR_FACTION).knowsShip(FACTION_SPECIAL_SHIP_UNLOCK)) {
                    Global.getSector().getFaction(OUR_FACTION).removeKnownShip(FACTION_SPECIAL_SHIP_UNLOCK);
                    log.info("The Anarakis special ship unlock has been disabled; seems like their enemies successfully crippled their economy.");
                }
            }
        }


        //Gets a multiplier for cooldown ticking, depending on headquarter status
        float spawnRateMult = 1f;
        if (lostOriginalHeadquarters) { spawnRateMult *= 0.5f; }
        if (headquarters == null) { spawnRateMult *= 0f; }

        //Tick down our market-spawning cooldown, unless we already have the maximum number of markets
        if (existingMarkets.size() < MAX_MARKETS_SPAWNED) {
            marketSpawnCooldown -= Misc.getDays(amount)*spawnRateMult;
        }

        //If our cooldown is over, spawn a new market
        if (marketSpawnCooldown <= 0f) {
            //Prepares to spawn a new market; gets a list of systems that can get a market added
            List<StarSystemAPI> validSystems = getValidSpawnSystems();

            //If our list of systems is empty, we stop here; there simply aren't any places to spawn them! Also print debug stuff
            if (validSystems.size() <= 0) {
                log.info("Could not find any system to add a market to!");
                marketSpawnCooldown = 1f;
                return;
            }

            //Now that we have a list of valid systems, pick one at random to try and spawn in.
            //  Run this up to 10 times, or until the spawning is successful
            loa_UpgradingMarketHandler resultingHandler = null;
            for (int i = 0; i < 10; i++) {
                resultingHandler = spawnMarket(validSystems.get(MathUtils.getRandomNumberInRange(0, validSystems.size()-1)));
                if (resultingHandler != null) {
                    break;
                }
            }

            //If we didn't get any handler, the script didn't successfully create a market
            if (resultingHandler != null) {
                //Since we got a valid handler, we add it to our list of handlers and set a cooldown for the next market spawn
                existingMarkets.add(resultingHandler);
                marketSpawnCooldown = MINIMUM_SPAWN_COOLDOWN * ((float)(MAX_MARKETS_SPAWNED - existingMarkets.size())/(float)MAX_MARKETS_SPAWNED) +
                        MAXIMUM_SPAWN_COOLDOWN * ((float)existingMarkets.size()/(float)MAX_MARKETS_SPAWNED);
                //Also prevent spawns in that system for the foreseeable future
                systemSpawnCooldowns.put(resultingHandler.getMarket().getStarSystem(), Float.MAX_VALUE);
            } else {
                //Even if we didn't get a handler, we still set some cooldown, so we don't swamp the engine with all our system checking
                marketSpawnCooldown = 1f;
            }
        }
    }

    private List<StarSystemAPI> getValidSpawnSystems() {
        List<StarSystemAPI> validSystems = new ArrayList<>();
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            //Ignore systems too recently visited
            if (Global.getSector().getClock().getElapsedDaysSince(system.getLastPlayerVisitTimestamp()) < 30f) {
                continue;
            }

            //Ignore any system that has an active base in it, or is on "spawn cooldown" from recently losing a base
            if (systemIsLockedFromSpawning(system)) {
                continue;
            }

            //Ignore Non-Procgen systems
            if (!system.isProcgen()) {
                continue;
            }

            //Ignore heavy/medium Remnant systems
            if (system.hasTag(Tags.THEME_REMNANT_MAIN) || system.hasTag(Tags.THEME_REMNANT_RESURGENT)) {
                continue;
            }

            //Ignore Pulsar systems
            if (system.hasPulsar()) {
                continue;
            }

            //Also, ignore things too far away from the sector's center
            if (MathUtils.getDistance(system.getLocation(), Misc.ZERO) > MAX_SPAWN_DISTANCE){
                continue;
            }

            //If it passed all earlier checks, add it as a valid system
            validSystems.add(system);
        }

        //Systems in our whitelist are always allowed, unless we visited them too recently or already have a base/cooldown there
        //Or if we have a market there from some other faction, as that would reveal us
        for (String systemName : WHITELISTED_SYSTEMS) {
            StarSystemAPI system = Global.getSector().getStarSystem(systemName);
            if (system == null) {
                continue;
            }
            if (Global.getSector().getClock().getElapsedDaysSince(system.getLastPlayerVisitTimestamp()) < 30f) {
                continue;
            }
            if (systemIsLockedFromSpawning(system)) {
                continue;
            }
            validSystems.add(system);
        }
        return validSystems;
    }


    //Spawns a market in a designated system. Returns the upgrade handler for the market, or Null if the market creation failed
    private loa_UpgradingMarketHandler spawnMarket(StarSystemAPI system) {
        //Generates a name for the market/entity (it'll get a suffix from its upgrader script later)
        String name = null;
        List<String> unusedNames = new ArrayList<>();
        for (String potName : POSSIBLE_NAMES) {
            boolean isUsed = false;
            for (loa_UpgradingMarketHandler otherMarket : existingMarkets) {
                if (otherMarket.getBaseName().equals(potName)) {
                    isUsed = true;
                    break;
                }
            }
            if (!isUsed) {unusedNames.add(potName);}
        }
        if (!unusedNames.isEmpty()) {name = unusedNames.get(MathUtils.getRandomNumberInRange(0, unusedNames.size()-1));}
        if (name == null) {
            return null;
        }

        //Finds a location in the system to spawn (note that we only spawn in asteroid belts/fields, and highly prefer fields); reports an error if no valid location was found
        LinkedHashMap<BaseThemeGenerator.LocationType, Float> weights = new LinkedHashMap<BaseThemeGenerator.LocationType, Float>();
        weights.put(BaseThemeGenerator.LocationType.IN_ASTEROID_BELT, 1f);
        weights.put(BaseThemeGenerator.LocationType.IN_ASTEROID_FIELD, 10f);
        WeightedRandomPicker<BaseThemeGenerator.EntityLocation> locs = BaseThemeGenerator.getLocations(null, system, null, 100f, weights);
        BaseThemeGenerator.EntityLocation loc = locs.pick();
        if (loc == null) {
            return null;
        }
        //Double-check our location is not orbiting a jump point. If it is, we failed this location finding instance
        if (loc.orbit.getFocus() != null && loc.orbit.getFocus() instanceof JumpPointAPI) {
            return null;
        }

        //Creates the station we're going to throw the market on
        BaseThemeGenerator.AddedEntity added = BaseThemeGenerator.addNonSalvageEntity(system, loc, "al_random_arsbase", OUR_FACTION);
        if (added == null || added.entity == null) {
            return null;
        }
        SectorEntityToken entity = added.entity;

        //Instantiates a market of size 3, and make sure it is hidden from the main screen
        MarketAPI market = Global.getFactory().createMarket(Misc.genUID(), "New Base", 3);
        market.setSize(3);
        market.setHidden(true);
        market.setEconGroup(OUR_FACTION+market.getId());

        //Adjusts our survey level
        market.setFactionId(OUR_FACTION);
        market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);

        //Instantiates a base state
        market.setFactionId(OUR_FACTION);
        market.addCondition(Conditions.POPULATION_3);

        //All markets have population, so we add that. Also go through our "starting" industries and add those
        market.addIndustry(Industries.POPULATION);
        for (String indus : STARTING_INDUSTRIES) {
            market.addIndustry(indus);
        }

        //Adds appropriate submarkets
        market.addSubmarket(Submarkets.SUBMARKET_OPEN);
        market.addSubmarket(Submarkets.SUBMARKET_BLACK);

        //Sets tariff
        market.getTariff().modifyFlat("default_tariff", market.getFaction().getTariffFraction());

        //Sets both the entity's and market's name to the random name we selected (this will later be adjusted)
        market.setName(name);
        entity.setName(name);

        //Links the market and entity together
        market.setPrimaryEntity(entity);
        entity.setMarket(market);

        //(Hopefully) stealths the base
        entity.setSensorProfile(1000f);
        entity.setDiscoverable(true);
        entity.getDetectedRangeMod().modifyFlat("gen", 5000f);

        market.getMemoryWithoutUpdate().set("$nex_unbuyable", true);
        
        //Reapplies our industries to ensure the effects are correct
        market.reapplyIndustries();

        //Adds the market to the economy
        Global.getSector().getEconomy().addMarket(market, true);

        //Creates the upgrade handler and adds it to the sector
        loa_UpgradingMarketHandler handler = new loa_UpgradingMarketHandler(entity, market, this, name);

        //Adds an economy fixer to the economy to handle imports of our markets
        Global.getSector().getEconomy().addUpdateListener(new EconomyFixer(market));

        //Outputs that we've added the market to the log
        log.info(String.format("Added new base in [%s]. It's named [%s]", system.getName(), name));

        //Returns the upgrade handler
        return handler;
    }


    //A check if there is "room" for a market to upgrade to a certain tier
    public boolean roomToUpgradeToTier (int tier, MarketAPI market) {
        //Checks for headquarters and/or too high tier to upgrade to
        if (tier > 4) {
            return false;
        } else if (tier == 4) {
            return (headquarters == market);
        }

        //Checks how many tier 2/3 markets we have
        int tier2Markets = 0;
        int tier3Markets = 0;
        for (loa_UpgradingMarketHandler otherMarket : existingMarkets) {
            if (otherMarket.getCurrentTier() == 2) {
                tier2Markets++;
            } else if (otherMarket.getCurrentTier() == 3) {
                tier3Markets++;
            }
        }

        //Compares number of tier 2/3 markets to maximum
        if (tier == 2) {
            return (tier2Markets < MAX_TIER_2_MARKETS);
        } else if (tier == 3) {
            return (tier3Markets < MAX_TIER_3_MARKETS);
        }

        //Fallback
        return true;
    }


    //No running while paused, there's simply no point
    @Override
    public boolean runWhilePaused() {
        return false;
    }

    //Delete ourselves if the faction we work for is entirely gone
    @Override
    public boolean isDone() {
        if (headquarters == null && Misc.getFactionMarkets(Global.getSector().getFaction(OUR_FACTION)).isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    //Checks if a system is currently under a "spawn lock" due to having a base or recently destroyed base in it
    private boolean systemIsLockedFromSpawning(StarSystemAPI system) {
        //A system without an entry in our map has never gotten a spawn, so is perfectly fine
        if (systemSpawnCooldowns.get(system) == null) {
            return false;
        }

        //Otherwise, we're blocked if its cooldown is more than zero
        return systemSpawnCooldowns.get(system) >= 0f;
    }

    //Reports that one of our markets have been removed for some reason
    public void reportMarketRemoved(MarketAPI market) {
        //Set a cooldown on our star system, so we don't respawn there too fast
        systemSpawnCooldowns.put(market.getStarSystem(), COOLDOWN_PER_SYSTEM_AFTER_BASE_LOSS);
    }



    //--- A listener class meant to fix the problems with Hidden markets not properly tracking imports and similar events
    private class EconomyFixer implements EconomyAPI.EconomyUpdateListener {
        MarketAPI market;

        public EconomyFixer(MarketAPI market) {
            this.market = market;
        }

        @Override
        public void economyUpdated() {
            float fleetSizeBonus = 1f;
            float qualityBonus = 0f;
            int lightPatrols = 0;
            int mediumPatrols = 0;
            int heavyPatrols = 0;

            //Calculates the industry bonus of our faction
            float industryBonus = 0f;
            int highestHeavyIndustryLevel = 0;
            int highestAutoforgeLevel = 0;
            for (MarketAPI factionMarket : Misc.getFactionMarkets(market.getFaction())) {
                if (factionMarket.hasIndustry(Industries.HEAVYINDUSTRY)) {
                    highestHeavyIndustryLevel = Math.max(highestHeavyIndustryLevel, 1);
                    SpecialItemData item = factionMarket.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem();
                    if (item != null) {
                        if (Items.CORRUPTED_NANOFORGE.equals(item.getId())) {
                            highestAutoforgeLevel = Math.max(highestAutoforgeLevel, 1);
                        }
                        if (Items.PRISTINE_NANOFORGE.equals(item.getId())) {
                            highestAutoforgeLevel = Math.max(highestAutoforgeLevel, 2);
                        }
                    }
                } else if (factionMarket.hasIndustry(Industries.ORBITALWORKS)) {
                    highestHeavyIndustryLevel = Math.max(highestHeavyIndustryLevel, 2);
                    SpecialItemData item = factionMarket.getIndustry(Industries.ORBITALWORKS).getSpecialItem();
                    if (item != null) {
                        if (Items.CORRUPTED_NANOFORGE.equals(item.getId())) {
                            highestAutoforgeLevel = Math.max(highestAutoforgeLevel, 1);
                        }
                        if (Items.PRISTINE_NANOFORGE.equals(item.getId())) {
                            highestAutoforgeLevel = Math.max(highestAutoforgeLevel, 2);
                        }
                    }
                }
                if (highestHeavyIndustryLevel >= 2 && highestAutoforgeLevel >= 2) {
                    break; //We've already found the maximum possible bonus! No need to keep looking
                }
            }

            //CONFIGURATION: determines the increases to the industry bonus for each level of autoforge and/or heavy industry/orbital works
            //  Level 0 means no autoforge/industry, lvl 1 means Broken Autoforge/Heavy Industry, lvl 2 means Pristine Autoforge/Orbital Works
            switch (highestHeavyIndustryLevel) {
                case 2:
                    industryBonus += 0.5f;
                    break;
                case 1:
                    industryBonus += 0.1f;
                    break;
                default:
                    industryBonus += -0.3f;
                    break;
            }
            switch (highestAutoforgeLevel) {
                case 2:
                    industryBonus += 0.5f;
                    break;
                case 1:
                    industryBonus += 0.3f;
                    break;
                default:
                    //Do nothing
                    break;
            }

            //CONFIGURATION: How much bonus quality, fleetsize and patrols the markets get at different sizes
            switch (market.getSize()) {
                case 6:
                    qualityBonus = 0.5f * industryBonus;
                    fleetSizeBonus = 0.75f * industryBonus;
                    lightPatrols = 2;
                    mediumPatrols = 2;
                    heavyPatrols = 2;
                    break;
                case 5:
                    qualityBonus = 0.4f * industryBonus;
                    fleetSizeBonus = 0.5f * industryBonus;
                    lightPatrols = 2;
                    mediumPatrols = 2;
                    break;
                case 4:
                    qualityBonus = 0.3f * industryBonus;
                    fleetSizeBonus = 0.4f * industryBonus;
                    lightPatrols = 2;
                    mediumPatrols = 1;
                    break;
                default:
                    qualityBonus = 0.2f * industryBonus;
                    fleetSizeBonus = 0.3f * industryBonus;
                    lightPatrols = 2;
                    break;
            }

            market.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).
                    modifyFlatAlways(market.getId(), qualityBonus,
                            "Development level");
            market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyFlatAlways(market.getId(),
                    fleetSizeBonus,
                    "Development level");

            String modId = market.getId();
            market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).modifyFlat(modId, lightPatrols);
            market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).modifyFlat(modId, mediumPatrols);
            market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).modifyFlat(modId, heavyPatrols);
        }

        @Override
        public boolean isEconomyListenerExpired() {
            if (headquarters == null && Misc.getFactionMarkets(Global.getSector().getFaction(OUR_FACTION)).isEmpty()) {
                return true;
            } else {
                return false;
            }
        }

        public void commodityUpdated(String commodityId) {
            CommodityOnMarketAPI com = market.getCommodityData(commodityId);
            int curr = 0;
            String modId = market.getId();
            MutableStat.StatMod mod = com.getAvailableStat().getFlatStatMod(modId);
            if (mod != null) {
                curr = Math.round(mod.value);
            }

            int a = com.getAvailable() - curr;
            int d = com.getMaxDemand();
            if (d > a) {
                int supply = Math.max(1, d - a);
                com.getAvailableStat().modifyFlat(modId, supply, "Supplied by internal trade routes");
            }
        }
    }
}
