//By Nicke535, automatically reduces relations with certain factions should they ever get above an allowed level
package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.MathUtils;
import data.scripts.al_ArkgneisisModPlugin;
import exerelin.campaign.AllianceManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_campaign_relations_plugin implements EveryFrameScript {

    //The ID for the faction that gets their relations adjusted (sorry, couldn't remember your faction ID off the top of my head)
    private static final String MAIN_FACTION = "al_ars";

    //Map for faction relation limits: relations will never be above the level shown here for that faction, no matter what
    private static final Map<String, Float> FACTION_RELATION_MAXIMUMS = new HashMap<>();
    static {
        FACTION_RELATION_MAXIMUMS.put(Factions.HEGEMONY, -0.60f);       //Not on the best of terms. Ever.
        FACTION_RELATION_MAXIMUMS.put("templars", -1.00f);              //Not down with the deus vult.
        FACTION_RELATION_MAXIMUMS.put(Factions.LUDDIC_PATH, -0.50f);    //Little balls of hate these ones.
        FACTION_RELATION_MAXIMUMS.put("new_galactic_order", -1.00f);    //Hahaha, no.
        FACTION_RELATION_MAXIMUMS.put("vic", -0.20f);                   //Domain-supporting private institution, not to be trusted.
        FACTION_RELATION_MAXIMUMS.put("ironshell", -0.20f);             //Wibbly Wobbly Hegemony Mememony.
    }

    //Blacklist for Anarkasis "raids": any faction on here will not be targeted by the spontaneous hostilities from this script
    private static final List<String> FACTION_RAID_BLACKLIST = new ArrayList<>();
    static {
        FACTION_RAID_BLACKLIST.add(Factions.HEGEMONY);       //Always hostile anyhow
        FACTION_RAID_BLACKLIST.add(Factions.INDEPENDENT);    //Not one faction per-se, I suppose
        FACTION_RAID_BLACKLIST.add(Factions.PLAYER);         //This seems like a good idea
        FACTION_RAID_BLACKLIST.add(Factions.LUDDIC_PATH);    //They hate us anyway
        FACTION_RAID_BLACKLIST.add("templars");              //Never not hostile.
        FACTION_RAID_BLACKLIST.add("vass");                  //Time wizards are not real, they can't hurt you.
    }

    //Blacklist for Anarkasis "raid hiring": any faction on here will not buy raids against their enemies
    private static final List<String> FACTION_RAID_HIRING_BLACKLIST = new ArrayList<>();
    static {
        FACTION_RAID_HIRING_BLACKLIST.add(Factions.HEGEMONY);       //Would have to go through so many front companies to work nobody would be able to trace it.
        FACTION_RAID_HIRING_BLACKLIST.add(Factions.INDEPENDENT);    //Not one faction per-se, I suppose
        FACTION_RAID_HIRING_BLACKLIST.add(Factions.PLAYER);         //This seems like a good idea
        FACTION_RAID_HIRING_BLACKLIST.add(Factions.LUDDIC_PATH);    //They don't seem like the help-hiring type
        FACTION_RAID_HIRING_BLACKLIST.add("templars");              //Cant gain rep anyway.
    }

    //Defines the minimum and maximum time for both raid duration and cooldown (defined in in-game days)
    private static final float RAID_COOLDOWN_MIN_DAYS = 60f;
    private static final float RAID_COOLDOWN_MAX_DAYS = 120f;
    private static final float RAID_DURATION_MIN_DAYS = 30f;
    private static final float RAID_DURATION_MAX_DAYS = 150f;

    //How long must we wait, *at minimum*, before starting a new raid against the same faction after our first has ended?
    private static final float RAID_WAIT_AFTER_RAIDED = 150f;

    //How much reputation do we get with a faction that hires us to do a raid on someone?
    //  0.1f would represent 10 rep gain, and -0.15f would be 15 rep loss
    private static final float RAID_REPUTATION_GAIN_FROM_HIRING = 0.2f;

    //In-script variable initialization, no changing these
    private Map<FactionAPI, CustomRaidDataPacket> raidDatas = new HashMap<>();
    private Map<FactionAPI, Float> raidWaitingMap = new HashMap<>();
    private float betweenRaidCooldown = MathUtils.getRandomNumberInRange(RAID_COOLDOWN_MIN_DAYS, RAID_COOLDOWN_MAX_DAYS);

    @Override
    public void advance( float amount ) {
        //Sanity check
        SectorAPI sector = Global.getSector();
        if (sector == null) {
            return;
        }

        //If the faction is somehow unloaded from memory, do an emergency stop of all code. Should ideally never happen
        if (sector.getFaction(MAIN_FACTION) == null) {
            return;
        }

        //If the faction is completely gone, but not unloaded from memory, we call off all raids immidiately, but run no other code
        boolean factionIsGone = true;
        for (MarketAPI mrkt: Misc.getFactionMarkets(sector.getFaction(MAIN_FACTION))) {
            if (mrkt.isInEconomy() && !mrkt.isHidden()) {
                factionIsGone = false;
                break;
            }
        }
        if (factionIsGone) {
            //Clone the raid datas, and then iterate over them to end them
            List<FactionAPI> raidsToCallOff = new ArrayList<>(raidDatas.keySet());
            for (FactionAPI key : raidsToCallOff) {
                endRaid(key, sector.getFaction(MAIN_FACTION));
                raidDatas.remove(key);
            }
            return;
        }

        //Runs the code for downward-adjusting relations semi-sneakily when too high
        FactionAPI anarkasis = sector.getFaction(MAIN_FACTION);
        for (String s : FACTION_RELATION_MAXIMUMS.keySet()) {
            FactionAPI faction = sector.getFaction(s);
            if (faction == null) { continue; }

            //Adjusts relations downward for any faction that is too high
            if (anarkasis.getRelationship(faction.getId()) > FACTION_RELATION_MAXIMUMS.get(s)) {
                anarkasis.setRelationship(faction.getId(), FACTION_RELATION_MAXIMUMS.get(s));
            }
        }

        //Handles eventual "raids" (periods of hostility to normally non-hostile factions)
        betweenRaidCooldown -= Misc.getDays(amount);
        if (betweenRaidCooldown <= 0f) {
            startNewRaid(sector, anarkasis);
            betweenRaidCooldown = MathUtils.getRandomNumberInRange(RAID_COOLDOWN_MIN_DAYS, RAID_COOLDOWN_MAX_DAYS);
        }

        //Ticks down our after-raid cooldowns, removing those that are finished
        List<FactionAPI> cleanList = new ArrayList<>();
        for (FactionAPI key : raidWaitingMap.keySet()) {
            raidWaitingMap.put(key, raidWaitingMap.get(key) + Misc.getDays(amount));
            if (raidWaitingMap.get(key) > RAID_WAIT_AFTER_RAIDED) {
                cleanList.add(key);
            }
        }
        for (FactionAPI key : cleanList) {
            raidWaitingMap.remove(key);
        }

        //Ticks down existing raids, and removes those that are done
        List<FactionAPI> raidsToCallOff = new ArrayList<>();
        for (FactionAPI key : raidDatas.keySet()) {
            raidDatas.get(key).raidDurationLeft -= Misc.getDays(amount);
            if (raidDatas.get(key).raidDurationLeft <= 0f) {
                raidsToCallOff.add(key);
            }
        }
        for (FactionAPI key : raidsToCallOff) {
            endRaid(key, anarkasis);
            raidDatas.remove(key);
        }
    }


    //This handles starting a new raid
    private void startNewRaid (@NotNull SectorAPI sector, FactionAPI anarkasisFaction) {
        //First get a list of all the factions we could get mad at
        WeightedRandomPicker<FactionAPI> raidableFactions = new WeightedRandomPicker<>();
        FactionAPI factionForRaid;
        for (FactionAPI f : sector.getAllFactions()) {
            //Ignore ourselves...
            if (f != anarkasisFaction) {
                //...and anything in the blacklist...
                if (!FACTION_RAID_BLACKLIST.contains(f.getId())) {
                    //...and anything hidden in the intel screen...
                    if (!f.isShowInIntelTab()) {
                        continue;
                    }
                    //...and anything being raided already...
                    if (raidDatas.containsKey(f)) {
                        continue;
                    }
                    //...and anything too recently raided...
                    if (raidWaitingMap.containsKey(f)) {
                        continue;
                    }
                    //...in case of nexerelin, we also ignore alliance members...
                    if (al_ArkgneisisModPlugin.isExerelin) {
                        if (AllianceManager.areFactionsAllied(anarkasisFaction.getId(), f.getId())) {
                            continue;
                        }
                    }
                    //...and anything already madder at us than Hostile (a raid doesn't make you BETTER friends)
                    if (anarkasisFaction.isAtWorst(f,RepLevel.HOSTILE)) {
                        //Add with weight based on our relations to the faction, so more friendly factions are less likely to be raided
                        //  Some funky hard-coded math here, but should do the trick
                        raidableFactions.add(f, (float)Math.pow(1f-anarkasisFaction.getRelationshipLevel(f).getMax(), 2f));
                    }
                }
            }
        }

        //If there were *no* valid factions, call off the raid, otherwise pick one at random (with weight from earlier)
        if (raidableFactions.isEmpty()) {
            return;
        } else {
            factionForRaid = raidableFactions.pick();
        }

        //Also pick one faction randomly which is an enemy of the faction we're about to raid; this is our benefactor
        FactionAPI factionThatHiredRaid;
        List<FactionAPI> validFactions = new ArrayList<>();
        for (FactionAPI f : sector.getAllFactions()) {
            //Ignore anything in the blacklist...
            if (FACTION_RAID_HIRING_BLACKLIST.contains(f.getId())) {
                continue;
            }
            //...and anything hidden from intel...
            if (!f.isShowInIntelTab()) {
                continue;
            }
            //...and anyone we're currently raiding
            if (raidDatas.containsKey(f)) {
                continue;
            }

            //Finally, check the faction's relations to our "raid" faction; if it's too high, don't count them as valid
            if (f.isAtBest(factionForRaid, RepLevel.INHOSPITABLE) || f == anarkasisFaction) {
                validFactions.add(f);
            }
        }

        //If we don't have any valid benefactors, we simply pick ourselves as benefactor; otherwise, we pick one at random
        if (validFactions.isEmpty()) {
            factionThatHiredRaid = anarkasisFaction;
        } else {
            factionThatHiredRaid = validFactions.get(MathUtils.getRandomNumberInRange(0, validFactions.size()-1));
        }

        //Then, we simply change some values and voila! Hostilities. Also save all the data we need for later
        float raidedRepLevelBefore = factionForRaid.getRelationship(MAIN_FACTION);
        anarkasisFaction.setRelationship(factionForRaid.getId(), RepLevel.HOSTILE);

        //Create our Intel to the intel screen
        loa_campaign_relations_intel intel = new loa_campaign_relations_intel(factionForRaid, factionThatHiredRaid);
        if (!intel.isDone()) {
            Global.getSector().getIntelManager().addIntel(intel, false);
            Global.getSector().addScript(intel);
        }

        //Sends a signal that the war has begun
        Global.getSector().getCampaignUI().addMessage(
                capitalizeFirstLetter(anarkasisFaction.getDisplayNameWithArticle()) + " have started attacking ships belonging to " + factionForRaid.getDisplayNameWithArticle() + ".",
                Misc.getTextColor(),
                anarkasisFaction.getDisplayName(),factionForRaid.getDisplayName(),
                anarkasisFaction.getBaseUIColor(),
                factionForRaid.getBaseUIColor());

        //And finally create a data package we can save in the script
        raidDatas.put(factionForRaid, new CustomRaidDataPacket(intel, raidedRepLevelBefore, MathUtils.getRandomNumberInRange(RAID_DURATION_MIN_DAYS, RAID_DURATION_MAX_DAYS)));
    }

    //This handles ending the current raid
    private void endRaid (FactionAPI targetFaction, FactionAPI anarkasisFaction) {
        //Gets the data package with the valid information
        CustomRaidDataPacket packet = raidDatas.get(targetFaction);

        //Failsafe, should never happen
        if (packet == null) {
            return;
        }

        //Check if SUSPICIOUS is actually lower than what we used to have... and use the lowest of the two
        if (packet.repLevelBefore < RepLevel.SUSPICIOUS.getMin()) {
            anarkasisFaction.setRelationship(targetFaction.getId(), packet.repLevelBefore);
        } else {
            anarkasisFaction.setRelationship(targetFaction.getId(), RepLevel.SUSPICIOUS);
        }

        //Give a bonus to whatever faction hired us (unless they are us, that is)
        if (packet.intel.getFactionThatHired() != anarkasisFaction) {
            packet.intel.getFactionThatHired().adjustRelationship(MAIN_FACTION, RAID_REPUTATION_GAIN_FROM_HIRING);
        }
        
        //Ensure that we don't attack the same faction two times in a row
        raidWaitingMap.put(targetFaction, 0f);

        //Ends our Intel
        if (packet.intel != null) {
            packet.intel.endThisIntel();
        }

        //Sends a signal that the war is over; slightly different message if we had a faction that hired us
        if (packet.intel == null || packet.intel.getFactionThatHired() == anarkasisFaction) {
            Global.getSector().getCampaignUI().addMessage(
                    capitalizeFirstLetter(anarkasisFaction.getDisplayNameWithArticle()) + " have ceased attacks against " + targetFaction.getDisplayNameWithArticle() + ".",
                    Misc.getTextColor(),
                    anarkasisFaction.getDisplayName(),targetFaction.getDisplayName(),
                    anarkasisFaction.getBaseUIColor(),
                    targetFaction.getBaseUIColor());
        } else {
            Global.getSector().getCampaignUI().addMessage(
                    capitalizeFirstLetter(anarkasisFaction.getDisplayNameWithArticle()) + " have ceased attacks against " + targetFaction.getDisplayNameWithArticle() + ".",
                    Misc.getTextColor(),
                    anarkasisFaction.getDisplayName(),targetFaction.getDisplayName(),
                    anarkasisFaction.getBaseUIColor(),
                    targetFaction.getBaseUIColor());
            Global.getSector().getCampaignUI().addMessage(
                    "Intel suggests these attacks were sponsored at least in part by " + packet.intel.getFactionThatHired().getDisplayNameWithArticle() + ".",
                    Misc.getTextColor(),
                    packet.intel.getFactionThatHired().getDisplayName(),packet.intel.getFactionThatHired().getDisplayName(),
                    packet.intel.getFactionThatHired().getBaseUIColor(),
                    packet.intel.getFactionThatHired().getBaseUIColor());
        }

        //And cleans up our variables
        raidDatas.remove(targetFaction);
    }


    //We are NEVER DONE!
    @Override
    public boolean isDone() {
        return false;
    }

    //No need to run while paused
    @Override
    public boolean runWhilePaused() {
        return false;
    }

    //Class for storing raid information compactly
    private class CustomRaidDataPacket {
        private loa_campaign_relations_intel intel;
        private float repLevelBefore;
        private float raidDurationLeft;

        CustomRaidDataPacket (loa_campaign_relations_intel intel, float repLevelBefore, float raidDurationLeft) {
            this.intel = intel;
            this.repLevelBefore = repLevelBefore;
            this.raidDurationLeft = raidDurationLeft;
        }
    }

    //Shorthand function to convert a string to have uppercase at the start
    private String capitalizeFirstLetter(@NotNull final String line) {
        if (line.length() < 2) {
            return "" + Character.toUpperCase(line.charAt(0));
        }
        return Character.toUpperCase(line.charAt(0)) + line.substring(1);
    }
}
