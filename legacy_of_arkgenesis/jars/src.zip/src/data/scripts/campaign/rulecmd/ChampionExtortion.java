// if the player has the Champion, take it. Irregardless, take supplies and fuel too
package data.scripts.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.loading.AbilitySpecAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.MutableValue;
import com.fs.starfarer.api.util.Misc.Token;


import java.util.List;
import java.util.Map;

public class ChampionExtortion extends BaseCommandPlugin {

    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap)
    {
        final MemoryAPI localMemory = memoryMap.get(MemKeys.LOCAL);
        if (localMemory == null) return false;
        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        CampaignFleetAPI other = (CampaignFleetAPI) dialog.getInteractionTarget();

        for (FleetMemberAPI member : playerFleet.getMembersWithFightersCopy()) {
            //Ignore fighters
            if (member.getHullSpec().getHullSize() == ShipAPI.HullSize.FIGHTER) {
                continue;
            }

            //Then, check the ID
            if (member.getHullId().contains("loaht_champion1")) {
                addFleetMemberLossText(member.getVariant(), dialog.getTextPanel());
                other.getFleetData().addFleetMember(member);
                playerFleet.getFleetData().removeFleetMember(member);
                playerFleet.forceSync();
                playerFleet.updateCounts();
                other.forceSync();
                other.updateCounts();
            }
        }

        float supplies = playerFleet.getCargo().getCommodityQuantity(Commodities.SUPPLIES);
        float fuel = playerFleet.getCargo().getCommodityQuantity(Commodities.FUEL);

        AddRemoveCommodity.addCommodityLossText(Commodities.SUPPLIES, (int) Math.abs(supplies * 0.5f), dialog.getTextPanel());
        AddRemoveCommodity.addCommodityLossText(Commodities.FUEL, (int) Math.abs(fuel * 0.5f), dialog.getTextPanel());

        playerFleet.getCargo().removeCommodity(Commodities.SUPPLIES, supplies * 0.5f);
        playerFleet.getCargo().removeCommodity(Commodities.FUEL, fuel * 0.5f);

        other.getAI().addAssignment(FleetAssignment.GO_TO_LOCATION_AND_DESPAWN, Misc.getDistressJumpPoint(other.getStarSystem()), 1000000f, null);
        other.removeTag("ChampionFleet");

        return true;
    }

    public static void addFleetMemberLossText(ShipVariantAPI variant, TextPanelAPI text) {
        text.setFontSmallInsignia();
        String str = variant.getHullSpec().getHullNameWithDashClass() + " " + variant.getHullSpec().getDesignation();
        text.addParagraph("Lost " + str + "", Misc.getNegativeHighlightColor());
        text.highlightInLastPara(Misc.getHighlightColor(), str);
        text.setFontInsignia();
    }

}
