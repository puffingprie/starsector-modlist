package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.fleet.ShipRolePick;
import com.fs.starfarer.api.impl.campaign.DModManager;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.ShipRoles;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.submarkets.OpenMarketPlugin;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.lazywizard.lazylib.MathUtils;

import java.io.IOException;
import java.util.*;

/**
 * Raid econonmy! This one is a minor beast, so it's a tad bit complex
 *
 * Note that Raid Economy reads from the files "data/config/loa/raid_economy_factions_whitelist.csv", "data/config/loa/raid_economy_weapons_blacklist.csv"
 * and "data/config/loa/raid_economy_ships_blacklist.csv" primarily, falling back to Prism market equivalents if no file is found
 *
 * @author Nicke535
 */
public class loa_raid_economy extends BaseMarketConditionPlugin {
    //A debug logger to more easily track what the script is doing
    private static Logger log = Global.getLogger(loa_raid_economy.class);

    //Sets the maximum tier of equipment sold on the open market: for comparison, the Sabot or Tac-Laser is tier 1 and Tachyon Lance is tier 3
    private static final int MAXIMUM_OPEN_MARKET_TIER = 4;

    //How many weapons are added to the market for each faction we're at war with, per market size, per submarket (the submarkets get spawned at separately)
    //  So at 1f, we get 1 weapon pick (approximately 4 small weapons) for a size 1 market, if we are at war with 1 faction)
    //  Fractions represent probability (0.5f means at size 1 there's a 50% chance of getting a weapon pick, at size 2 a guaranteed pick, at size 3 50% chance for 1 pick and 50% chance for 2 picks etc.)
    private static final float WEAPONS_PER_FACTION_AND_SIZE = 1f;

    //Like the setting above, but with two differences : each pick is a single LPC, and affects fighter wings instead
    private static final float WINGS_PER_FACTION_AND_SIZE = 0.5f;

    //Like the settings above, but instead for ships
    private static final float SHIPS_PER_FACTION_AND_SIZE = 0.5f;

    //The maximum and minimum D-Mods ships are sold with for the military and civialian market respectively
    private static final int CIVILIAN_MARKET_MIN_DMODS = 1;
    private static final int CIVILIAN_MARKET_MAX_DMODS = 3;
    private static final int MILITARY_MARKET_MIN_DMODS = 0;
    private static final int MILITARY_MARKET_MAX_DMODS = 2;

    // -- Internal script variables
    // White-and blacklists. Loaded once when the game starts, but then should remain untouched
    // Note that we manually include the appropriate vanilla factions here as well
    private static Set<String> restrictedWeapons = new HashSet<>();
    private static Set<String> restrictedShips = new HashSet<>();
    private static Set<String> allowedFactions = new HashSet<>(Arrays.asList(Factions.HEGEMONY, Factions.TRITACHYON, Factions.PERSEAN,
            Factions.DIKTAT, Factions.INDEPENDENT, Factions.LUDDIC_CHURCH, Factions.LUDDIC_PATH, Factions.LIONS_GUARD));

    private MarketAPI market;
    private loa_raid_economy_market_opening_listener listener;

    @Override
    public void init(MarketAPI market, MarketConditionAPI condition) {
        super.init(market, condition);
        this.market = market;
        if (listener == null) {
            listener = new loa_raid_economy_market_opening_listener(market, this);
        } else {
            listener.ourMarket = market;
            listener.ourCondition = this;
        }
    }

    // Stolen partially from Prism Market
    private void addRandomWeapons(int wepsPerFactionAndMarket) {
        SubmarketAPI milMarket = market.getSubmarket(Submarkets.GENERIC_MILITARY);
        SubmarketAPI openMarket = market.getSubmarket(Submarkets.SUBMARKET_OPEN);
        CargoAPI milCargo = milMarket == null ? null : milMarket.getCargo();
        CargoAPI openCargo = openMarket == null ? null : openMarket.getCargo();

        List<FactionAPI> factionsAtWar = getFactionsAtWar();
        List<FactionAPI> allowedPickFactions = getAllowedFactionsAtWar();
        for (FactionAPI faction : factionsAtWar) {
            WeightedRandomPicker<String> picker = getWeaponWeights(faction, allowedPickFactions);
            if (milCargo != null) {
                for (int i = 0; i < wepsPerFactionAndMarket; i++) {
                    if (picker.isEmpty()) break;
                    String weaponId = picker.pickAndRemove();
                    int quantity = 2;
                    WeaponSpecAPI spec = Global.getSettings().getWeaponSpec(weaponId);
                    if (spec.getSize() == WeaponAPI.WeaponSize.SMALL) {
                        quantity = 8;
                    }
                    else if (spec.getSize() == WeaponAPI.WeaponSize.MEDIUM) {
                        quantity = 4;
                    }
                    milCargo.addWeapons(weaponId, quantity);
                }
            }
            if (openCargo != null) {
                for (int i = 0; i < wepsPerFactionAndMarket; i++) {
                    if (picker.isEmpty()) break;
                    String weaponId = picker.pickAndRemove();
                    int quantity = 1;
                    WeaponSpecAPI spec = Global.getSettings().getWeaponSpec(weaponId);
                    if (spec.getTier() > MAXIMUM_OPEN_MARKET_TIER) {
                        continue;
                    }
                    if (spec.getSize() == WeaponAPI.WeaponSize.SMALL) {
                        quantity = 4;
                    } else if (spec.getSize() == WeaponAPI.WeaponSize.MEDIUM) {
                        quantity = 2;
                    }
                    openCargo.addWeapons(weaponId, quantity);
                }
            }
        }
    }

    public void addWeapons() {
        int numberToAdd = (int)Math.floor(WEAPONS_PER_FACTION_AND_SIZE*market.getSize());
        if (Math.random() < WEAPONS_PER_FACTION_AND_SIZE*market.getSize() - numberToAdd) {
            numberToAdd++;
        }
        addRandomWeapons(numberToAdd);
    }

    public void addWings() {
        SubmarketAPI milMarket = market.getSubmarket(Submarkets.GENERIC_MILITARY);
        SubmarketAPI openMarket = market.getSubmarket(Submarkets.SUBMARKET_OPEN);
        CargoAPI milCargo = milMarket == null ? null : milMarket.getCargo();
        CargoAPI openCargo = openMarket == null ? null : openMarket.getCargo();

        List<FactionAPI> factionsAtWar = getFactionsAtWar();
        List<FactionAPI> allowedPickFactions = getAllowedFactionsAtWar();
        for (FactionAPI faction : factionsAtWar) {
            int numberToAdd = (int)Math.floor(WINGS_PER_FACTION_AND_SIZE*market.getSize());
            if (Math.random() < WINGS_PER_FACTION_AND_SIZE*market.getSize() - numberToAdd) {
                numberToAdd++;
            }
            WeightedRandomPicker<String> picker = getWingWeights(faction, allowedPickFactions);
            if (milCargo != null) {
                int picks = 0;
                while (!picker.isEmpty() && picks < numberToAdd) {
                    String id = picker.pickAndRemove();
                    milCargo.addItems(CargoAPI.CargoItemType.FIGHTER_CHIP, id, 1);
                    picks++;
                }
            }
            if (openCargo != null) {
                int picks = 0;
                while (!picker.isEmpty() && picks < numberToAdd) {
                    String id = picker.pickAndRemove();
                    FighterWingSpecAPI spec = Global.getSettings().getFighterWingSpec(id);
                    if (spec.getTier() > MAXIMUM_OPEN_MARKET_TIER) {
                        continue;
                    }
                    openCargo.addItems(CargoAPI.CargoItemType.FIGHTER_CHIP, id, 1);
                    picks++;
                }
            }
        }
    }

    public void addCivShips() {
        SubmarketAPI subMarket = market.getSubmarket(Submarkets.SUBMARKET_OPEN);
        if (subMarket == null) { return; }
        CargoAPI cargo = subMarket.getCargo();

        WeightedRandomPicker<String> rolePicker = new WeightedRandomPicker<>();
        rolePicker.add(ShipRoles.CIV_RANDOM, 10f);
        rolePicker.add(ShipRoles.FREIGHTER_SMALL, 15f);
        rolePicker.add(ShipRoles.FREIGHTER_MEDIUM, 10f);
        rolePicker.add(ShipRoles.FREIGHTER_LARGE, 5f);
        rolePicker.add(ShipRoles.TANKER_SMALL, 15f);
        rolePicker.add(ShipRoles.TANKER_MEDIUM, 10f);
        rolePicker.add(ShipRoles.TANKER_LARGE, 5f);
        rolePicker.add(ShipRoles.COMBAT_FREIGHTER_SMALL, 5f);
        rolePicker.add(ShipRoles.COMBAT_FREIGHTER_MEDIUM, 5f);
        rolePicker.add(ShipRoles.COMBAT_FREIGHTER_LARGE, 1f);
        rolePicker.add(ShipRoles.COMBAT_SMALL, 5f);
        rolePicker.add(ShipRoles.COMBAT_MEDIUM, 1f);

        List<FactionAPI> warFactions = getFactionsAtWar();
        List<FactionAPI> allowedSpawnFactions = getAllowedFactionsAtWar();
        WeightedRandomPicker<FactionAPI> randomFactionPicker = new WeightedRandomPicker<>();
        randomFactionPicker.addAll(allowedSpawnFactions);

        //Renew ship stock once per faction
        for (FactionAPI faction : warFactions) {
            if (!allowedSpawnFactions.contains(faction)) {
                faction = randomFactionPicker.pick();
            }
            int numberToAdd = (int)Math.floor(SHIPS_PER_FACTION_AND_SIZE*market.getSize());
            if (Math.random() < SHIPS_PER_FACTION_AND_SIZE*market.getSize() - numberToAdd) {
                numberToAdd++;
            }
            int tries = 0;
            for (int i = 0; i < numberToAdd; i++) {
                //pick the role and faction
                List<ShipRolePick> picks = null;
                int tries2 = 0;
                do {
                    tries2++;
                    String role = rolePicker.pick();
                    // Pick a random ship
                    try {
                        picks = faction.pickShip(role, FactionAPI.ShipPickParams.priority());
                    } catch (NullPointerException npex) {
                        // Most likely picker picked a role when the faction has no ships for that role; do nothing
                    }
                } while (picks == null && tries2 < 50);
                if (tries2 >= 50) {
                    continue; //This faction seems to simply not work to spawn from at the moment: just ignore it for now
                }

                for (ShipRolePick pick : picks) {
                    FleetMemberType type = FleetMemberType.SHIP;
                    String variantId = pick.variantId;

                    //set the ID
                    FleetMemberAPI member = Global.getFactory().createFleetMember(type, variantId);
                    variantId = member.getHullId() + "_Hull";
                    member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variantId);

                    // Adds D-mods randomly
                    int dModCount = MathUtils.getRandomNumberInRange(CIVILIAN_MARKET_MIN_DMODS, CIVILIAN_MARKET_MAX_DMODS);
                    if (dModCount > 0) {
                        DModManager.setDHull(member.getVariant());
                        DModManager.addDMods(member, true, dModCount, null);
                    }

                    // If the ship is allowed to be sold, we add it. Otherwise, start over and try again...
                    //      Hey, it's brute force, but it's certified Prism-grade Brute Force[TM]
                    if (!restrictedShips.contains(member.getHullId())) {
                        member.getRepairTracker().setMothballed(true);
                        member.getRepairTracker().setCR(0.5f);
                        cargo.getMothballedShips().addFleetMember(member);
                        log.info("Added "+member.getHullId()+" to "+market.getName()+": pick number "+(i+1)+" for "+faction.getDisplayName());
                    } else {
                        i -= 1;
                    }
                }
                tries++;
                if (tries > 40) break;
            }
        }
    }

    public void addMilShips() {
        SubmarketAPI subMarket = market.getSubmarket(Submarkets.GENERIC_MILITARY);
        if (subMarket == null) { return; }
        CargoAPI cargo = subMarket.getCargo();

        WeightedRandomPicker<String> rolePicker = new WeightedRandomPicker<>();
        rolePicker.add(ShipRoles.COMBAT_FREIGHTER_SMALL, 1f);
        rolePicker.add(ShipRoles.COMBAT_FREIGHTER_MEDIUM, 1f);
        rolePicker.add(ShipRoles.COMBAT_FREIGHTER_LARGE, 5f);
        rolePicker.add(ShipRoles.COMBAT_SMALL, 30f);
        rolePicker.add(ShipRoles.COMBAT_MEDIUM, 25f);
        rolePicker.add(ShipRoles.COMBAT_LARGE, 20f);
        rolePicker.add(ShipRoles.COMBAT_CAPITAL, 10f);
        rolePicker.add(ShipRoles.CARRIER_SMALL, 10f);
        rolePicker.add(ShipRoles.CARRIER_MEDIUM, 5f);
        rolePicker.add(ShipRoles.CARRIER_LARGE, 5f);

        List<FactionAPI> warFactions = getFactionsAtWar();
        List<FactionAPI> allowedSpawnFactions = getAllowedFactionsAtWar();
        WeightedRandomPicker<FactionAPI> randomFactionPicker = new WeightedRandomPicker<>();
        randomFactionPicker.addAll(allowedSpawnFactions);

        //Renew ship stock once per faction
        for (FactionAPI faction : warFactions) {
            if (!allowedSpawnFactions.contains(faction)) {
                faction = randomFactionPicker.pick();
            }
            int numberToAdd = (int)Math.floor(SHIPS_PER_FACTION_AND_SIZE*market.getSize());
            if (Math.random() < SHIPS_PER_FACTION_AND_SIZE*market.getSize() - numberToAdd) {
                numberToAdd++;
            }
            int tries = 0;
            for (int i = 0; i < numberToAdd; i++) {
                //pick the role and faction
                List<ShipRolePick> picks = null;
                int tries2 = 0;
                do {
                    tries2++;
                    String role = rolePicker.pick();
                    // Pick a random ship
                    try {
                        picks = faction.pickShip(role, FactionAPI.ShipPickParams.priority());
                    } catch (NullPointerException npex) {
                        // Most likely picker picked a role when the faction has no ships for that role; do nothing
                    }
                } while (picks == null && tries2 < 50);
                if (tries2 >= 50) {
                    continue; //This faction seems to simply not work to spawn from at the moment: just ignore it for now
                }

                for (ShipRolePick pick : picks) {
                    FleetMemberType type = FleetMemberType.SHIP;
                    String variantId = pick.variantId;

                    //set the ID
                    FleetMemberAPI member = Global.getFactory().createFleetMember(type, variantId);
                    variantId = member.getHullId() + "_Hull";
                    member = Global.getFactory().createFleetMember(type, variantId);

                    // Adds D-mods randomly
                    int dModCount = MathUtils.getRandomNumberInRange(MILITARY_MARKET_MIN_DMODS, MILITARY_MARKET_MAX_DMODS);
                    if (dModCount > 0) {
                        DModManager.setDHull(member.getVariant());
                        DModManager.addDMods(member, true, dModCount, null);
                    }

                    // If the ship is allowed to be sold, we add it. Otherwise, start over and try again...
                    //      Hey, it's brute force, but it's certified Prism-grade Brute Force[TM]
                    if (!restrictedShips.contains(member.getHullId())) {
                        member.getRepairTracker().setMothballed(true);
                        member.getRepairTracker().setCR(0.5f);
                        cargo.getMothballedShips().addFleetMember(member);
                        log.info("Added "+member.getHullId()+" to "+market.getName()+": pick number "+(i+1)+" for "+faction.getDisplayName());
                    } else {
                        i -= 1;
                    }
                }
                tries++;
                if (tries > 40) break;
            }
        }
    }

    //Copied and heavily edited from Nexerelin's implementation, which is apparently copied from Vanilla originally...
    private WeightedRandomPicker<String> getWeaponWeights(FactionAPI faction, List<FactionAPI> allowedPickFactions) {
        WeightedRandomPicker<String> picker = new WeightedRandomPicker<>();

        //If our faction isn't one of the configured factions, we pick gear from every other faction
        if (allowedPickFactions.contains(faction)) {
            for (String weapon : faction.getKnownWeapons()) {
                if (restrictedWeapons.contains(weapon)) {
                    continue;
                }

                WeaponSpecAPI spec = Global.getSettings().getWeaponSpec(weapon);
                if (spec.getTier() >= 5 || spec.getAIHints().contains(WeaponAPI.AIHints.SYSTEM)) {
                    continue;
                }

                float weight = 10 - spec.getTier();    // higher tier = more rare

                weight *= spec.getRarity();

                // Chance to be picked twice, so add twice to weights
                picker.add(weapon, weight);
                picker.add(weapon, weight);
            }
        } else {
            for (FactionAPI otherFaction : allowedPickFactions) {
                for (String weapon : otherFaction.getKnownWeapons()) {
                    if (restrictedWeapons.contains(weapon)) {
                        continue;
                    }

                    WeaponSpecAPI spec = Global.getSettings().getWeaponSpec(weapon);
                    if (spec.getTier() >= 5 || spec.getAIHints().contains(WeaponAPI.AIHints.SYSTEM)) {
                        continue;
                    }

                    float weight = 10 - spec.getTier();    // higher tier = more rare

                    weight *= spec.getRarity();

                    // Chance to be picked twice, so add twice to weights
                    picker.add(weapon, weight);
                    picker.add(weapon, weight);
                }
            }
        }

        return picker;
    }

    //Copied and heavily edited from Nexerelin's implementation, which is apparently copied from Vanilla originally...
    private WeightedRandomPicker<String> getWingWeights(FactionAPI faction, List<FactionAPI> allowedPickFactions) {
        WeightedRandomPicker<String> picker = new WeightedRandomPicker<>();

        //If our faction isn't one of the configured factions, we pick gear from every other faction
        if (allowedPickFactions.contains(faction)) {
            for (String fighter : faction.getKnownFighters()) {
                if (restrictedShips.contains(fighter)) {
                    continue;
                }

                FighterWingSpecAPI spec = Global.getSettings().getFighterWingSpec(fighter);
                if (spec.getTier() >= 5 || spec.hasTag(Tags.WING_NO_SELL)) {
                    continue;
                }

                float weight = 10 - (spec.getTier());    // higher tier = more rare

                weight *= spec.getRarity();

                // Chance to be picked twice, so add twice to weights
                picker.add(fighter, weight);
                picker.add(fighter, weight);
            }
        } else {
            for (FactionAPI otherFaction : allowedPickFactions) {
                for (String fighter : otherFaction.getKnownFighters()) {
                    if (restrictedShips.contains(fighter)) {
                        continue;
                    }

                    FighterWingSpecAPI spec = Global.getSettings().getFighterWingSpec(fighter);
                    if (spec.getTier() >= 5 || spec.hasTag(Tags.WING_NO_SELL)) {
                        continue;
                    }

                    float weight = 10 - (spec.getTier());    // higher tier = more rare

                    weight *= spec.getRarity();

                    // Chance to be picked twice, so add twice to weights
                    picker.add(fighter, weight);
                    picker.add(fighter, weight);
                }
            }
        }

        return picker;
    }

    /**
     * Doesn't check for factions being blacklisted
     */
    private List<FactionAPI> getFactionsAtWar() {
        List<FactionAPI> factionsAtWar = new ArrayList<>();
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            if (!faction.isShowInIntelTab()) {
                continue;
            }
            if (faction.isAtBest(market.getFactionId(), RepLevel.HOSTILE)) {
                factionsAtWar.add(faction);
            }
        }
        return factionsAtWar;
    }

    /**
     * Does not return any factions that are not whitelisted in our configuration
     */
    private List<FactionAPI> getAllowedFactionsAtWar() {
        List<FactionAPI> factionsAtWar = new ArrayList<>();
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            if (!faction.isShowInIntelTab()) {
                continue;
            }
            if (faction.isAtBest(market.getFactionId(), RepLevel.HOSTILE) && allowedFactions.contains(faction.getId())) {
                factionsAtWar.add(faction);
            }
        }
        return factionsAtWar;
    }

    //Stolen nearly entirely from the Nexerelin implementation : fixes black- and whitelists for allowed items in markets
    public static void setupBlackAndWhitelist() throws JSONException {
        //We want to know every mod that is currently running, so we can read their data individually
        Set<String> loadedMods = new HashSet<>();
        for (ModSpecAPI spec : Global.getSettings().getModManager().getEnabledModsCopy()) {
            loadedMods.add(spec.getId());
        }

        log.info("Loading whitelisted factions from config");
        for (String modID : loadedMods) {
            try {
                //Ignore nexerelin since that one would just add a whole bunch of factions and shouldn't sit on a raid economy list itself
                if (modID.equals("nexerelin")) {
                    continue;
                }

                JSONArray data;
                //My heart sinks upon looking at these try-catches... but we should only run this once, so shouldn't be a problem
                try {
                    data = Global.getSettings().loadCSV("data/config/loa/raid_economy_factions_whitelist.csv", modID);
                } catch (RuntimeException e1) {
                    log.info("ModID " + modID + " did not have a Raid Economy whitelist, reverting to Prism whitelist");
                    try {
                        data = Global.getSettings().loadCSV("data/config/prism/prism_factions_whitelist.csv", modID);
                    } catch (RuntimeException e2) {
                        data = null;
                    }
                }
                if (data != null) {
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject row = data.getJSONObject(i);
                        allowedFactions.add(row.getString("id"));
                        log.info("Added to faction whitelist: " + row.getString("id"));
                    }
                }
            } catch (JSONException | IOException e) {
                throw new JSONException("Legacy of Arkgneisis encountered a critical runtime error when trying to load data from mod with ID " + modID);
            }
        }

        log.info("Loading blacklisted weapons from config");
        for (String modID : loadedMods) {
            try {
                //Ignore nexerelin since that one would just add a whole bunch of stuff and shouldn't sit on a raid economy list itself
                if (modID.equals("nexerelin")) {
                    continue;
                }

                JSONArray data;
                //My heart sinks upon looking at these try-catches... but we should only run this once, so shouldn't be a problem
                try {
                    data = Global.getSettings().loadCSV("data/config/loa/raid_economy_weapons_blacklist.csv", modID);
                } catch (RuntimeException e1) {
                    log.info("ModID " + modID + " did not have a Raid Economy weapon blacklist, reverting to Prism weapon blacklist");
                    try {
                        data = Global.getSettings().loadCSV("data/config/prism/prism_weapons_blacklist.csv", modID);
                    } catch (RuntimeException e2) {
                        data = null;
                    }
                }
                if (data != null) {
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject row = data.getJSONObject(i);
                        restrictedWeapons.add(row.getString("id"));
                        log.info("Added to weapon blacklist: " + row.getString("id"));
                    }
                }
            } catch (JSONException | IOException e) {
                throw new JSONException("Legacy of Arkgneisis encountered a critical runtime error when trying to load data from mod with ID " + modID);
            }
        }

        log.info("Loading blacklisted ships from config");
        for (String modID : loadedMods) {
            try {
                //Ignore nexerelin since that one would just add a whole bunch of stuff and shouldn't sit on a raid economy list itself
                if (modID.equals("nexerelin")) {
                    continue;
                }

                JSONArray data;
                //My heart sinks upon looking at these try-catches... but we should only run this once, so shouldn't be a problem
                try {
                    data = Global.getSettings().loadCSV("data/config/loa/raid_economy_ships_blacklist.csv", modID);
                } catch (RuntimeException e1) {
                    log.info("ModID " + modID + " did not have a Raid Economy ship blacklist, reverting to Prism ship blacklist");
                    try {
                        data = Global.getSettings().loadCSV("data/config/prism/prism_ships_blacklist.csv", modID);
                    } catch (RuntimeException e2) {
                        data = null;
                    }
                }
                if (data != null) {
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject row = data.getJSONObject(i);
                        restrictedShips.add(row.getString("id"));
                        log.info("Added to weapon blacklist: " + row.getString("id"));
                    }
                }
            } catch (JSONException | IOException e) {
                throw new JSONException("Legacy of Arkgneisis encountered a critical runtime error when trying to load data from mod with ID " + modID);
            }
        }
    }
}
