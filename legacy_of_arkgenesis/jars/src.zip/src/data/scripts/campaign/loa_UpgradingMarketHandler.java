package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_UpgradingMarketHandler implements FleetEventListener, EveryFrameScript {
    //A debug logger to more easily track what the script is doing
    public static Logger log = Global.getLogger(loa_UpgradingMarketHandler.class);

    /*---------- CONFIGURATION START ----------*/

    //The different suffixes corresponding to different tier
    private static final Map<Integer, String> NAME_SUFFIX_MAP = new HashMap<>();
    static {
        NAME_SUFFIX_MAP.put(1, "Outpost");
        NAME_SUFFIX_MAP.put(2, "Base");
        NAME_SUFFIX_MAP.put(3, "Harbor");
        NAME_SUFFIX_MAP.put(4, "Headquarters");
    }

    //How long it takes to get the next "upgrade", depending on which tier the market currently is. Specified in days
    private static final Map<Integer, Float> UPGRADE_COOLDOWNS = new HashMap<>();
    static {
        UPGRADE_COOLDOWNS.put(1, 10f);
        UPGRADE_COOLDOWNS.put(2, 20f);
        UPGRADE_COOLDOWNS.put(3, 30f);
        UPGRADE_COOLDOWNS.put(4, 10f);
    }

    //Specifies the different "upgrades" that can be gotten each time the market upgrades
    private static final List<UpgradeData> UPGRADE_DATAS = new ArrayList<>();
    static {
        //UPGRADE_DATAS.add(new UpgradeData(ID, isCondition, tiers, weight, upgradesFrom));
        UPGRADE_DATAS.add(new UpgradeData("loa_void_extraction", false, 1, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("loa_raid_economy", true, 1, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("patrolhq", false, 1, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("grounddefenses", false, 1, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("outpost", true, 1, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("frontier", true, 1, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("free_market", true, 1, 1f, null));
        
        UPGRADE_DATAS.add(new UpgradeData("waystation", false, 2, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("militarybase", false, 2, 1f, "patrolhq"));
        UPGRADE_DATAS.add(new UpgradeData("refining", false, 2, 1f, "loa_void_extraction"));
        UPGRADE_DATAS.add(new UpgradeData("loa_asteroid_battlestation", false, 2, 1f, "loa_asteroid_orbitalstation"));
        
        UPGRADE_DATAS.add(new UpgradeData("heavyindustry", false, 3, 1f, null));
        UPGRADE_DATAS.add(new UpgradeData("heavybatteries", false, 3, 1f, "grounddefenses"));
        UPGRADE_DATAS.add(new UpgradeData("loa_asteroid_starfortress", false, 3, 1f, "loa_asteroid_battlestation"));
        
        UPGRADE_DATAS.add(new UpgradeData("highcommand", false, 4, 1f, "militarybase"));
        UPGRADE_DATAS.add(new UpgradeData("fuelprod", false, 4, 1f, "refining"));
        UPGRADE_DATAS.add(new UpgradeData("orbitalworks", false, 4, 1f, "heavyindustry"));
        UPGRADE_DATAS.add(new UpgradeData("megaport", false, 4, 1f, "spaceport"));
    }

    //How many upgrades can we get per tier?
    private static final Map<Integer, Integer> UPGRADES_PER_TIER = new HashMap<>();
    static {
        UPGRADES_PER_TIER.put(1, 7);
        UPGRADES_PER_TIER.put(2, 4);
        UPGRADES_PER_TIER.put(3, 3);
        UPGRADES_PER_TIER.put(4, 4);
    }

    /*---------- CONFIGURATION END ----------*/


    //The main entity to track; this corresponds to the station
    private SectorEntityToken stationEntity;

    //The current fleet entity that represents the station
    private CampaignFleetAPI addedListenerTo = null;

    //The market to track
    private MarketAPI market;
    public MarketAPI getMarket() {
        return market;
    }

    //The plugin instance that spawned us
    private loa_spawnRandomMarketsPlugin plugin;

    //The "permanent" part of our name, which isn't adapted to match our size
    private String name;

    //Whether we are finished running the script
    private boolean isDone = false;

    //Internal timer for tracking how many days has passed since our last upgrade
    private float upgradeTimer = 0f;

    //Counts our current number of upgrades in tier, and which tier we currently inhibit
    private int currentTier = 1;
    private int upgradesThisTier = 0;

    //Counts ALL the upgrades we've ever gotten; we can't get the same one twice, even if our old one
    //was upgraded to something new down the line
    private List<String> alreadyGottenUpgrades = new ArrayList<>();


    //Instantiator
    public loa_UpgradingMarketHandler (SectorEntityToken stationEntity, MarketAPI market, loa_spawnRandomMarketsPlugin plugin, String name) {
        this.stationEntity = stationEntity;
        this.market = market;
        this.plugin = plugin;
        this.name = name;
        stationEntity.setCustomDescriptionId("loa_random_market_tier"+currentTier);
        Global.getSector().addScript(this);
    }


    //Main Advance function
    @Override
    public void advance(float amount) {
        //Failsafe, in case we somehow run when paused
        if (Global.getSector().isPaused()) {
            amount = 0f;
        }

        //Make sure the correct fleet has our listener
        if (Misc.getStationFleet(market) != null) {
            CampaignFleetAPI stationFleet = Misc.getStationFleet(market);
            if (stationFleet != addedListenerTo) {
                if (addedListenerTo != null) {
                    addedListenerTo.removeEventListener(this);
                }
                addedListenerTo = stationFleet;
                addedListenerTo.addEventListener(this);
                log.info("The market "+name+" changed its currently-tracked Station Fleet");
            }
        }

        //Updates our name
        updateName();

        //Checks if our "upgrade timer" has passed; if so, we get an upgrade!
        upgradeTimer += Misc.getDays(amount);
        if (upgradeTimer > UPGRADE_COOLDOWNS.get(currentTier)) {
            //If we have the maximum amount of upgrades this tier, we instead upgrade the tier of the station (if slots are available)
            if (upgradesThisTier >= UPGRADES_PER_TIER.get(currentTier)) {
                if (plugin.roomToUpgradeToTier(currentTier + 1, market)) {
                    currentTier++;
                    upgradesThisTier = 0;
                    market.removeCondition("population_"+market.getSize());
                    market.setSize(market.getSize()+1);
                    market.addCondition("population_"+market.getSize());
                    stationEntity.setCustomDescriptionId("loa_random_market_tier"+currentTier);
                    updateName();
                    log.info(String.format("Upgraded the market [%s] to tier [%s]", name, currentTier));
                }
            } else {
                getUpgrade();
            }
            upgradeTimer = 0f;
        }

        //Finally, check if we've been captured. If so, we need to self-destruct [salted earth anyone?]
        if (!loa_spawnRandomMarketsPlugin.OUR_FACTION.equals(market.getFactionId()) && !isDone) {
            reportFleetDespawnedToListener(addedListenerTo, null, null);
        }
    }

    //Reports that the fleet has despawned; this means we should clean ourselves from the sector, remove the market/entity, and report all of this to the plugin
    @Override
    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) {
        //Only trigger if we aren't done yet
        if (isDone) {return;}

        //Also, only trigger on our own station fleet
        if (addedListenerTo != null && fleet == addedListenerTo) {
            //Expires the station
            market.setFactionId(Factions.NEUTRAL);
            Misc.fadeAndExpire(stationEntity);

            //Removes ourselves from our main plugin and the sector's engine
            plugin.existingMarkets.remove(this);
            plugin.reportMarketRemoved(market);
            Global.getSector().getEconomy().removeMarket(market);
            Misc.removeRadioChatter(market);
            market.advance(0f);
            Global.getSector().removeScript(this);

            //Tells the sector we're ready to be removed from memory, in case the previous step wasn't enough
            isDone = true;

            //Logs that we've been defeated
            log.info(String.format("Removed the market [%s] due to being defeated in combat or captured", name));
        }
    }


    //Updates the name to the correct one, taking size and suffix into consideration
    private void updateName () {
        stationEntity.setName(name + " " + NAME_SUFFIX_MAP.get(currentTier));
        market.setName(name + " " + NAME_SUFFIX_MAP.get(currentTier));
    }


    //Gets an upgrade, depending on our current tier
    private void getUpgrade () {
        //Iterate through all the possible upgrades, remove the ones we can't get, and add the rest with a weighting factor
        WeightedRandomPicker<UpgradeData> picker = new WeightedRandomPicker<>();
        for (UpgradeData data : UPGRADE_DATAS) {
            //Don't get stuff not belonging to our own tier
            if (data.tier != currentTier) { continue; }

            //Don't get stuff we have already gotten earlier
            if (alreadyGottenUpgrades.contains(data.ID)) {
                continue;
            }

            //Don't get stuff we don't have the downgrade for (if we have a downgrade)
            if (data.upgradesFrom != null) {
                if (data.isCondition) {
                    if (!market.hasCondition(data.upgradesFrom)) { continue; }
                } else {
                    if (!market.hasIndustry(data.upgradesFrom)) { continue; }
                }
            }

            //And don't get stuff the market actually can't mount (only applies for industries)
            if (!data.isCondition) {
                if (!Global.getSettings().getIndustrySpec(data.ID).getNewPluginInstance(market).isAvailableToBuild()) {
                    continue;
                }
            }

            //If we didn't fail the checks, add us to the picker
            picker.add(data, data.weight);
        }

        //Now that the picker is done being populated, we pick one data at random
        UpgradeData pickedData = picker.pick();

        //If we picked nothing, then there are no more picks left: simply return upgrade-less and log the event
        if (pickedData == null) {
            log.warn(String.format("The market [%s] wanted to get another upgrade, but there were no valid ones available!", name));
            return;
        }

        //Then we start applying it; first, remove the downgrade if we have one
        if (pickedData.upgradesFrom != null) {
            if (pickedData.isCondition) {
                market.removeCondition(pickedData.upgradesFrom);
            } else {
                market.removeIndustry(pickedData.upgradesFrom, MarketAPI.MarketInteractionMode.LOCAL, true);
            }
        }

        //Second, add the new upgrade
        if (pickedData.isCondition) {
            market.addCondition(pickedData.ID);
            //Also logs it to the log
            log.info(String.format("Upgraded the market [%s] with the [%s] condition", name, pickedData.ID));
        } else {
            market.addIndustry(pickedData.ID);
            //Also logs it to the log
            log.info(String.format("Upgraded the market [%s] with the [%s] industry", name, pickedData.ID));
        }

        //Slightly cheating, but we'll need to do it like this: if we just got the Military Base upgrade, add the military submarket
        if (pickedData.ID.equals("militarybase")) {
            market.addSubmarket(Submarkets.GENERIC_MILITARY);
        }

        //And lastly, register all the stuff and update the market
        alreadyGottenUpgrades.add(pickedData.ID);
        upgradesThisTier++;
        market.reapplyConditions();
        market.reapplyIndustries();
    }

    //Returns our current tier
    public int getCurrentTier() {
        return currentTier;
    }

    //Returns our name, without the suffix
    public String getBaseName() { return name; }

    //We don't have to report a battle *occurring*, so we do nothing here
    @Override
    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
        //Do nothing!
    }

    //We are done when we are done (who'd have thought!)
    @Override
    public boolean isDone() {
        return isDone;
    }

    //We don't run when paused
    @Override
    public boolean runWhilePaused() {
        return false;
    }


    //This class defines all necessary data for an "upgrade" for the market
    private static class UpgradeData {
        public final String ID;             //ID of the item to be added, as specified in Industries/Conditions.csv
        public final boolean isCondition;   //Anything that isn't a condition is an Industry
        public final int tier;              //Determines build order; this upgrade is only available in the tier specified here
        public final float weight;          //How likely the upgrade is to be picked compared to other upgrades
        public final String upgradesFrom;   //The condition/industry this upgrade replaces

        public UpgradeData (String ID, boolean isCondition, int tier, float weight, String upgradesFrom) {
            this.ID = ID;
            this.isCondition = isCondition;
            this.tier = tier;
            this.weight = weight;
            this.upgradesFrom = upgradesFrom;
        }
    }
}
