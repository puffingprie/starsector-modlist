package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import org.apache.log4j.Logger;

public class loa_raid_economy_market_opening_listener extends BaseCampaignEventListener {
    //A debug logger to more easily track what the script is doing
    private static Logger log = Global.getLogger(loa_raid_economy_market_opening_listener.class);

    MarketAPI ourMarket;
    loa_raid_economy ourCondition;

    private boolean hasAddedContentThisMonth = false;

    public loa_raid_economy_market_opening_listener(MarketAPI market, loa_raid_economy condition) {
        super(true);
        ourMarket = market;
        ourCondition = condition;
    }

    @Override
    public void reportEconomyMonthEnd() {
        //Reset our counter for if we've added new content this economy month
        hasAddedContentThisMonth = false;

        //Just remove ourselves if the economy month ends and our market is no longer in the economy
        if (!ourMarket.isInEconomy() || ourMarket == null) {
            Global.getSector().removeListener(this);
            ourCondition = null;
            ourMarket = null;
        }
    }

    @Override
    public void reportPlayerOpenedMarketAndCargoUpdated(MarketAPI market) {
        if (market == ourMarket && !hasAddedContentThisMonth) {
            ourCondition.addWeapons();
            ourCondition.addWings();
            ourCondition.addCivShips();
            ourCondition.addMilShips();
            hasAddedContentThisMonth = true;
        }
    }
}
