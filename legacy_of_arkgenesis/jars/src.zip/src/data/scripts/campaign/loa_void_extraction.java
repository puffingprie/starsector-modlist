package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;

import java.awt.*;

/**
 * Produces most low-level commodities at the expense of hulls and heavy machinery
 *      Fairly uniquely among industries, it scales at less than linear rate with market size
 * @author Nicke535
 */
public class loa_void_extraction extends BaseIndustry {

    //The various amounts of resources that are produced per population (so at 0.5f, a size 4 colony would generate 2 of the material)
    //  Rounded down, so 0.3f would give a size 3 colony 0 bonus production and a size 4 colony 1 bonus production
    private static final float ORE_PER_POP = 0.34f;
    private static final float RARE_ORE_PER_POP = 0.34f;
    private static final float FOOD_PER_POP = 0.34f;
    private static final float VOLATILES_PER_POP = 0.34f;
    private static final float ORGANICS_PER_POP = 0.34f;

    //Base resource gain: at "zero" size, the colony would generate this much of each resource
    private static final float ORE_BASE = 1.66f;
    private static final float RARE_ORE_BASE = 1f;
    private static final float FOOD_BASE = 2f;
    private static final float VOLATILES_BASE = 2f;
    private static final float ORGANICS_BASE = 1.33f;

    //Resource demand "modifier" of ships and machinery, respectively.
    //  To follow vanilla standards: the demand for commodities is always equal to market size + a demand modifier, almost always a negative one
    //  For example, Heavy Industries have a metal demand modifier of 0 and rare metal demand modifier of -2 (thus making the final metal cost equal to market size, and rare metal cost 2 lower than market size)
    private static final int SHIP_DEMAND_MOD = 0;
    private static final int MACHINERY_DEMAND_MOD = -1;

    @Override
    public void apply() {
        super.apply(true);

        //If we have a Beta core, we actually get a bonus to our production of Ore, Food and Volatiles
        boolean beta = Commodities.BETA_CORE.equals(aiCoreId);
        int basicResourceBonus = 0;
        if (beta) {basicResourceBonus = SUPPLY_BONUS;}

        int size = market.getSize();

        demand(Commodities.SHIPS, size + SHIP_DEMAND_MOD);
        demand(Commodities.HEAVY_MACHINERY, size + MACHINERY_DEMAND_MOD);

        supply(Commodities.ORE, (int) (ORE_BASE + (int)Math.floor(size*ORE_PER_POP) + basicResourceBonus));
        supply(Commodities.RARE_ORE, (int) (RARE_ORE_BASE + (int)Math.floor(size* RARE_ORE_PER_POP)));
        supply(Commodities.FOOD, (int) (FOOD_BASE + (int)Math.floor(size*FOOD_PER_POP) + basicResourceBonus));
        supply(Commodities.VOLATILES, (int) (VOLATILES_BASE + (int)Math.floor(size*VOLATILES_PER_POP) + basicResourceBonus));
        supply(Commodities.ORGANICS, (int) (ORGANICS_BASE + (int)Math.floor(size*ORGANICS_PER_POP)));

        Pair<String, Integer> deficit = getMaxDeficit(Commodities.SHIPS, Commodities.HEAVY_MACHINERY);

        applyDeficitToProduction(1, deficit, Commodities.ORE, Commodities.RARE_ORE, Commodities.FOOD,
                Commodities.VOLATILES, Commodities.ORGANICS);

        if (!isFunctional()) {
            supply.clear();
        }
    }

    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public boolean isDemandLegal(CommodityOnMarketAPI com) {
        return true;
    }

    @Override
    public boolean isSupplyLegal(CommodityOnMarketAPI com) {
        return true;
    }

    //We excludes the normal Beta version of the supply/demand increase, since that's handled differently for us. Instead, just apply the Gamma bonus
    @Override
    protected void updateAICoreToSupplyAndDemandModifiers() {
        if (aiCoreId == null) {
            return;
        }

        boolean alpha = aiCoreId.equals(Commodities.ALPHA_CORE);
        boolean beta = aiCoreId.equals(Commodities.BETA_CORE);
        boolean gamma = aiCoreId.equals(Commodities.GAMMA_CORE);

        if (alpha) {
            applyAlphaCoreSupplyAndDemandModifiers();
        } else if (beta) {
            applyGammaCoreSupplyAndDemandModifiers();
        } else if (gamma) {
            applyGammaCoreSupplyAndDemandModifiers();
        }
    }

    //Our descriptions for Alpha and Beta cores are not correct compared to vanilla, so change those
    @Override
    protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10f;
        Color highlight = Misc.getHighlightColor();

        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }
        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
            text.addPara(pre + "Reduces demand by %s unit. " +
                            "Increases production by %s unit.", 0f, highlight,
                    "" + DEMAND_REDUCTION,
                    "" + SUPPLY_BONUS);
            tooltip.addImageWithText(opad);
            return;
        }

        tooltip.addPara(pre + "Reduces demand by %s unit. " +
                        "Increases production by %s unit.", opad, highlight,
                "" + DEMAND_REDUCTION,
                "" + SUPPLY_BONUS);
    }

    @Override
    protected void addBetaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10f;
        Color highlight = Misc.getHighlightColor();

        String pre = "Beta-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Beta-level AI core. ";
        }
        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
            text.addPara(pre + "Reduces demand by %s unit. " +
                            "Increases production of %s, %s and %s by %s unit.", 0f, highlight,
                    "" + DEMAND_REDUCTION,
                    "ore",
                    "food",
                    "volatiles",
                    "" + SUPPLY_BONUS);
            tooltip.addImageWithText(opad);
            return;
        }

        tooltip.addPara(pre + "Reduces demand by %s unit. " +
                        "Increases production of %s, %s and %s by %s unit.", opad, highlight,
                "" + DEMAND_REDUCTION,
                "ore",
                "food",
                "volatiles",
                "" + SUPPLY_BONUS);
    }
}
