// Bar event of the Champion quest
package data.scripts.campaign.intel.bar.events;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;
import com.fs.starfarer.api.impl.campaign.procgen.DefenderDataOverride;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.characters.FullName.Gender;

import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.AddedEntity;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.jetbrains.annotations.Nullable;
import org.lazywizard.lazylib.MathUtils;

import java.awt.*;
import java.util.*;
import java.util.List;

public class ChampionBarEvent extends BaseBarEventWithPerson {

    public static String CHAMPION_KEY = "$champion_derelict";
    public static String CHAMPION_SYSTEM_KEY = "$champion_system";
    public static String CHAMPION_PIRATE_KEY = "$champion_pirate";

    public static enum OptionId {
        INIT,
        CONTINUE_1,
        CONTINUE_2,
        CONTINUE_3,
        CONTINUE_4,
        LEAVE,
    }

    private static int COORD_PRICE = 7500;

    //This is the "grace distance" the champion's orbit will have to the nearest planet. It will be forced outwards in
    //orbit until it's further away from a planet than this
    private static final float CHAMPION_SPAWN_GRACE_DISTANCE = 200f;
    //Name of the debris belt the Champion spawns in
    private static final String CHAMPION_BELT_NAME = "Wreck Ring";
    //This is how much the orbit's of the various derelicts in the Champion's field vary in height (still same orbit time)
    private static final float CHAMPION_BELT_VARIATION = 128f;
    //The amount of derelicts to spawn in the champion's ring
    private static final int CHAMPION_DERELICTS_AMOUNT = 25;
    //What is the lowest strength (in fleet points) the Champion's defenders can have?
    private static final float CHAMPION_DERELICT_STRENGTH_MIN = 75f;
    //What is the highest strength (in fleet point) the Champion's defenders can have?
    private static final float CHAMPION_DERELICT_STRENGTH_MAX = 200f;

    // get the Champion's entity
    public static SectorEntityToken getChampion() {
        return (SectorEntityToken) Global.getSector().getMemoryWithoutUpdate().get(CHAMPION_KEY);
    }
    // get the system
    public static StarSystemAPI getSystem() {
        return (StarSystemAPI) Global.getSector().getMemoryWithoutUpdate().get(CHAMPION_SYSTEM_KEY);
    }
    // get the system
    public static PersonAPI getPirate() {
        return (PersonAPI) Global.getSector().getMemoryWithoutUpdate().get(CHAMPION_PIRATE_KEY);
    }

    public static final Set<String> MARKET_FACTIONS = new LinkedHashSet<>(5);
    // factions whose markets can have the bar event
    static {
        MARKET_FACTIONS.add(Factions.HEGEMONY);
        MARKET_FACTIONS.add(Factions.INDEPENDENT);
        MARKET_FACTIONS.add(Factions.PERSEAN);
        MARKET_FACTIONS.add(Factions.PIRATES);
        MARKET_FACTIONS.add("al_ars");
    }

    private static final float GAUSSIAN_DERELICT_PERCENTAGE = 0.3f;
    private static final List<String> ALLOWED_DERELICT_WRECKS = new ArrayList<>();
    static {
        ALLOWED_DERELICT_WRECKS.add("picket_Assault");
        ALLOWED_DERELICT_WRECKS.add("sentry_FS");
        ALLOWED_DERELICT_WRECKS.add("defender_PD");
        ALLOWED_DERELICT_WRECKS.add("warden_Defense");
        ALLOWED_DERELICT_WRECKS.add("bastillon_Standard");
    }

    public ChampionBarEvent() {
        super();
    }

    // must be a valid faction, player must be level 10 or higher
    public boolean shouldShowAtMarket(MarketAPI market) {
        if (!super.shouldShowAtMarket(market)) return false;

        if (Global.getSector().getPlayerStats().getLevel() < 10 && !DebugFlags.BAR_DEBUG) return false;

        return MARKET_FACTIONS.contains(market.getFactionId());
    }

    // spawn all the quest items. Done before intel is added to avoid issues
    protected void generate() {

        WeightedRandomPicker<StarSystemAPI> picker = new WeightedRandomPicker<StarSystemAPI>(random);
        for (StarSystemAPI system : Global.getSector().getStarSystems()) {
            if (system.hasTag(Tags.THEME_CORE_POPULATED) || system.hasTag(Tags.THEME_CORE_UNPOPULATED) || system.isNebula()) continue;
            float w = 10000f;
            // do not pick unless there's absolutely nothing else
            if (system.hasTag(Tags.THEME_REMNANT) || system.hasTag("breakers")) {
                w = 0.1f;
            }
            //if (!Misc.getMarketsInLocation(system).isEmpty()) continue;

            picker.add(system);
        }

        StarSystemAPI system = picker.pick();
        //if (system1 == null) {
        //	doDataFail();
        //	return;
        //}

        if (system != null) {
            float orbitRadiusToUse = GetChampionOrbitRing(system, CHAMPION_SPAWN_GRACE_DISTANCE);
            SpawnChampionRing(system, CHAMPION_BELT_NAME, orbitRadiusToUse, CHAMPION_BELT_VARIATION, CHAMPION_DERELICTS_AMOUNT,
                    CHAMPION_DERELICT_STRENGTH_MIN, CHAMPION_DERELICT_STRENGTH_MAX);
        }

        Global.getSector().getMemoryWithoutUpdate().set(CHAMPION_SYSTEM_KEY, system);
        Global.getSector().getPlayerFleet().getCargo().getCredits().add(-1 * COORD_PRICE);
    }

    // add the quest to intel
    protected void addIntel() {

        TextPanelAPI text = dialog.getTextPanel();
        SectorEntityToken champion = getChampion();

        ChampionIntel intel = new ChampionIntel(champion, this);
        Global.getSector().getIntelManager().addIntel(intel, false, text);
    }

    // set up the NPC shown during the bar event. Picks a suitable portrait from 4 options for each gender
    @Override
    protected void regen(MarketAPI market) {
        if (this.market == market) return;
        super.regen(market);

        if (person.getGender() == FullName.Gender.MALE) {
            person.setPortraitSprite(pickMalePortrait());
        } else {
            person.setPortraitSprite(pickFemalePortrait());
        }
        Global.getSector().getMemoryWithoutUpdate().set(CHAMPION_PIRATE_KEY, person);
    }

    // the text shown when you enter the bar screen. Picks a random description and prompt from 4 options
    @Override
    public void addPromptAndOption(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        super.addPromptAndOption(dialog, memoryMap);

        regen(dialog.getInteractionTarget().getMarket());

        TextPanelAPI text = dialog.getTextPanel();
        text.addPara(pickDescription());

        Color c = Misc.getBasePlayerColor();
        //Color c = Misc.getHighlightColor();

        dialog.getOptionPanel().addOption(pickPrompt(), this,
                c, null);
    }

    @Override
    public void init(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        super.init(dialog, memoryMap);

        done = false;

        dialog.getVisualPanel().showPersonInfo(person, true);

        optionSelected(null, OptionId.INIT);
    }

    // the dialogue itself
    @Override
    public void optionSelected(String optionText, Object optionData) {
        if (!(optionData instanceof OptionId)) {
            return;
        }
        OptionId option = (OptionId) optionData;

        Color t = Misc.getTextColor();
        Color h = Misc.getHighlightColor();
        Color n = Misc.getNegativeHighlightColor();
        float pad = 3f;

        OptionPanelAPI options = dialog.getOptionPanel();
        TextPanelAPI text = dialog.getTextPanel();
        options.clearOptions();

        switch (option) {
            case INIT:

                text.addPara("You approach the spacer and they take note of you, a disarming smile and cocked brow marking their expression. 'Well well, someone's got a nose for opportunity, don't they?'");

                options.addOption("Return their smile and nod, before inquiring further.", OptionId.CONTINUE_1);
                options.addOption("Apologize, stating that you mistook them for someone else, and take your leave.", OptionId.LEAVE);
                break;
            case CONTINUE_1:

                text.addPara("'I'm a scav, I'm sure you know all about what that entails, so I'll spare you the introduction. The part you care about will probably relate to this.' They pull out a Tripad and turn the screen towards you. On its display is a wall of data readouts, and a slideshow of blurry, unfocused pictures and sensor renderings, showing what appears to be some kind of ship. Its hard to make out, but its certainly not a hull configuration you've ever seen. 'I stumbled across this little mystery out in the frontier, no clue what it is, but it looks weird, and people around here pay good money for weird.' The spacer takes back their Tripad and pulls out a chip from one of its external ports. 'It was absolutely crawling with those old drones though, a bit too hot for my blood, but for a modest finders fee of "  + COORD_PRICE + " credits, I'd be happy to tell you where it is.'", t, h, "" + COORD_PRICE);

                options.addOption("The smell of adventure fills your nostrils, agree to the terms and take the data chip.", OptionId.CONTINUE_2);
                if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() <= 7500) {
                    options.setEnabled(OptionId.CONTINUE_2, false);
                    options.setTooltip(OptionId.CONTINUE_2, "You don't have enough credits.");
                }
                options.addOption("Appear to mull it over a bit before declining, paying for something you have to retrieve yourself sounds like bad business.", OptionId.LEAVE);
                break;
            case CONTINUE_2:
                generate();

                text.addPara("It's been a pleasure, maybe if we run into each other again you can tell me about what you found, hm?");

                text.setFontSmallInsignia();

                text.addPara("Lost " + COORD_PRICE + " credits", n, h, "" + COORD_PRICE);

                text.setFontInsignia();
                options.addOption("Continue", OptionId.CONTINUE_3);
                break;
            case CONTINUE_3:

                text.addPara("You slot the chip into your own Tripad, checking over the data before nodding and excusing yourself from the spacer's company.");

                BarEventManager.getInstance().notifyWasInteractedWith(this);
                addIntel();
                options.addOption("Continue", OptionId.CONTINUE_4);
                break;
            case CONTINUE_4:

                text.addPara("Satisfied with their earnings, the Spacer disappears into the crowd of patrons.");

                options.addOption("Leave", OptionId.LEAVE);
                break;
            case LEAVE:
                noContinue = true;
                done = true;
                break;
        }
    }

    protected transient boolean failed = false;
    protected void doDataFail() {
        failed = true;
    }

    // all of these are settings for the interaction target
    @Override
    protected String getPersonFaction() {
        return Factions.PIRATES;
    }

    @Override
    protected String getPersonRank() {
        return Ranks.SPACE_CAPTAIN;
    }

    @Override
    protected String getPersonPost() {
        return Ranks.POST_MERCENARY;
    }

    @Override
    protected String getPersonPortrait() {
        return null;
    }

    @Override
    protected Gender getPersonGender() {
        return Gender.ANY;
    }

    protected String pickMalePortrait() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("graphics/portraits/portrait_pirate02.png");
        post.add("graphics/portraits/portrait_pirate03.png");
        post.add("graphics/portraits/portrait_mercenary04.png");
        post.add("graphics/portraits/portrait33.png");
        return post.pick();
    }

    protected String pickFemalePortrait() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("graphics/portraits/portrait14.png");
        post.add("graphics/portraits/portrait21.png");
        post.add("graphics/portraits/portrait29.png");
        post.add("graphics/portraits/portrait_mercenary05.png");
        return post.pick();
    }

    protected String pickDescription() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("A veteran spacer is leaned against a support beam, casting an appraising glance into the throngs of bar patrons.");
        post.add("An unkempt looking spacer sits slouched over the drink, occasionally tilting their head up to glare into the crowd.");
        post.add("A gritty looking spacer shuffles by, almost running into you as they scan each booth along their path, sizing up the people sitting in them.");
        return post.pick();
    }

    protected String pickPrompt() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("Wait until the spacer's eyes meet your own, return a curious glare and move to join them.");
        post.add("Grab a pair of drinks from the bar and try to break the ice with the spacer.");
        post.add("Try to grab the spacers attention and make your way over to them.");
        return post.pick();
    }

    // Nicke's functions used for spawning the Champion
    /**
     *  Utility function for getting a valid ring orbit between a system's outermost planet and outermost jump point,
     *  with a grace distance to not get too close to the planet. If no planets exist, get a distance outside the
     *  system's outermost jump point, as determined by the grace distance
     *
     *  Will not collide with the outermost planet, but some odd configurations of planets and/or multi-star systems
     *  may cause issues. Use on single-star systems with Fringe jump points for the best results
     *
     *  Returns negative numbers in case of an error occurring (no jump points, for example)
     *
     *  @param system The system to get the ring coordinates in
     *  @param graceDistance The "grace distance" from the outermost planet; we will not get an orbit closer than this
     *                       to that planet (too high values may force us far out of the system, so be careful)
     **/
    public static float GetChampionOrbitRing (StarSystemAPI system, float graceDistance) {
        //First, get all the system's planets and jump points, so we know if either are empty
        List<PlanetAPI> systemPlanets = new ArrayList<>();
        List<JumpPointAPI> jumpPoints = new ArrayList<>();
        for (SectorEntityToken token : system.getAllEntities()) {
            //The center token is ignored (this is most often a star, but either way we can't use it due to math)
            if (token == system.getCenter()) {
                continue;
            }

            //Also, ignore stuff not circling the system center, since their orbits may intersect us
            if (token.getOrbit() == null || token.getOrbit().getFocus() != system.getCenter()) {
                continue;
            }

            //Get the planets
            if (token instanceof PlanetAPI) {
                systemPlanets.add((PlanetAPI) token);
            }

            //...and the jump points
            else if (token instanceof JumpPointAPI) {
                jumpPoints.add((JumpPointAPI)token);
            }
        }

        //Is our jump point list empty? That shouldn't ever happen, but in case it does return -1f
        if (jumpPoints.isEmpty()) {
            return -1f;
        }

        //Since our jump points weren't empty, we get the outermost jump point for later use
        float outermostJumppointRadius = 0f;
        for (JumpPointAPI point : jumpPoints) {
            float distance = point.getCircularOrbitRadius();
            if (distance > outermostJumppointRadius) {
                outermostJumppointRadius = distance;
            }
        }

        //Is our planet list empty? In that case, we use a simplified algorithm; simply get a distance outside the outermost jump point
        if (systemPlanets.isEmpty()) {
            return (outermostJumppointRadius + graceDistance);
        }

        //If our planet list *isn't* empty, we try and find which planet is furthest out in the system
        else {
            PlanetAPI furthestPlanet = null;
            for (PlanetAPI planet : systemPlanets) {
                if (furthestPlanet == null) {
                    furthestPlanet = planet;
                } else if (planet.getCircularOrbitRadius()+planet.getRadius() > furthestPlanet.getCircularOrbitRadius()+furthestPlanet.getRadius()) {
                    furthestPlanet = planet;
                }
            }

            //Now that we've found the furthest-away planet, we calculate the average orbit between it and the furthermost jump point, and
            //adjusts for our grace distance
            float orbitDistance = (outermostJumppointRadius + furthestPlanet.getCircularOrbitRadius()) / 2f;
            if (orbitDistance < outermostJumppointRadius && orbitDistance < (furthestPlanet.getCircularOrbitRadius() + furthestPlanet.getRadius() + graceDistance)) {
                orbitDistance = (furthestPlanet.getCircularOrbitRadius() + furthestPlanet.getRadius() + graceDistance);
            } else if (orbitDistance > (furthestPlanet.getCircularOrbitRadius() - furthestPlanet.getRadius() - graceDistance)) {
                orbitDistance = (furthestPlanet.getCircularOrbitRadius() - furthestPlanet.getRadius() - graceDistance);
            }

            //Finally, return the orbit
            return orbitDistance;
        }
    }

    public static void SpawnChampionRing (StarSystemAPI system, String customName, float orbitRadius, float orbitVariance,
                                          int amountOfDerelicts, float championDefenderStrengthMin, float championDefenderStrengthMax) {
        //First, calculate our orbit time. This is set so we have a decently slow orbit regardless of radius
        float orbitTime = orbitRadius / 20f;

        //Then, spawn a ring with a custom name
        system.addRingBand(system.getCenter(), "misc", "rings_dust0", 256f, 1, Color.gray,
                128f, orbitRadius, orbitTime, Terrain.RING, customName);


        //After that, we decide an angle for our Champion to spawn; this is important, as the Derelicts in the ring spawn more commonly near the Champion, since we
        //use Gaussian distribution for some derelicts
        float championAngle = MathUtils.getRandomNumberInRange(0f, 360f);

        //Then, we spawn the champion itself, with defenders
        DefenderDataOverride defenders = new DefenderDataOverride(Factions.DERELICT, 1f,championDefenderStrengthMin,championDefenderStrengthMax);
        SectorEntityToken champion = addDerelict(system, system.getCenter(), "loaht_champion1_d_wreck", ShipRecoverySpecial.ShipCondition.BATTERED, orbitRadius, orbitTime,
                championAngle, true, defenders);

        // Raccoon modification: give the Champion a key so we can track it down later
        Global.getSector().getMemoryWithoutUpdate().set(CHAMPION_KEY, champion);
        champion.addTag("ChampionDerelict");

        //And lastly, we add all the non-salvageable derelicts
        for (int i = 0; i <amountOfDerelicts; i++) {
            //First, get an angle
            float angle = championAngle;

            //We have a chance to use gaussian distribution
            if (Math.random() < GAUSSIAN_DERELICT_PERCENTAGE) {
                Random rand = new Random();
                angle += 60f * rand.nextGaussian();
            } else {
                angle += MathUtils.getRandomNumberInRange(-180f, 180f);
            }

            //Then, we get our orbit radius for this specific derelict
            float localRadius = MathUtils.getRandomNumberInRange(orbitRadius-orbitVariance, orbitRadius+orbitVariance);

            //Lastly, spawn the derelict
            addDerelict(system, system.getCenter(), getDerelictVariant(), ShipRecoverySpecial.ShipCondition.WRECKED,
                    localRadius, orbitTime, angle, false, null);
        }
    }


    //Mini-function for generating the derelicts in the system, and for generating the Champion
    private static SectorEntityToken addDerelict(StarSystemAPI system, SectorEntityToken focus, String variantId,
                                                 ShipRecoverySpecial.ShipCondition condition, float orbitRadius, float daysToOrbit,
                                                 float startOrbitAngle, boolean recoverable, @Nullable DefenderDataOverride defenders) {

        DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        ship.setCircularOrbit(focus, startOrbitAngle, orbitRadius, daysToOrbit);

        if (recoverable) {
            SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        if (defenders != null) {
            Misc.setDefenderOverride(ship, defenders);
        }
        return ship;
    }


    // Mini-function for getting a random ship classified as a Derelict in our list at the top of the script.
    // Returns "picket_Assault" if none of the designated variants exist (and returns Null if, somehow, the Picket doesn't exist)
    private static String getDerelictVariant () {
        //Get all variants that can be spawned, and put them in a list
        List<String> validStrings = new ArrayList<>();
        for (String s : ALLOWED_DERELICT_WRECKS) {
            if (Global.getSettings().getVariant(s) != null) {
                validStrings.add(s);
            }
        }

        //If we had *any* valid variants, select one of those at random
        if (!validStrings.isEmpty()) {
            int rand = MathUtils.getRandomNumberInRange(0, validStrings.size()-1);
            return validStrings.get(rand);
        }

        //Backup plan: none of the derelicts we specified exists, so we use the Picket instead
        else {
            if (Global.getSettings().getVariant("picket_Assault") != null) {
                return "picket_Assault";
            }

            //Backup BACKUP plan; return Null if the picket doesn't exist (trying to run this with a total conversion, eh?)
            else {
                return null;
            }
        }
    }
}
