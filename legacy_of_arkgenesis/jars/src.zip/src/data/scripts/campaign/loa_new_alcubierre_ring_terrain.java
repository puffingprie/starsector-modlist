package data.scripts.campaign;

import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import com.fs.starfarer.api.impl.campaign.ids.Abilities;
import com.fs.starfarer.api.impl.campaign.terrain.*;
import com.fs.starfarer.api.loading.Description;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignEngineLayers;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TerrainAIFlags;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.campaign.terrain.AuroraRenderer.AuroraRendererDelegate;
import com.fs.starfarer.api.impl.campaign.terrain.FlareManager.FlareManagerDelegate;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import data.scripts.campaign.loa_AnargaiaDeathManager.DEATH_STAGE;

/**
 * Handles the terrain for the Alcubierre Drive Boundary
 * Fair warning, this file is shock-full of settings I can't quite grasp. They're near the bottom, feel free to change to try and get a better visual look.
 * Almost everything shouldn't impact the terrain's function, only its looks
 */
public class loa_new_alcubierre_ring_terrain extends BaseRingTerrain implements AuroraRendererDelegate, FlareManagerDelegate {

    public static class AlcubierreParams extends RingParams {
        public float windBurnLevel;
        public float flareProbability;
        public float crLossMult;

        public AlcubierreParams(float bandWidthInEngine, float middleRadius,
                                SectorEntityToken relatedEntity,
                                float windBurnLevel, float flareProbability, float crLossMult) {
            super(bandWidthInEngine, middleRadius, relatedEntity);
            this.windBurnLevel = windBurnLevel;
            this.flareProbability = flareProbability;
            this.crLossMult = crLossMult;
        }
    }

    transient protected SpriteAPI texture = null;
    transient protected Color color;

    protected AuroraRenderer renderer;
    protected FlareManager flareManager;
    protected AlcubierreParams params;

    protected transient RangeBlockerUtil blocker = null;

    public void init(String terrainId, SectorEntityToken entity, Object param) {
        super.init(terrainId, entity, param);
        params = (AlcubierreParams) param;
        name = params.name;
        if (name == null) {
            name = "Alcubierre Drive Boundary";
        }
    }

    @Override
    protected Object readResolve() {
        super.readResolve();
        texture = Global.getSettings().getSprite("terrain", "aurora");
        layers = EnumSet.of(CampaignEngineLayers.TERRAIN_7);
        if (renderer == null) {
            renderer = new AuroraRenderer(this);
        }
        if (flareManager == null) {
            flareManager = new FlareManager(this);
        }
        if (blocker == null) {
            blocker = new RangeBlockerUtil(360, super.params.bandWidthInEngine + 1000f);
        }
        return this;
    }

    Object writeReplace() {
        return this;
    }

    @Override
    protected boolean shouldPlayLoopOne() {
        return super.shouldPlayLoopOne() && !flareManager.isInActiveFlareArc(Global.getSector().getPlayerFleet());
    }

    @Override
    protected boolean shouldPlayLoopTwo() {
        return super.shouldPlayLoopTwo() && flareManager.isInActiveFlareArc(Global.getSector().getPlayerFleet());
    }



    transient private EnumSet<CampaignEngineLayers> layers = EnumSet.of(CampaignEngineLayers.TERRAIN_7);
    public EnumSet<CampaignEngineLayers> getActiveLayers() {
        return layers;
    }

    public AlcubierreParams getParams() {
        return params;
    }

    public void advance(float amount) {
        super.advance(amount);
        renderer.advance(amount);
        flareManager.advance(amount);

        if (amount > 0 && blocker != null) {
            blocker.updateLimits(entity, params.relatedEntity, 0.5f);
            blocker.advance(amount, 100f, 0.5f);
        }

        //New addition: if Anargaia dies, we collapse in size and have different names and descriptions
        if (Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY) instanceof DEATH_STAGE) {
            DEATH_STAGE deathStage = (DEATH_STAGE)Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY);
            if (deathStage == DEATH_STAGE.FIRST) {
                float outerRadius = params.middleRadius+(params.bandWidthInEngine/2f);
                float plannedInnerRadius = (params.middleRadius-(params.bandWidthInEngine/2f)) * (float)Math.pow(0.55f,amount); // Shrinks 45% per second, should be fast but not instant
                this.params.middleRadius = (outerRadius+plannedInnerRadius)/2f;
                this.params.bandWidthInEngine = outerRadius-plannedInnerRadius;
                this.name = "Collapsing Warp Bubble";
            }
        }
    }

    public void render(CampaignEngineLayers layer, ViewportAPI viewport) {
        if (blocker != null && !blocker.wasEverUpdated()) {
            blocker.updateAndSync(entity, params.relatedEntity, 0.5f);
        }
        renderer.render(viewport.getAlphaMult());
    }

    @Override
    public float getRenderRange() {
        FlareManager.Flare curr = flareManager.getActiveFlare();
        if (curr != null) {
            float outerRadiusWithFlare = computeRadiusWithFlare(flareManager.getActiveFlare());
            return outerRadiusWithFlare + 200f;
        }
        return super.getRenderRange();
    }

    @Override
    public boolean containsPoint(Vector2f point, float radius) {
        if (blocker != null && blocker.isAnythingShortened()) {
            float angle = Misc.getAngleInDegrees(this.entity.getLocation(), point);
            float dist = Misc.getDistance(this.entity.getLocation(), point);
            float max = blocker.getCurrMaxAt(angle);
            if (dist > max) return false;
        }

        if (flareManager.isInActiveFlareArc(point)) {
            float outerRadiusWithFlare = computeRadiusWithFlare(flareManager.getActiveFlare());
            float dist = Misc.getDistance(this.entity.getLocation(), point);
            if (dist > outerRadiusWithFlare + radius) return false;
            if (dist + radius < params.middleRadius - params.bandWidthInEngine / 2f) return false;
            return true;
        }
        return super.containsPoint(point, radius);
    }

    protected float computeRadiusWithFlare(FlareManager.Flare flare) {
        float inner = params.middleRadius - params.bandWidthInEngine * 0.5f;
        float thickness = params.bandWidthInEngine;

        thickness *= flare.extraLengthMult;
        thickness += flare.extraLengthFlat;

        return inner + thickness;
    }

    @Override
    protected float getExtraSoundRadius() {
        float base = super.getExtraSoundRadius();

        float angle = Misc.getAngleInDegrees(params.relatedEntity.getLocation(), Global.getSector().getPlayerFleet().getLocation());
        float extra = 0f;
        if (flareManager.isInActiveFlareArc(angle)) {
            extra = computeRadiusWithFlare(flareManager.getActiveFlare()) - params.bandWidthInEngine;
        }
        //System.out.println("Extra: " + extra);
        return base + extra;
    }


    @Override
    public void applyEffect(SectorEntityToken entity, float days) {
        if (entity instanceof CampaignFleetAPI) {
            CampaignFleetAPI fleet = (CampaignFleetAPI) entity;

            //Push the fleet inwards: also reduce their burn drive speed more and more closer to the edge
            float distanceToCenter = MathUtils.getDistance(fleet.getLocation(), this.entity.getLocation());

            //Within the radius of "non-effectiveness": do nothing
            if (distanceToCenter < this.params.middleRadius - this.params.bandWidthInEngine*0.5f) {
                return;
            }



            //Modifies speed based on just how far away the distance is
            //  Note that this is partially ignored for the death sequence: there, we cap it so it's at least 50% of the effect all the time (unless we emergency burn)
            DEATH_STAGE deathStage = DEATH_STAGE.NOT_STARTED;
            if (Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY) instanceof DEATH_STAGE) {
                deathStage = (DEATH_STAGE) Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY);
            }
            float speedMultForDistance = 1f - MathUtils.clamp((distanceToCenter - (this.params.middleRadius - this.params.bandWidthInEngine*0.5f))/(this.params.bandWidthInEngine),0f, 1f);
            if (deathStage != DEATH_STAGE.NOT_STARTED) {
                if (fleet.getAbilities().get(Abilities.EMERGENCY_BURN) == null
                    || !fleet.getAbilities().get(Abilities.EMERGENCY_BURN).isActive()) {
                    speedMultForDistance = Math.min(0.5f, speedMultForDistance);
                }
            }
            fleet.getStats().getMovementSpeedMod().modifyMult("loa_alcubierre_zone", speedMultForDistance);

            //Add a pushing force
            float pushMultForDistance = 1f - speedMultForDistance;
            Vector2f pushDir = VectorUtils.getDirectionalVector(fleet.getLocation(), this.entity.getLocation());
            fleet.setVelocity(fleet.getVelocity().x+days*this.params.windBurnLevel*pushDir.x*pushMultForDistance, fleet.getVelocity().y+days*this.params.windBurnLevel*pushDir.y*pushMultForDistance);
        }
    }



    @Override
    public Color getNameColor() {
        Color bad = Misc.getNegativeHighlightColor();
        Color base = super.getNameColor();
        //bad = Color.red;
        return Misc.interpolateColor(base, bad, Global.getSector().getCampaignUI().getSharedFader().getBrightness() * 1f);
    }

    public boolean hasTooltip() {
        return true;
    }

    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
        float pad = 10f;
        float small = 5f;
        Color gray = Misc.getGrayColor();
        Color highlight = Misc.getHighlightColor();
        Color fuel = Global.getSettings().getColor("progressBarFuelColor");
        Color bad = Misc.getNegativeHighlightColor();

        tooltip.addTitle(name);

        //Our description varies depending on if we're collapsing yet or not
        DEATH_STAGE deathStage = DEATH_STAGE.NOT_STARTED;
        if (Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY) instanceof DEATH_STAGE) {
            deathStage = (DEATH_STAGE) Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY);
        }
        if (deathStage == DEATH_STAGE.NOT_STARTED) {
            tooltip.addPara(Global.getSettings().getDescription(getTerrainId(), Description.Type.TERRAIN).getText1(), pad);

            float nextPad = pad;
            if (expanded) {
                tooltip.addSectionHeading("Travel", Alignment.MID, pad);
                nextPad = small;
            }

            tooltip.addPara("Getting closer to the edge of the Alcubierre Drive's area of effect is %s. You'll have to turn back", pad,
                    bad,
                    "next to impossible"
            );
        } else {
            if (deathStage == DEATH_STAGE.FIRST) {
                tooltip.addPara("This entire area of space is collapsing due to the catastropthic destruction of Anargaia. If you don't get out soon there won't be anything left of you to salvage...", pad);
            } else if (deathStage == DEATH_STAGE.DANGER) {
                tooltip.addPara("This entire area of space is collapsing due to the catastropthic destruction of Anargaia. Your ships are starting to suffer damage from the energies: recommend escaping posthaste.", pad);
            } else if (deathStage == DEATH_STAGE.DAMAGE) {
                tooltip.addPara("The violent energies are ripping everything apart: it's only a matter of seconds before the whole area collapses into nothing! Get us the hell out of here, commander!", pad);
            } else if (deathStage == DEATH_STAGE.FINAL) {
                tooltip.addPara("You should not be seeing this. Please report it to Gwyvern or Nicke535.", pad);
            }
        }
    }

    public boolean isTooltipExpandable() {
        return true;
    }

    public float getTooltipWidth() {
        return 350f;
    }

    public String getTerrainName() {
        return super.getTerrainName();
    }

    public String getEffectCategory() {
        return null; // to ensure multiple coronas overlapping all take effect
        //return "corona_" + (float) Math.random();
    }

    public float getAuroraAlphaMultForAngle(float angle) {
        return 1f;
    }

    public float getAuroraBandWidthInTexture() {
        return 256f;
        //return 512f;
    }

    public float getAuroraTexPerSegmentMult() {
        return 1f;
        //return 2f;
    }

    public Vector2f getAuroraCenterLoc() {
        return params.relatedEntity.getLocation();
    }

    public Color getAuroraColorForAngle(float angle) {
        if (color == null) {
            if (params.relatedEntity instanceof PlanetAPI) {
                color = ((PlanetAPI)params.relatedEntity).getSpec().getCoronaColor();
                //color = Misc.interpolateColor(color, Color.white, 0.5f);
            } else {
                color = Color.WHITE;
            }
            color = Misc.setAlpha(color, 255);
        }
        if (flareManager.isInActiveFlareArc(angle)) {
            return flareManager.getColorForAngle(color, angle);
        }
        return color;
    }

    public float getAuroraInnerRadius() {
        return params.middleRadius - params.bandWidthInEngine * 0.5f;
    }

    public float getAuroraOuterRadius() {
        return params.middleRadius + params.bandWidthInEngine * 0.5f;
    }

    public float getAuroraShortenMult(float angle) {
        return 0.85f + flareManager.getShortenMod(angle);
    }

    public float getAuroraInnerOffsetMult(float angle) {
        return flareManager.getInnerOffsetMult(angle);
    }

    public SpriteAPI getAuroraTexture() {
        return texture;
    }

    public RangeBlockerUtil getAuroraBlocker() {
        return blocker;
    }

    public float getAuroraThicknessFlat(float angle) {
//		float shorten = blocker.getShortenAmountAt(angle);
//		if (shorten > 0) return -shorten;
//		if (true) return -4000f;

        if (flareManager.isInActiveFlareArc(angle)) {
            return flareManager.getExtraLengthFlat(angle);
        }
        return 300f;
    }

    public float getAuroraThicknessMult(float angle) {
        if (flareManager.isInActiveFlareArc(angle)) {
            return flareManager.getExtraLengthMult(angle);
        }
        return 1f;
    }





    public java.util.List<Color> getFlareColorRange() {
        List<Color> result = new ArrayList<Color>();

        result.add(Color.WHITE);
        result.add(Color.WHITE);

        return result;
    }

    public float getFlareArcMax() {
        return 60;
    }

    public float getFlareArcMin() {
        return 30;
    }

    public float getFlareExtraLengthFlatMax() {
        return 500;
    }

    public float getFlareExtraLengthFlatMin() {
        return 200;
    }

    public float getFlareExtraLengthMultMax() {
        return 1.5f;
    }

    public float getFlareExtraLengthMultMin() {
        return 1;
    }

    public float getFlareFadeInMax() {
        return 10f;
    }

    public float getFlareFadeInMin() {
        return 3f;
    }

    public float getFlareFadeOutMax() {
        return 10f;
    }

    public float getFlareFadeOutMin() {
        return 3f;
    }

    public float getFlareOccurrenceAngle() {
        return 0;
    }

    public float getFlareOccurrenceArc() {
        return 360f;
    }

    public float getFlareProbability() {
        return params.flareProbability;
    }

    public float getFlareSmallArcMax() {
        return 90;
    }

    public float getFlareSmallArcMin() {
        return 30;
    }

    public float getFlareSmallExtraLengthFlatMax() {
        return this.params.bandWidthInEngine*1f;
    }

    public float getFlareSmallExtraLengthFlatMin() {
        return this.params.bandWidthInEngine*0.5f;
    }

    public float getFlareSmallExtraLengthMultMax() {
        return 1.1f;
    }

    public float getFlareSmallExtraLengthMultMin() {
        return 1;
    }

    public float getFlareSmallFadeInMax() {
        return 4f;
    }

    public float getFlareSmallFadeInMin() {
        return 0.5f;
    }

    public float getFlareSmallFadeOutMax() {
        return 3f;
    }

    public float getFlareSmallFadeOutMin() {
        return 0.5f;
    }

    public float getFlareShortenFlatModMax() {
        return 0.05f;
    }

    public float getFlareShortenFlatModMin() {
        return 0.05f;
    }

    public float getFlareSmallShortenFlatModMax() {
        return 0.05f;
    }

    public float getFlareSmallShortenFlatModMin() {
        return 0.05f;
    }

    public int getFlareMaxSmallCount() {
        return 20;
    }

    public int getFlareMinSmallCount() {
        return 30;
    }

    public float getFlareSkipLargeProbability() {
        return 0f;
    }

    public SectorEntityToken getFlareCenterEntity() {
        return this.entity;
    }

	//These are for AI avoidance: set them to effectively nonexistant
    public boolean hasAIFlag(Object flag) {
        return false;
    }

    public float getMaxEffectRadius(Vector2f locFrom) {
        return 0f;
    }
    public float getMinEffectRadius(Vector2f locFrom) {
        return 0f;
    }

    public float getOptimalEffectRadius(Vector2f locFrom) {
        return 0f;
    }

    public boolean canPlayerHoldStationIn() {
        return false;
    }
}
