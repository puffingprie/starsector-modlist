package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loamt_suspendedmounts extends BaseHullMod {

    public static final float RECOIL_BONUS = 40f;
    
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getMaxRecoilMult().modifyMult(id, 1f - RECOIL_BONUS * 0.01f);
                stats.getRecoilPerShotMult().modifyMult(id, 1f - RECOIL_BONUS * 0.01f);
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + (int) RECOIL_BONUS + "%";
        }
        return null;
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "Only compatible with Exodus Initiative hulls.";
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        // Allows any ship with a loamt hull id
        return ship.getHullSpec().getHullId().startsWith("loamt_");
    }
}
