package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class al_hfweaponmounts extends BaseHullMod {
    
//	private static Map mag = new HashMap();
//	static {
//		mag.put(HullSize.FRIGATE, 10f);
//		mag.put(HullSize.DESTROYER, 20f);
//		mag.put(HullSize.CRUISER, 25f);
//		mag.put(HullSize.CAPITAL_SHIP, 30f);
//	}    
    
        public static final float RECOIL_BONUS = 30f;
        
        public static final float RANGE_BONUS = 5f;
	
        @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) RANGE_BONUS + "%";
		if (index == 1) return "" + (int) RECOIL_BONUS + "%";
//              if (index == 2) return "" + ((Float) mag.get(HullSize.FRIGATE)).intValue();
//		if (index == 3) return "" + ((Float) mag.get(HullSize.DESTROYER)).intValue();
//		if (index == 4) return "" + ((Float) mag.get(HullSize.CRUISER)).intValue();
//		if (index == 5) return "" + ((Float) mag.get(HullSize.CAPITAL_SHIP)).intValue();
//                if (index == 6) return "Safety Overrides";
		return null;
	}
	
	
        @Override
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
                stats.getMaxRecoilMult().modifyMult(id, 1f - RECOIL_BONUS * 0.01f);
                stats.getRecoilPerShotMult().modifyMult(id, 1f - RECOIL_BONUS * 0.01f);
                stats.getBallisticWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);
		stats.getEnergyWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);
               
	}
//        public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
//                if (!ship.getVariant().getHullMods().contains("safetyoverrides")) {
//                ship.getMutableStats().getZeroFluxSpeedBoost().modifyFlat(id,(Float) mag.get(ship.getHullSize()));
//                }     
//    } 
	
}

