package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

/**
 * Gives resistance to kinetic [including collision!] damage while the module's parent has an active shipsystem
 * @author Nicke535
 */
public class loa_rammingprow extends BaseHullMod {

    private static final float DAMAGE_MULT = 0.01f;

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        if (ship.getParentStation() != null && ship.getParentStation().getSystem() != null && ship.getParentStation().getSystem().isActive()) {
            ship.getMutableStats().getKineticDamageTakenMult().modifyMult(this.getClass().getName()+ship.getId(), DAMAGE_MULT);
            ship.getMutableStats().getKineticShieldDamageTakenMult().modifyMult(this.getClass().getName()+ship.getId(), DAMAGE_MULT);
        } else {
            ship.getMutableStats().getKineticDamageTakenMult().unmodify(this.getClass().getName()+ship.getId());
            ship.getMutableStats().getKineticShieldDamageTakenMult().unmodify(this.getClass().getName()+ship.getId());
        }
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        return null;
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return false;
    }
}
