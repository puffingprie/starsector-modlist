package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;

import java.awt.*;

/**
 * Gives resistance to kinetic [including collision!] damage while the module's parent has an active shipsystem
 * @author Nicke535
 */
public class loa_supermassiveram extends BaseHullMod {

    private static final float DAMAGE_MULT = 0.01f;
    private static final Color JITTER_COLOR = new Color(75,35,0, 50);
    private static final Color JITTER_UNDER_COLOR = new Color(25,35,0, 50);

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        if (ship.getParentStation() != null && ship.getParentStation().getSystem() != null && ship.getParentStation().getSystem().isActive()) {
            ship.getMutableStats().getHullDamageTakenMult().modifyMult(this.getClass().getName()+ship.getId(), DAMAGE_MULT);
            ship.getMutableStats().getArmorDamageTakenMult().modifyMult(this.getClass().getName()+ship.getId(), DAMAGE_MULT);
            ship.getMutableStats().getShieldDamageTakenMult().modifyMult(this.getClass().getName()+ship.getId(), DAMAGE_MULT);

            //Handles jitter
            float jitterLevel = ship.getParentStation().getSystem().getEffectLevel();
            float jitterRangeBonus = 10f;
            jitterLevel *= jitterLevel;

            ship.setJitter(this, JITTER_COLOR, jitterLevel, (int)Math.ceil(4 * jitterLevel), 0, 0 + jitterRangeBonus);
            ship.setJitterUnder(this, JITTER_UNDER_COLOR, jitterLevel, (int)Math.ceil(20 * jitterLevel), 0f, 5f + jitterRangeBonus);
        } else {
            ship.getMutableStats().getHullDamageTakenMult().unmodify(this.getClass().getName()+ship.getId());
            ship.getMutableStats().getArmorDamageTakenMult().unmodify(this.getClass().getName()+ship.getId());
            ship.getMutableStats().getShieldDamageTakenMult().unmodify(this.getClass().getName()+ship.getId());
        }
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        return null;
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return false;
    }
}
