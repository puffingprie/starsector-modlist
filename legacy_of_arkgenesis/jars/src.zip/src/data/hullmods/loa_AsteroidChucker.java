//By Nicke535, almost whole-heartedly copied from Alex Stealth Minefield implementation
//Randomly spawns "asteroid projectiles" near enemy ships in combat
package data.hullmods;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;

public class loa_AsteroidChucker extends BaseHullMod {
	//We don't allow asteroids to spawn closer to a ship than this
	private static float SAFETY_DISTANCE = 10000f;
	
	//The variance in how far away an asteroid spawns from a "target". 400 would mean 0-400 SU away from the minimum spawn distance (SAFETY_DISTANCE)
	private static float SPAWNRANGE_VARIANCE = 15000f;
	
	//We don't want this to stack with several instances of the same hullmod; give it a data key for this
	public static String ASTFIELD_DATA_KEY = "loa_asteroidfield_datakey"; 
	
	//The ID of the weapon to use as asteroid; temporarily set to the Reaper
	protected String getWeaponId() {
		return "loa_asteroid";
	}

	//Approximate checking time to determine number of targets and actually handle spawning.
	//	This doesn't actually affect spawnrate, only in how big "chunks" projectiles spawn: double this and you spawn twice as often with half as many projectiles
	//	Keep relatively high (0.2+ seconds) or it'll be needlessly performance-heavy for how small the improvement is mechanically
	private static final float CHECK_TIME = 0.5f;

	//Base number of asteroids to spawn per second (on average), for the entire battlefield.
	private static final float BASE_SPAWNS_PER_SECOND = 0.5f;

	//Number of asteroids to spawn per second and DP of the enemy fleet (on average), for the entire battlefield.
	private static final float SPAWNS_PER_SECOND_AND_DP = 0.01f;


	//Classes for storing info used later in the script
	public static class IncomingProj {
		Vector2f mineLoc;
		float delay;
		ShipAPI target;
	}
	public static class AstfieldData {
		ShipAPI source;
		IntervalUtil tracker = new IntervalUtil(CHECK_TIME*0.8f, CHECK_TIME*1.2f);
		List<IncomingProj> incoming = new ArrayList<IncomingProj>();
	}
	
	
	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		super.advanceInCombat(ship, amount);
		
		CombatEngineAPI engine = Global.getCombatEngine();
		
		AstfieldData data = (AstfieldData) engine.getCustomData().get(ASTFIELD_DATA_KEY);
		if (data == null) {
			data = new AstfieldData();
			data.source = ship;
			engine.getCustomData().put(ASTFIELD_DATA_KEY, data);
		}
		
		if (data.source != ship) return;
		if (!ship.isAlive()) return;
		
		
		for (IncomingProj inc : new ArrayList<>(data.incoming)) {
			inc.delay -= amount;
			if (inc.delay <= 0) {
				spawnMine(ship, inc.mineLoc, inc.target);
				data.incoming.remove(inc);
			}
		}
		
		data.tracker.advance(amount);
		if (!data.tracker.intervalElapsed()) return;

		// Get all the enemies on the map, count them, and try to register a potential spawn around them. Any that get a proper spawn are added to our picker
		WeightedRandomPicker<IncomingProj> picker = new WeightedRandomPicker<>();
		float enemyDP = 0f;
		for (ShipAPI enemy : engine.getShips()) {
			if (enemy == ship) continue;
			if (enemy.isHulk()) continue;
			if (enemy.getOwner() == ship.getOwner()) continue;
			if (enemy.isFighter()) continue;
			if (enemy.isDrone()) continue;
			if (enemy.isStation()) continue;
			if (enemy.isStationModule()) continue;
			if (enemy.getTravelDrive() != null && enemy.getTravelDrive().isActive()) continue;

			enemyDP += enemy.getMutableStats().getSuppliesToRecover().getBaseValue();
		
			Vector2f mineLoc = Misc.getPointAtRadius(enemy.getLocation(), 
													 enemy.getCollisionRadius() + SAFETY_DISTANCE + SPAWNRANGE_VARIANCE * (float) Math.random());
			float minOk = SAFETY_DISTANCE;
			if (!isAreaClear(mineLoc, minOk)) continue;
			
			IncomingProj inc = new IncomingProj();
			inc.delay = (float) Math.random() * 1.5f;
			inc.target = enemy;
			inc.mineLoc = mineLoc;
			
			picker.add(inc);
		}

		//Calculates the number of spawns we should have this iteration
		float spawns = (BASE_SPAWNS_PER_SECOND + (enemyDP*SPAWNS_PER_SECOND_AND_DP)) * CHECK_TIME;
		int numToSpawn = (int)Math.floor(spawns);
		if (Math.random() < spawns - Math.floor(spawns)) {
			numToSpawn++;
		}

		//Then, we simply spawn the asteroids
		//	Note that if we run out of targets, we don't spawn multiple per target: that would be *a bit* too evil
		for (int i = 0; i < numToSpawn && !picker.isEmpty(); i++) {
			IncomingProj inc = picker.pickAndRemove();
			data.incoming.add(inc);
		}
	}


	public void spawnMine(ShipAPI source, Vector2f mineLoc, ShipAPI target) {
		float mineDir = Misc.getAngleInDegrees(mineLoc, target.getLocation());
		CombatEngineAPI engine = Global.getCombatEngine();
		Vector2f currLoc = Misc.getPointAtRadius(mineLoc, 50f + (float) Math.random() * 50f);
		MissileAPI mine = (MissileAPI) engine.spawnProjectile(source, null, 
															  getWeaponId(), 
															  currLoc, 
															  mineDir, null);
		mine.setFlightTime((float) Math.random());
		mine.fadeOutThenIn(1f);
		
		Global.getSoundPlayer().playSound("mine_spawn", 1f, 1f, mine.getLocation(), mine.getVelocity());
	}
	
	//Slightly re-tooled from Alex implementation; now properly checks the collision radius of *the other ships*, and not the ship the asteroid targets
	//This fixes a bug where a small-enough frigate could make a projectile spawn INSIDE a large-enough capital ship
	public boolean isAreaClear(Vector2f loc, float range) {
		CombatEngineAPI engine = Global.getCombatEngine();
		for (ShipAPI other : engine.getShips()) {
			if (other.isFighter()) continue;
			if (other.isDrone()) continue;
			
			float dist = Misc.getDistance(loc, other.getLocation());
			if (dist < range + other.getCollisionRadius()) {
				return false;
			}
		}
		
		for (CombatEntityAPI other : Global.getCombatEngine().getAsteroids()) {
			float dist = Misc.getDistance(loc, other.getLocation());
			if (dist < other.getCollisionRadius() + 100f) {
				return false;
			}
		}
		
		return true;
	}

}




