package data.world;

import java.awt.Color;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import data.scripts.campaign.loa_AnargaiaDeathManager;
import data.scripts.campaign.loa_anargaia_bombardment_terrain;
import data.scripts.campaign.loa_fake_alcubierre_ring_terrain;
import data.scripts.campaign.loa_new_alcubierre_ring_terrain;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Generates Anargaia and attaches various extra scripts to it to get a solid all-round experience. Sure wish it showed in the starsystem screen though...
 * @author Nicke535
 */
public class loa_anargaia {
    /* -- Governor/Admin settings -- */
    // The path to the portrait of the AGI admin. I think it also needs to be added to the settings.json file to show up like some other custom sprites, but I'm not sure
    public static final String ADMIN_PORTRAIT_PATH = "graphics/arkleg/portraits/loa_enigma.png";

    // The first and last name of the AGI core (last should probably be left empty, unless you want it to have one)
    public static final String ADMIN_FIRST_NAME = "Enigma";
    public static final String ADMIN_LAST_NAME = "Core";

    /* -- BASIC GENERATION SETTINGS -- */
    // - Waypoints on world map to move across; loops around (1->2->3->1->2 ...)
    private static final List<Vector2f> WAYPOINTS = new ArrayList<>();
    static {
        WAYPOINTS.add(new Vector2f(-8619f, -15538f));
        WAYPOINTS.add(new Vector2f(-8982f, -9886f));
        WAYPOINTS.add(new Vector2f(-2803f, -6351f));
        WAYPOINTS.add(new Vector2f(-712f, -1336f));
        WAYPOINTS.add(new Vector2f(-7499f, 3320f));
        WAYPOINTS.add(new Vector2f(-15267f, 3133f));
        WAYPOINTS.add(new Vector2f(-17532f, -1074f));
        WAYPOINTS.add(new Vector2f(-8290f, -4294f));
        WAYPOINTS.add(new Vector2f(-17562f, -13045f));
        WAYPOINTS.add(new Vector2f(-12716f, -15261f));
    }

    // - Speed on the world sector map
    private static final float SPEED = 10f;

    // - Inner radius of the Alcubierre Zone
    private static final float ALCUBIERRE_SIZE_INNER = 1000f;

    // - Outer radius of the Alcubierre Zone
    private static final float ALCUBIERRE_SIZE_OUTER = 15000f;

    // - Inner and outer radii for the extra visual alcubierre zones (those that have no in-game effect other than visuals)
    // -- For each entry in this list, you get an additional visual zone overlayed. The first number is inner radius, the second outer radius
    private static final List<Pair<Float, Float>> ALCUBIERRE_ADDITIONAL_VISUAL_AREAS = new ArrayList<>();
    static {
        ALCUBIERRE_ADDITIONAL_VISUAL_AREAS.add(new Pair<>(2000f, 14000f));
        ALCUBIERRE_ADDITIONAL_VISUAL_AREAS.add(new Pair<>(3000f, 16000f));
        ALCUBIERRE_ADDITIONAL_VISUAL_AREAS.add(new Pair<>(4000f, 18000f));
        ALCUBIERRE_ADDITIONAL_VISUAL_AREAS.add(new Pair<>(5000f, 20000f));
    }

    // - Inner radius of the Nuclear Flak (this is the direct-hit range)
    private static final float FLAK_SIZE_INNER = 500f;

    // - Outer radius of the Nuclear Flak
    private static final float FLAK_SIZE_OUTER = 2000f;


    /* -- STAR PARTICLE SETTINGS -- */
    //Streaking stars to spawn on average each second
    private static final float STAR_AMOUNT_PER_SECOND = 150f;

    //Speed of streaking stars (average: parralax is also applied here)
    private static final float STAR_PARTICLE_SPEED = 250f;

    //Size of streaking stars (average: parralax also applies)
    private static final float STAR_PARTICLE_SIZE = 7f;


    /* -- ENGINE PLUME SETTINGS -- */
    //Particles for the engine plume each second
    private static final float ENGINE_PARTICLES_PER_SECOND = 250f;

    //Speed of engine plume particles, minimum and maximum
    private static final float ENGINE_PARTICLE_SPEED_MIN = 75f;
    private static final float ENGINE_PARTICLE_SPEED_MAX = 150;

    //Size of the engine plume particles, minimum and maximum
    private static final float ENGINE_PARTICLE_SIZE_MIN = 18f;
    private static final float ENGINE_PARTICLE_SIZE_MAX = 22f;

    //Distance from the center of Anargaia that the engine plume starts spawning
    private static final float ENGINE_SPAWN_DISTANCE = 125f;

    //How "wide" the plume of the engine is at the base of the engine
    private static final float ENGINE_BASE_WIDTH = 40f;

    //Angle width of the engine plume
    private static final float ENGINE_ANGLE = 35f;

    //Minimum and maximum lifetime of the engine particles
    private static final float ENGINE_PARTICLE_DURATION_MIN = 1.4f;
    private static final float ENGINE_PARTICLE_DURATION_MAX = 2.2f;

    //Particle color of the engine plume (due to rendering, some white will be mixed in as well)
    private static final Color ENGINE_PARTICLE_COLOR = new Color(255, 122, 39);



    //Main generation function
    public MarketAPI generate(SectorAPI sector) {
        StarSystemAPI system = sector.createStarSystem("Anargaia");
        system.getLocation().set(WAYPOINTS.get(0));
        LocationAPI hyper = Global.getSector().getHyperspace();

        system.setBackgroundTextureFilename("graphics/arkleg/backgrounds/loa_warpedspace.jpg");

        // Create a centerpoint in the system, for everything to rotate around.
        SectorEntityToken centerpoint = system.initNonStarCenter();

        //Change our type to NEBULA to indicate we have no centerpoint. Might have some consequences, but this is the only way I found that is neat to do
        system.setType(StarSystemGenerator.StarSystemType.NEBULA);

        // Sets light color in entire system, affects all entities
        system.setLightColor(new Color(255, 255, 255));


        // Adds the giant space station Anargaia
        SectorEntityToken anargaia = system.addCustomEntity("loa_anargaia_station", "Anargaia", "loa_ars_capitol", "al_ars");
        anargaia.setCircularOrbitPointingDown(centerpoint, 0f, 50f, 99999999999f);
        anargaia.setCustomDescriptionId("loa_anargaia");

        // Add the marketplace to Anargaia ---------------
        MarketAPI anargaia_market = al_campaign_hax.addMarketplace("al_ars", anargaia, null,
                "Anargaia", // name of the market
                6, // size of the market
                new ArrayList<>(
                        Arrays.asList( // list of market conditions
                                Conditions.POPULATION_6, Conditions.OUTPOST, Conditions.FREE_PORT, Conditions.FRONTIER, "loa_raid_economy", 
                                Industries.POPULATION, Industries.MEGAPORT, Industries.ORBITALWORKS, Industries.WAYSTATION,
                                Industries.HEAVYBATTERIES,"loa_anargaia_station", Industries.HIGHCOMMAND, Industries.FUELPROD)),
                new ArrayList<>(
                        Arrays.asList( // which submarkets to generate
                                Submarkets.GENERIC_MILITARY,
                                Submarkets.SUBMARKET_BLACK,
                                Submarkets.SUBMARKET_OPEN,
                                Submarkets.SUBMARKET_STORAGE)),
                0.3f); //Tariff
        anargaia_market.setHidden(false);

        anargaia_market.getMemoryWithoutUpdate().set("$nex_unbuyable", true);
        
        // Adds a bombardment area surrounding Anargaia
        SectorEntityToken bombZone = system.addTerrain("loa_bombardment_zone", new loa_anargaia_bombardment_terrain.BombardmentAreaParams(
                anargaia_market,        // Market the terrain belongs to
                FLAK_SIZE_INNER,           // Size of the "near" effect area (direct hits)
                FLAK_SIZE_OUTER,          // Size of the "far" effect area
                "Bombardment Zone" // Terrain name
        ));

        //Adds our death manager, so we can keep track of when we are going to DIE
        Global.getSector().addScript(new loa_AnargaiaDeathManager(anargaia, anargaia_market, bombZone));

        // Adds the Alcubierre Drive's outer ring
        SectorEntityToken alcubierre_zone = system.addTerrain("loa_alcubierre_zone", new loa_new_alcubierre_ring_terrain.AlcubierreParams(
                ALCUBIERRE_SIZE_OUTER-ALCUBIERRE_SIZE_INNER,
                (ALCUBIERRE_SIZE_INNER+ ALCUBIERRE_SIZE_OUTER)/2f,
                anargaia,
                20000f,
                40f,
                0f
        ));
        //Adds the additional visual alcubierre rings
        for (Pair<Float, Float> pair : ALCUBIERRE_ADDITIONAL_VISUAL_AREAS) {
            SectorEntityToken visual_alcubierre = system.addTerrain("loa_fake_alcubierre_zone", new loa_fake_alcubierre_ring_terrain.AlcubierreParams(
                    pair.two-pair.one,
                    (pair.one+pair.two)/2f,
                    anargaia,
                    20000f,
                    40f,
                    0f
            ));
        }

        // Jump point : has a miniature script setting its rotation to be oppositely-locked to Anargaia ---------------
        JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("loa_anargaia_jump_point", "Anargaia Rift");
        jumpPoint.setCircularOrbit(centerpoint, 180f, 900f, 99999999999f);
        system.addEntity(jumpPoint);
        new OrbitOppositePlugin(jumpPoint, anargaia);

        // generates hyperspace destinations for in-system jump points
        system.autogenerateHyperspaceJumpPoints(false, false);
        system.generateAnchorIfNeeded();

        sector.addScript(new MovingStarsystemScript(anargaia, system));

        return anargaia_market;
    }

    private class OrbitOppositePlugin implements EveryFrameScript {
        SectorEntityToken orbiter;
        SectorEntityToken target;

        OrbitOppositePlugin(SectorEntityToken orbiter, SectorEntityToken target) {
            this.orbiter = orbiter;
            this.target = target;
            orbiter.getStarSystem().addScript(this);
        }


        @Override
        public void advance(float amount) {
            //Our behaviour is stopped if we are currently dying, and we remove ourselves from the engine
            loa_AnargaiaDeathManager.DEATH_STAGE deathStage = loa_AnargaiaDeathManager.DEATH_STAGE.NOT_STARTED;
            if (Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY) instanceof loa_AnargaiaDeathManager.DEATH_STAGE) {
                deathStage = (loa_AnargaiaDeathManager.DEATH_STAGE) Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY);
            }
            if (deathStage != loa_AnargaiaDeathManager.DEATH_STAGE.NOT_STARTED) {
                orbiter.getStarSystem().removeScript(this);
                return;
            }

            //Only run if the player is in our system
            if (Global.getSector().getPlayerFleet() != null
                    && Global.getSector().getPlayerFleet().getContainingLocation() == orbiter.getContainingLocation()) {
                //Ensure our orbits line up opposite to one another
                OrbitAPI orbiterOrbit = orbiter.getOrbit();
                OrbitAPI targetOrbit = target.getOrbit();
                if (orbiterOrbit != null && targetOrbit != null) {
                    orbiter.setCircularOrbitAngle(target.getCircularOrbitAngle()+180f);
                }
            }
        }

        @Override
        public boolean runWhilePaused() {
            return false;
        }

        @Override
        public boolean isDone() {
            return false;
        }
    }


    //Manages moving the starsystem itself: turns to face the right direction, and spawns particle effects for a "speed" feeling
    private class MovingStarsystemScript implements EveryFrameScript {
        private SectorEntityToken starStation;
        private StarSystemAPI system;

        private float currentFacing = 0f;
        private int currentWaypoint = 0;
        private boolean runOnce = false;
        boolean marketIsOpen = false;
        private Vector2f storedLoc = null;

        private MovingStarsystemScript(SectorEntityToken starStation, StarSystemAPI system) {
            this.starStation = starStation;
            this.system = system;

            //Spawns us in a random spot on our "track"
            currentWaypoint = MathUtils.getRandomNumberInRange(0, WAYPOINTS.size()-1);
            Vector2f targetPos = new Vector2f(WAYPOINTS.get(currentWaypoint));
            float distanceAlongToTarget = MathUtils.getRandomNumberInRange(0f, 1f);
            int previousPoint = currentWaypoint-1;
            if (previousPoint < 0) {
                previousPoint = WAYPOINTS.size()-1;
            }
            Vector2f previousPos = new Vector2f(WAYPOINTS.get(previousPoint));
            Vector2f spawnPos = Misc.interpolateVector(previousPos, targetPos, distanceAlongToTarget);
            system.getLocation().x = spawnPos.x;
            system.getLocation().y = spawnPos.y;

            Global.getSector().addListener(new RegisterOpenMarketListener(this));
        }


        @Override
        public void advance(float amount) {
            if (Global.getSector().isPaused()) {
                amount = 0f;
            }

            //Our behaviour is stopped if we are currently dying, and we remove ourselves from the engine
            loa_AnargaiaDeathManager.DEATH_STAGE deathStage = loa_AnargaiaDeathManager.DEATH_STAGE.NOT_STARTED;
            if (Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY) instanceof loa_AnargaiaDeathManager.DEATH_STAGE) {
                deathStage = (loa_AnargaiaDeathManager.DEATH_STAGE) Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY);
            }
            if (deathStage != loa_AnargaiaDeathManager.DEATH_STAGE.NOT_STARTED) {
                Global.getSector().removeScript(this);
                return;
            }

            //If we are in a market, don't run normal stuff: instead, randomize our location every frame to confound people looking in the commodity screen
            if (marketIsOpen) {
                if (storedLoc == null) {
                    storedLoc = new Vector2f(system.getLocation());
                }
                system.getLocation().x = MathUtils.getRandomNumberInRange(-9999f, 9999f);
                system.getLocation().y = MathUtils.getRandomNumberInRange(-9999f, 9999f);
            } else {
                if (storedLoc != null) {
                    system.getLocation().x = storedLoc.x;
                    system.getLocation().y = storedLoc.y;
                    storedLoc = null;
                }

                //Moves our location closer to the next waypoint. If we reach it, set us to aim for the next waypoint, too
                if (MathUtils.getDistance(system.getLocation(), WAYPOINTS.get(currentWaypoint)) < amount * SPEED) {
                    //Don't shift end-waypoints if we're in the system itself: just halt in that case
                    if (!Global.getSector().getPlayerFleet().getContainingLocation().equals(starStation.getContainingLocation())) {
                        system.getLocation().x = WAYPOINTS.get(currentWaypoint).x;
                        system.getLocation().y = WAYPOINTS.get(currentWaypoint).y;
                        currentWaypoint++;
                        if (currentWaypoint >= WAYPOINTS.size()) {
                            currentWaypoint = 0;
                        }
                    }
                } else {
                    Vector2f dirVector = VectorUtils.getDirectionalVector(system.getLocation(), WAYPOINTS.get(currentWaypoint));
                    dirVector.scale(amount*SPEED);
                    system.getLocation().x += dirVector.x;
                    system.getLocation().y += dirVector.y;
                }

                //Always adjust our angle to point towards our "correct" facing: if the player is in the system, we only adjust rotation once
                if (Global.getSector().getPlayerFleet().getContainingLocation().equals(starStation.getContainingLocation())) {
                    if (runOnce) {
                        runOnce = false;
                        starStation.setCircularOrbitAngle(currentFacing+90f);
                    }

                    //We also spawn streaking stars when the player is in the system
                    spawnStreakingStars(amount);

                    //We *also* spawn a particle plume behind Anargaia itself
                    spawnEnginePlume(amount, starStation);
                } else {
                    runOnce = true;
                    currentFacing = VectorUtils.getAngle(system.getLocation(), WAYPOINTS.get(currentWaypoint));
                }
            }
        }

        //Utility function for also spawning small "streaking stars" as a sign that the thing is moving
        private void spawnStreakingStars(float amount) {
            //The stars spawn across a massive area, but only if they are close to the camera viewport
            float starsToSpawnThisFrame = STAR_AMOUNT_PER_SECOND * amount;

            ViewportAPI view = Global.getSector().getViewport();
            Vector2f centerPoint = MathUtils.getPoint(view.getCenter(), STAR_PARTICLE_SPEED *0.5f, currentFacing);
            for (int i = 0; (i-Math.random()) < starsToSpawnThisFrame; i++) {
                float parralax = MathUtils.getRandomNumberInRange(0.5f, 2f);
                Vector2f point = MathUtils.getRandomPointInCircle(centerPoint, view.getVisibleWidth()*2f);
                Vector2f particleSpeed = MathUtils.getPoint(new Vector2f(0f, 0f), STAR_PARTICLE_SPEED *parralax, currentFacing);
                particleSpeed.x *= -1f;
                particleSpeed.y *= -1f;
                if (view.isNearViewport(point, 500f)) {
                    starStation.getContainingLocation().addHitParticle(point, particleSpeed, STAR_PARTICLE_SIZE *parralax,
                            parralax, 1.5f, Color.white);
                }
            }
        }

        //Utility function for also spawning an engine plume on our station
        private void spawnEnginePlume(float amount, SectorEntityToken station) {
            //Determine spawn count
            float particlesThisFrame = ENGINE_PARTICLES_PER_SECOND*amount;

            ViewportAPI view = Global.getSector().getViewport();
            Vector2f centerPoint = MathUtils.getPoint(station.getLocation(), ENGINE_SPAWN_DISTANCE, currentFacing+180f);
            for (int i = 0; (i-Math.random()) < particlesThisFrame; i++) {
                float speed = MathUtils.getRandomNumberInRange(ENGINE_PARTICLE_SPEED_MIN, ENGINE_PARTICLE_SPEED_MAX);
                float sizeVariation = MathUtils.getRandomNumberInRange(0f, 1f);
                float angleDir = MathUtils.getRandomNumberInRange(-0.5f, 0.5f); //Helps make the "cone" into a more traditional engine plume
                float angleFactorMod = 1f-Math.abs(angleDir);
                Vector2f point = MathUtils.getPoint(centerPoint, ENGINE_BASE_WIDTH * (angleDir*-1f), currentFacing+90f);
                Vector2f particleSpeed = MathUtils.getPoint(new Vector2f(0f, 0f), speed*angleFactorMod,
                        currentFacing+angleDir*ENGINE_ANGLE);
                particleSpeed.x *= -1f;
                particleSpeed.y *= -1f;
                if (view.isNearViewport(point, 500f)) {
                    starStation.getContainingLocation().addHitParticle(point, particleSpeed,
                            ENGINE_PARTICLE_SIZE_MIN * (1f-sizeVariation) + ENGINE_PARTICLE_SIZE_MAX *sizeVariation,
                            sizeVariation, angleFactorMod*MathUtils.getRandomNumberInRange(ENGINE_PARTICLE_DURATION_MIN, ENGINE_PARTICLE_DURATION_MAX),
                            ENGINE_PARTICLE_COLOR);
                }
            }
        }

        @Override
        public boolean runWhilePaused() {
            return true;
        }

        @Override
        public boolean isDone() {
            return false;
        }
    }

    private class RegisterOpenMarketListener extends BaseCampaignEventListener{
        MovingStarsystemScript script;
        public RegisterOpenMarketListener(MovingStarsystemScript script) {
            super(true);
            this.script = script;
        }

        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
            if (!"loa_anargaia_station_market".equals(market.getId())) {
                script.marketIsOpen = true;
            }
        }

        @Override
        public void reportPlayerClosedMarket(MarketAPI market) {
            if (!"loa_anargaia_station_market".equals(market.getId())) {
                script.marketIsOpen = false;
            }
        }
    }
}
