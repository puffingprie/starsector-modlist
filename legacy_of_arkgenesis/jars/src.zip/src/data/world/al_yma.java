package data.world;

import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import java.util.ArrayList;
import java.util.Arrays;

public class al_yma
{
    public void generate(SectorAPI sector)
    {
//        StarSystemAPI system = sector.getStarSystem("Yma");
//
//        SectorEntityToken al_fulcrum = system.addCustomEntity("al_fulcrum", "Fulcrum Station", "al_arsbase_4", "al_ars");
//        al_fulcrum.setCircularOrbit(system.getEntityById("Yma"), 270-60, 12500, 800);
//        al_fulcrum.setCustomDescriptionId("al_arsbase_4_fulcrum");
//        al_fulcrum.setInteractionImage("illustrations", "cargo_loading");
//
//        MarketAPI al_fulcrum_market = al_campaign_hax.addMarketplace("al_ars", al_fulcrum,
//                null,
//                "Fulcrum Station", 4,
//
//                new ArrayList<>(
//                        Arrays.asList(Conditions.POPULATION_4,
//                                Conditions.OUTPOST, Conditions.FREE_PORT, Conditions.FRONTIER, 
//                                Conditions.ORE_MODERATE, Conditions.RARE_ORE_SPARSE, 
//                                Industries.POPULATION, Industries.MILITARYBASE, Industries.SPACEPORT, Industries.ORBITALWORKS, 
//                                Industries.WAYSTATION, Industries.BATTLESTATION, Industries.MINING, Industries.HEAVYBATTERIES)),
//                                
//                new ArrayList<>(
//                        Arrays.asList(Submarkets.GENERIC_MILITARY, Submarkets.SUBMARKET_BLACK,
//                        Submarkets.SUBMARKET_OPEN, Submarkets.SUBMARKET_STORAGE)),
//                0.3f);
    }
}
