package data.missions.al_folly;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "SDC", FleetGoal.ATTACK, false, 10);
		api.initFleet(FleetSide.ENEMY, "DSS", FleetGoal.ATTACK, true, 10);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "A Band of Barbarous Invaders.");
		api.setFleetTagline(FleetSide.ENEMY, "Domain response fleet under Rear Admiral William Alastair");
		
		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy the Domain response fleet.");
		api.addBriefingItem("The enemy is tough but their range is short, avoid close combat at all costs.");
                api.addBriefingItem("The Maldomain II must survive.");
		
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "loa_folley_alastair", FleetMemberType.SHIP, "SDC Maldomain II", true);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_lyons", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "loa_folley_jameson", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "loa_folley_jameson", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "loa_folley_jameson", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "loa_folley_victoria", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "loa_folley_burke", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_caswell", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_thatcher", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "loa_folley_norwood", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_walsh", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_walsh", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_sherman", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.PLAYER, "loa_folley_sherman", FleetMemberType.SHIP, false);
			
		// Mark player flagship as essential
		api.defeatOnShipLoss("SDC Maldomain II");
		
		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "al_folly_onslaught", FleetMemberType.SHIP, "DSS Incorrigable", true);
		api.addToFleet(FleetSide.ENEMY, "al_folly_dominator", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_dominator", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_dominator", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_mora", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.ENEMY, "al_folly_mora", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_gemini", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_gemini", FleetMemberType.SHIP, false);
		//api.addToFleet(FleetSide.ENEMY, "al_folly_enforcer", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_enforcer", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_enforcer", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_enforcer", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
                //api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
                //api.addToFleet(FleetSide.ENEMY, "al_folly_lasher", FleetMemberType.SHIP, false);
		
		
		// Set up the map.
		float width = 24000f;
		float height = 18000f;
		api.initMap((float)-width/2f, (float)width/2f, (float)-height/2f, (float)height/2f);
		
		float minX = -width/2;
		float minY = -height/2;
	
		for (int i = 0; i < 15; i++) {
			float x = (float) Math.random() * width - width/2;
			float y = (float) Math.random() * height - height/2;
			float radius = 100f + (float) Math.random() * 900f; 
			api.addNebula(x, y, radius);
		}
		
		api.addNebula(minX + width * 0.8f - 5000, minY + height * 0.5f, 1000);
		
		api.addObjective(minX + width * 0.8f - 1000, minY + height * 0.5f, "nav_buoy");
		api.addObjective(minX + width * 0.2f + 1000, minY + height * 0.5f, "nav_buoy");
		api.addObjective(minX + width * 0.5f, minY + height * 0.5f, "sensor_array");
                api.addObjective(minX + width * 0.8f - 1000, minY + height * 0.7f, "comm_relay");
		api.addObjective(minX + width * 0.2f + 1000, minY + height * 0.3f, "comm_relay");
		
		// Add an asteroid field
		api.addAsteroidField(minX + width * 0.7f, minY + height * 0.5f, 45, 5000f,
								20f, 70f, 50);
                api.addAsteroidField(minX + width * 0.3f, minY + height * 0.5f, 45, 5000f,
								20f, 70f, 50);
		api.addAsteroidField(minX + width * 0.1f, minY + height * 0.5f, 45, 500f,
								20f, 70f, 50);
		 //Add some planets.  These are defined in data/config/planets.json.
		api.addPlanet(0, 0, 200f, "irradiated", 350f, true);
	}

}






