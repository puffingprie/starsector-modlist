package data.missions.loa_randtest;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI.ShipPickMode;
import com.fs.starfarer.api.campaign.PlanetSpecAPI;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.fleets.DefaultFleetInflater;
import com.fs.starfarer.api.impl.campaign.fleets.DefaultFleetInflaterParams;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector2f;

public class MissionDefinition implements MissionDefinitionPlugin {

    public static final List<String> PLAYER_FACTIONS = new ArrayList<>();
    public static final List<String> ENEMY_FACTIONS = new ArrayList<>();
    public static final String[] OBJECTIVE_TYPES = {
        "sensor_array", "nav_buoy", "comm_relay"
    };
    public static final List<String> PLANETS = new ArrayList<>();

    private static final Random rand = new Random();
    private static int size = 30;
    private static boolean first = true;

    private static String playerFaction;
    private static int playerFactionIndex;
    private static int playerQuality;
    private static String enemyFaction;
    private static int enemyFactionIndex;
    private static int enemyAdvantage;
    private static int enemyQuality;
    private static boolean balanceFleets;
    private static boolean boostTime;

    private static long bestPlayerFleetSeed = 0L;
    private static long bestEnemyFleetSeed = 0L;
    private static float bestDistance = Float.MAX_VALUE;

    static {
        PLAYER_FACTIONS.add("al_ars");

        ENEMY_FACTIONS.add(Factions.HEGEMONY);
        ENEMY_FACTIONS.add(Factions.PERSEAN);
        ENEMY_FACTIONS.add(Factions.TRITACHYON);
        ENEMY_FACTIONS.add(Factions.DIKTAT);
        ENEMY_FACTIONS.add(Factions.LUDDIC_CHURCH);
        ENEMY_FACTIONS.add(Factions.INDEPENDENT);
        ENEMY_FACTIONS.add(Factions.LIONS_GUARD);
        ENEMY_FACTIONS.add(Factions.LUDDIC_PATH);
        ENEMY_FACTIONS.add(Factions.PIRATES);
        ENEMY_FACTIONS.add(Factions.TRITACHYON);
        ENEMY_FACTIONS.add(Factions.DERELICT);
        ENEMY_FACTIONS.add(Factions.REMNANTS);
    }

    private void init() {
        for (PlanetSpecAPI spec : Global.getSettings().getAllPlanetSpecs()) {
            PLANETS.add(spec.getPlanetType());
        }
    }

    @Override
    public void defineMission(MissionDefinitionAPI api) {
        boolean refreshPlayer = false;
        boolean refreshEnemy = false;

        if (first || Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL)) {
            init();
            first = false;
            playerFaction = PLAYER_FACTIONS.get(0);
            playerFactionIndex = PLAYER_FACTIONS.indexOf(playerFaction);
            enemyFaction = ENEMY_FACTIONS.get(0);
            enemyFactionIndex = ENEMY_FACTIONS.indexOf(enemyFaction);
            size = 30;
            enemyAdvantage = 100;
            playerQuality = 125;
            enemyQuality = 125;
            balanceFleets = true;
            boostTime = true;
            refreshPlayer = true;
            refreshEnemy = true;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
            refreshPlayer = true;
            refreshEnemy = true;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
            size = Math.max(size - 1, 1);
            refreshPlayer = true;
            refreshEnemy = true;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
            size = Math.min(size + 1, 250);
            refreshPlayer = true;
            refreshEnemy = true;
        }

        int objectiveCount = (int) Math.floor(size * ((float) Math.random() * 0.75f + 0.5f) / 8f);
        float width = (12000f + 10000f * (size / 40f)) * ((float) Math.random() * 0.4f + 0.6f);
        float height = (12000f + 10000f * (size / 40f)) * ((float) Math.random() * 0.4f + 0.6f);
        width = (int) (width / 500f) * 500;
        height = (int) (height / 500f) * 500;

        api.initFleet(FleetSide.PLAYER, "A", FleetGoal.ATTACK, true, size / 8);
        api.initFleet(FleetSide.ENEMY, "B", FleetGoal.ATTACK, true, size / 8);

        switch (objectiveCount) {
            case 0:
                api.addBriefingItem("Battle size: " + size + "  -  " + (int) width + "x" + (int) height);
                break;
            case 1:
                api.addBriefingItem("Battle size: " + size + "  -  " + objectiveCount + " objective" + "  -  " + (int) width + "x" + (int) height);
                break;
            default:
                api.addBriefingItem("Battle size: " + size + "  -  " + objectiveCount + " objectives" + "  -  " + (int) width + "x" + (int) height);
                break;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
            playerFactionIndex = (playerFactionIndex + 1) % PLAYER_FACTIONS.size();
            playerFaction = PLAYER_FACTIONS.get(playerFactionIndex);
            refreshPlayer = true;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_F)) {
            enemyFactionIndex = (enemyFactionIndex + 1) % ENEMY_FACTIONS.size();
            enemyFaction = ENEMY_FACTIONS.get(enemyFactionIndex);
            refreshEnemy = true;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_E)) {
            enemyAdvantage = Math.max(enemyAdvantage - 5, 5);
            refreshEnemy = true;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_R)) {
            enemyAdvantage = Math.min(enemyAdvantage + 5, 1000);
            refreshEnemy = true;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_I)) {
            playerQuality = Math.max(playerQuality - 5, -25);
            refreshPlayer = true;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_O)) {
            playerQuality = Math.min(playerQuality + 5, 125);
            refreshPlayer = true;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_K)) {
            enemyQuality = Math.max(enemyQuality - 5, -25);
            refreshEnemy = true;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_L)) {
            enemyQuality = Math.min(enemyQuality + 5, 125);
            refreshEnemy = true;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_B)) {
            balanceFleets = !balanceFleets;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_T)) {
            boostTime = !boostTime;
        }

        float playerSize = size * 5f;
        float enemySize = size * 5f * (enemyAdvantage / 100f);

        api.setFleetTagline(FleetSide.PLAYER, playerFaction + " (" + Math.round(playerSize) + " points) (Q " + playerQuality + "%)");
        api.setFleetTagline(FleetSide.ENEMY, enemyFaction + " (" + Math.round(enemySize) + " points) (Q " + enemyQuality + "%)");

        int reps = 1;
        if (refreshPlayer || refreshEnemy) {
            bestDistance = Float.MAX_VALUE;
            if (balanceFleets) {
                reps = 1000;
            }
        }

        CampaignFleetAPI bestPlayerFleet = null;
        CampaignFleetAPI bestEnemyFleet = null;
        for (int i = 0; i < reps; i++) {
            CampaignFleetAPI playerFleet;
            long playerFleetSeed;
            if ((i == 0) || refreshPlayer) {
                FleetParamsV3 params = new FleetParamsV3(null,
                        new Vector2f(0, 0),
                        playerFaction,
                        playerQuality / 100f, // qualityOverride
                        "missionFleet",
                        playerSize, // combatPts
                        0f, // freighterPts
                        0f, // tankerPts
                        0f, // transportPts
                        0f, // linerPts
                        0f, // utilityPts
                        0f); // qualityMod
                params.withOfficers = false;
                params.ignoreMarketFleetSizeMult = true;
                params.forceAllowPhaseShipsEtc = true;
                params.modeOverride = ShipPickMode.PRIORITY_THEN_ALL;

                if (refreshPlayer) {
                    playerFleetSeed = rand.nextLong();
                } else {
                    playerFleetSeed = bestPlayerFleetSeed;
                }
                params.random = new Random(playerFleetSeed);

                playerFleet = FleetFactoryV3.createFleet(params);
                if (!refreshPlayer) {
                    bestPlayerFleet = playerFleet;
                }
            } else {
                playerFleet = bestPlayerFleet;
                playerFleetSeed = bestPlayerFleetSeed;
            }

            CampaignFleetAPI enemyFleet;
            long enemyFleetSeed;
            if ((i == 0) || refreshEnemy) {
                FleetParamsV3 params = new FleetParamsV3(null,
                        new Vector2f(0, 0),
                        enemyFaction,
                        enemyQuality / 100f, // qualityOverride
                        "missionFleet",
                        enemySize, // combatPts
                        0f, // freighterPts
                        0f, // tankerPts
                        0f, // transportPts
                        0f, // linerPts
                        0f, // utilityPts
                        0f); // qualityMod
                params.withOfficers = false;
                params.ignoreMarketFleetSizeMult = true;
                params.forceAllowPhaseShipsEtc = true;
                params.modeOverride = ShipPickMode.PRIORITY_THEN_ALL;

                if (refreshEnemy) {
                    enemyFleetSeed = rand.nextLong();
                } else {
                    enemyFleetSeed = bestEnemyFleetSeed;
                }
                params.random = new Random(enemyFleetSeed);

                enemyFleet = FleetFactoryV3.createFleet(params);
                if (!refreshEnemy) {
                    bestEnemyFleet = enemyFleet;
                }
            } else {
                enemyFleet = bestEnemyFleet;
                enemyFleetSeed = bestEnemyFleetSeed;
            }

            if ((playerFleet == null) || (enemyFleet == null)) {
                continue;
            }

            float friendlyDP = 0f;
            float friendlyFP = 0f;
            for (FleetMemberAPI member : playerFleet.getFleetData().getMembersInPriorityOrder()) {
                friendlyDP += member.getDeploymentPointsCost();
                friendlyFP += member.getFleetPointCost();
            }

            float enemyDP = 0f;
            float enemyFP = 0f;
            for (FleetMemberAPI member : enemyFleet.getFleetData().getMembersInPriorityOrder()) {
                enemyDP += member.getDeploymentPointsCost();
                enemyFP += member.getFleetPointCost();
            }

            float distance = Math.abs(enemyDP - friendlyDP) + Math.abs(enemyFP - friendlyFP);
            if (distance < bestDistance) {
                bestDistance = distance;
                bestPlayerFleetSeed = playerFleetSeed;
                bestPlayerFleet = playerFleet;
                bestEnemyFleetSeed = enemyFleetSeed;
                bestEnemyFleet = enemyFleet;
            }

            if (Math.round(distance) <= 0) {
                break;
            }
        }

        if ((bestPlayerFleet == null) || (bestEnemyFleet == null)) {
            return;
        }

        api.addBriefingItem("Match inequality: " + Math.round(bestDistance));

        if (boostTime) {
            api.addBriefingItem("Time acceleration applied!");
        }

        if (refreshPlayer) {
            DefaultFleetInflaterParams p = new DefaultFleetInflaterParams();
            p.quality = playerQuality / 100f;
            p.seed = MathUtils.getRandom().nextLong();
            p.mode = ShipPickMode.PRIORITY_THEN_ALL;

            DefaultFleetInflater inflater = new DefaultFleetInflater(p);
            inflater.inflate(bestPlayerFleet);
        }

        for (FleetMemberAPI member : bestPlayerFleet.getFleetData().getMembersInPriorityOrder()) {
            api.addFleetMember(FleetSide.PLAYER, member);
        }

        if (refreshEnemy) {
            DefaultFleetInflaterParams p = new DefaultFleetInflaterParams();
            p.quality = enemyQuality / 100f;
            p.seed = MathUtils.getRandom().nextLong();
            p.mode = ShipPickMode.PRIORITY_THEN_ALL;

            DefaultFleetInflater inflater = new DefaultFleetInflater(p);
            inflater.inflate(bestEnemyFleet);
        }

        for (FleetMemberAPI member : bestEnemyFleet.getFleetData().getMembersInPriorityOrder()) {
            api.addFleetMember(FleetSide.ENEMY, member);
        }

        api.initMap(-width / 2f, width / 2f, -height / 2f, height / 2f);

        float minX = -width / 2;
        float minY = -height / 2;

        int fakeSize = (int) (((width / ((float) Math.random() * 0.4f + 0.6f) - 12000f) * 150f / 10000f
                + (height / ((float) Math.random() * 0.4f + 0.6f) - 12000f) * 150f / 10000f) / 7.5f);

        int nebulaCount = (int) ((1f + (float) Math.random() * 3f) * (float) Math.sqrt(fakeSize * 3f));
        float nebulaSize = (float) Math.random();

//        if (nebulaSize * nebulaCount >= 32.5) {
//            api.addBriefingItem("Alert: Deep nebula");
//        } else if (nebulaSize * nebulaCount >= 25) {
//            api.addBriefingItem("Alert: Thick nebula");
//        } else if (nebulaSize * nebulaCount >= 17.5) {
//            api.addBriefingItem("Alert: Moderate nebula");
//        } else if (nebulaSize * nebulaCount >= 10) {
//            api.addBriefingItem("Alert: Sparse nebula");
//        }
        for (int i = 0; i < nebulaCount; i++) {
            float x = (float) Math.random() * width - width / 2;
            float y = (float) Math.random() * height - height / 2;
            float radius = (1f + (float) Math.random() * 4f) * nebulaSize * fakeSize;
            api.addNebula(x, y, radius);
        }

        double r;
        int objectives = objectiveCount;
        while (objectives > 0) {
            String type = OBJECTIVE_TYPES[rand.nextInt(OBJECTIVE_TYPES.length)];
            int configuration;
            r = Math.random();
            if (r < 0.5) {
                configuration = 0;
            } else if (r < 0.75) {
                configuration = 1;
            } else {
                configuration = 2;
            }

            if (objectives == 1) {
                r = Math.random();
                if (r < 0.75) {
                    api.addObjective(0f, 0f, type);
                } else if (r < 0.875) {
                    float x = (width * 0.075f + width * 0.3f * (float) Math.random()) * (Math.random() > 0.5 ? 1f : -1f);
                    api.addObjective(x, 0f, type);
                } else {
                    float y = (height * 0.075f + height * 0.3f * (float) Math.random()) * (Math.random() > 0.5 ? 1f : -1f);
                    api.addObjective(0f, y, type);
                }

                objectives -= 1;
            } else {
                float x1, x2, y1, y2;
                r = Math.random();
                if ((r < 0.75 && configuration == 0) || (r < 0.5 && configuration == 1) || (r < 0.25 && configuration == 2)) {
                    float theta = (float) (Math.random() * Math.PI);
                    double radius = Math.min(width, height);
                    radius = radius * 0.1 + radius * 0.3 * Math.random();
                    x1 = (float) (Math.cos(theta) * radius);
                    y1 = (float) -(Math.sin(theta) * radius);
                    x2 = -x1;
                    y2 = -y1;
                } else if ((r < 0.875 && configuration == 0) || (r < 0.75 && configuration == 1) || (r < 0.625 && configuration == 2)) {
                    x1 = (width * 0.075f + width * 0.3f * (float) Math.random()) * (Math.random() > 0.5 ? 1f : -1f);
                    x2 = x1;
                    y1 = (height * 0.075f + height * 0.3f * (float) Math.random()) * (Math.random() > 0.5 ? 1f : -1f);
                    y2 = -y1;
                } else {
                    x1 = (width * 0.075f + width * 0.3f * (float) Math.random()) * (Math.random() > 0.5 ? 1f : -1f);
                    x2 = -x1;
                    y1 = (height * 0.075f + height * 0.3f * (float) Math.random()) * (Math.random() > 0.5 ? 1f : -1f);
                    y2 = y1;
                }

                r = Math.random();
                if (r < 0.75) {
                    api.addObjective(x1, y1, type);
                    api.addObjective(x2, y2, type);
                } else {
                    api.addObjective(x1, y1, type);
                    type = OBJECTIVE_TYPES[rand.nextInt(OBJECTIVE_TYPES.length)];
                    api.addObjective(x2, y2, type);
                }

                objectives -= 2;
            }
        }

        int asteroidSpeed = (int) (Math.pow(Math.random() * 0.75f + 0.25f, 3.0) * 200f);
        int asteroidCount = fakeSize + (int) (fakeSize * 4 * Math.pow(Math.random(), 3.0));
        int asteroidFieldCount = (int) (fakeSize * (float) Math.pow(Math.random(), 2.0) / 6.5f);
        int ringAsteroidCount = (int) (asteroidCount * 4 * Math.random());
        int ringAsteroidFieldCount = (int) (fakeSize * (float) Math.pow(Math.random(), 2.0) / 10f);
        float asteroidType = (float) Math.random();
        if (asteroidType <= 0.45f) {
            ringAsteroidCount = 0;
            ringAsteroidFieldCount = 0;
        } else if (asteroidType <= 0.9f) {
            asteroidCount = 0;
            asteroidFieldCount = 0;
        }

        if ((float) Math.sqrt(asteroidSpeed) * (asteroidCount * asteroidFieldCount + ringAsteroidCount * (ringAsteroidFieldCount / 4)) / (fakeSize * fakeSize) >= 6f) {
            api.addBriefingItem("Alert: Asteroid storm");
        } else if ((float) Math.sqrt(asteroidSpeed) * (asteroidCount * asteroidFieldCount + ringAsteroidCount * (ringAsteroidFieldCount / 4)) / (fakeSize * fakeSize) >= 3f) {
            api.addBriefingItem("Alert: Thick asteroids");
        } else if ((float) Math.sqrt(asteroidSpeed) * (asteroidCount * asteroidFieldCount + ringAsteroidCount * (ringAsteroidFieldCount / 4)) / (fakeSize * fakeSize) >= 1.5f) {
            api.addBriefingItem("Alert: Moderate asteroids");
        } else if ((float) Math.sqrt(asteroidSpeed) * (asteroidCount * asteroidFieldCount + ringAsteroidCount * (ringAsteroidFieldCount / 4)) / (fakeSize * fakeSize) >= 0.75f) {
            api.addBriefingItem("Alert: Sparse asteroids");
        }

        for (int i = 0; i < asteroidFieldCount; i++) {
            api.addAsteroidField(minX + width * 0.5f,
                    minY + height * 0.5f,
                    (float) Math.random() * 360f,
                    Math.min(width, height) * ((float) (Math.random() * Math.random()) * 0.8f + 0.2f),
                    asteroidSpeed * 0.75f,
                    asteroidSpeed,
                    asteroidCount);
        }
        for (int i = 0; i < ringAsteroidFieldCount; i++) {
            api.addRingAsteroids(minX + width * 0.5f,
                    minY + height * 0.5f,
                    (float) Math.random() * 360f,
                    Math.min(width, height) * ((float) (Math.random() * Math.random()) * 0.8f + 0.2f),
                    asteroidSpeed * 0.75f,
                    asteroidSpeed,
                    ringAsteroidCount);
        }

        String planet = PLANETS.get((int) (Math.random() * PLANETS.size()));
        float radius = 25f + (float) Math.random() * (float) Math.random() * 500f;

        api.addPlanet(0, 0, radius, planet, 0f, true);
        if (planet.contentEquals("wormholeUnder")) {
            api.addPlanet(0, 0, radius, "wormholeA", 0f, true);
            api.addPlanet(0, 0, radius, "wormholeB", 0f, true);
            api.addPlanet(0, 0, radius, "wormholeC", 0f, true);
        }

        api.getContext().aiRetreatAllowed = false;
        api.getContext().enemyDeployAll = true;
        api.getContext().fightToTheLast = true;

        if (boostTime) {
            api.addPlugin(new BaseEveryFrameCombatPlugin() {
                @Override
                public void init(CombatEngineAPI engine) {
                    engine.getContext().aiRetreatAllowed = false;
                    engine.getContext().enemyDeployAll = true;
                    engine.getContext().fightToTheLast = true;
                }

                @Override
                public void advance(float amount, List<InputEventAPI> events) {
                    if (Global.getCombatEngine().isPaused()) {
                        return;
                    }

                    float trueFrameTime = Global.getCombatEngine().getElapsedInLastFrame();
                    float trueFPS = 1 / trueFrameTime;
                    float newTimeMult = Math.max(1f, trueFPS / 30f);
                    Global.getCombatEngine().getTimeMult().modifyMult("ii_tester", newTimeMult);
                }
            });
        }
    }
}
